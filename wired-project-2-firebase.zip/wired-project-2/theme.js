import { Atom, FlaskConical, Sigma } from 'lucide-react';

/* ============================================================
   THEME — single source of truth for the "jbr" brand kit.
   Previously this ~60-line block was copy-pasted into every
   screen (Dashboard, QuestionPapersPreview, OverallAnalytics)
   and had already started to drift — each file had a few classes
   the others didn't. This is the merged superset; every class any
   screen uses lives here now. Swapping theme modes (Advanced
   Dungeon / Shadow Fight) means editing this one file.
   ============================================================ */
export const THEME = `
  @import url('https://fonts.googleapis.com/css2?family=Orbitron:wght@500;700;900&family=Rajdhani:wght@500;600;700&display=swap');

  .jbr-root {
    --bg-color: #0a0710; --bg-glow: #2a0f3a; --card-bg: #130b1a; --panel-bg: #170d20;
    --gold: #ff6a00; --gold-bright: #ffcf3d; --xp: #ff3d7d;
    --phys: #22d3ee; --chem: #39ff88; --maths: #c77dff; --danger: #ff1a5e;
    --text-main: #f3ecff; --text-muted: #9a83b0; --border: #3a2452;
    font-family: 'Roboto', sans-serif;
    background: var(--bg-color); color: var(--text-main); min-height: 100vh;
  }
  .jbr-display { font-family: 'Orbitron', sans-serif; letter-spacing: 1.5px; }
  .jbr-label { font-family: 'Rajdhani', sans-serif; font-weight: 600; letter-spacing: 1px; }
  .jbr-gradient-text {
    background: linear-gradient(90deg, var(--gold-bright), var(--xp), var(--maths));
    -webkit-background-clip: text; background-clip: text; color: transparent;
  }
  .jbr-glow-bg { background: radial-gradient(ellipse 80% 50% at 50% -10%, var(--bg-glow), transparent), var(--bg-color); }
  .jbr-card {
    background: var(--card-bg); border: 1px solid var(--border); border-radius: 16px;
    transition: box-shadow .25s ease, border-color .25s ease, transform .15s ease;
  }
  .jbr-card:hover { border-color: var(--gold); box-shadow: 0 0 24px -6px rgba(255,106,0,.35); transform: translateY(-2px); }
  .jbr-panel { background: var(--panel-bg); border: 1px solid var(--border); border-radius: 12px; }
  .jbr-input {
    background: var(--panel-bg); border: 1px solid var(--border); border-radius: 10px;
    color: var(--text-main); padding: 10px 14px; font-family: 'Roboto', sans-serif;
    width: 100%; transition: border-color .2s ease;
  }
  .jbr-input:focus { outline: none; border-color: var(--gold); }
  .jbr-input::placeholder { color: var(--text-muted); }
  .jbr-textarea {
    background: var(--panel-bg); border: 1px solid var(--border); border-radius: 10px;
    color: var(--text-main); padding: 12px 14px; font-family: 'Roboto', monospace;
    font-size: 13px; width: 100%; min-height: 120px; resize: vertical; transition: border-color .2s ease;
  }
  .jbr-textarea:focus { outline: none; border-color: var(--gold); }
  .jbr-textarea::placeholder { color: var(--text-muted); }
  .jbr-dropzone {
    border: 1.5px dashed var(--border); border-radius: 12px; transition: border-color .2s ease, background .2s ease;
  }
  .jbr-dropzone.active { border-color: var(--gold); background: rgba(255,106,0,0.06); }
  .jbr-btn-primary {
    background: linear-gradient(90deg, var(--gold), var(--xp)); color: #160a00;
    border-radius: 10px; padding: 12px 20px; font-family: 'Rajdhani', sans-serif;
    font-weight: 700; letter-spacing: 1px; transition: opacity .2s ease, transform .1s ease;
  }
  .jbr-btn-primary:disabled { opacity: 0.4; cursor: not-allowed; }
  .jbr-btn-primary:not(:disabled):active { transform: scale(0.98); }
  .jbr-num-input {
    background: var(--card-bg); border: 1px solid var(--border); border-radius: 8px;
    color: var(--text-main); padding: 6px 8px; width: 56px; text-align: center; font-family: 'Rajdhani', sans-serif; font-weight: 700;
  }
  .jbr-num-input:focus { outline: none; border-color: var(--gold); }
  @keyframes jbr-spin { to { transform: rotate(360deg); } }
  .jbr-spin { animation: jbr-spin 0.9s linear infinite; }
  @media (prefers-reduced-motion: reduce) { .jbr-spin { animation: none; } }
  .jbr-chip {
    border-radius: 999px; padding: 6px 12px; display: inline-flex; align-items: center; gap: 6px;
    border: 1px solid var(--border); background: var(--panel-bg); cursor: pointer;
    transition: border-color .2s ease, background .2s ease, transform .1s ease;
  }
  .jbr-chip:active { transform: scale(0.97); }
  .jbr-chip:focus-visible { outline: 2px solid var(--gold-bright); outline-offset: 2px; }
  .jbr-option {
    border-radius: 10px; border: 1px solid var(--border); background: var(--card-bg);
    padding: 8px 12px; display: flex; align-items: center; gap: 8px;
  }
  .jbr-option.correct { border-color: var(--chem); background: rgba(57,255,136,0.06); }
  .jbr-divider { height: 2px; background: linear-gradient(90deg, var(--gold), var(--xp), var(--maths), transparent); border-radius: 2px; }
  .jbr-xp-track { background: var(--panel-bg); border: 1px solid var(--border); border-radius: 999px; overflow: hidden; }
  .jbr-xp-fill { background: linear-gradient(90deg, var(--xp), var(--gold-bright)); height: 100%; border-radius: 999px; transition: width .5s ease; }
  .jbr-track { background: var(--panel-bg); border: 1px solid var(--border); border-radius: 999px; overflow: hidden; }
  .jbr-fill { height: 100%; border-radius: 999px; transition: width .6s ease; }
  .jbr-tile:active { transform: scale(0.97); }
  .jbr-tile:focus-visible { outline: 2px solid var(--gold-bright); outline-offset: 2px; }
  .jbr-tile.disabled { opacity: 0.45; cursor: not-allowed; }
  .jbr-tile.disabled:hover { border-color: var(--border); box-shadow: none; transform: none; }
  .jbr-icon-btn {
    display: inline-flex; align-items: center; justify-content: center;
    border-radius: 10px; border: 1px solid var(--border); background: var(--panel-bg);
    transition: border-color .2s ease, background .2s ease, transform .1s ease;
  }
  .jbr-icon-btn:active { transform: scale(0.94); }
  .jbr-icon-btn:focus-visible { outline: 2px solid var(--gold-bright); outline-offset: 2px; }
  .jbr-icon-btn.active { border-color: var(--gold-bright); background: rgba(255,207,61,0.08); }
  .jbr-group-header {
    display: flex; align-items: center; justify-content: space-between; width: 100%;
    padding: 10px 4px; text-align: left; cursor: pointer;
  }
  @keyframes jbr-pulse { 0%,100% { opacity: 1; } 50% { opacity: .55; } }
  @keyframes jbr-shimmer { 0% { background-position: -200% 0; } 100% { background-position: 200% 0; } }
  @keyframes jbr-card-in { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }
  @keyframes jbr-glow-pulse { 0%,100% { box-shadow: 0 0 0 0 transparent; } 50% { box-shadow: 0 0 18px -4px var(--tier-color, var(--gold)); } }
  .jbr-skeleton {
    background: linear-gradient(90deg, var(--panel-bg) 25%, #241634 50%, var(--panel-bg) 75%);
    background-size: 200% 100%; animation: jbr-shimmer 1.6s infinite;
    border-radius: 8px;
  }
  .jbr-card-in { animation: jbr-card-in .35s ease both; }
  .jbr-achieve-unlocked { border-color: var(--tier-color, var(--gold)) !important; animation: jbr-glow-pulse 2.8s ease-in-out infinite; }
  .jbr-unlock-icon { animation: jbr-glow-pulse 2.8s ease-in-out infinite; }
  @media (prefers-reduced-motion: reduce) {
    .jbr-pulse, .jbr-skeleton, .jbr-card-in, .jbr-achieve-unlocked, .jbr-unlock-icon { animation: none; }
  }
`;

/* ============================================================
   SUBJECT METADATA — color/icon/label per subject. Used by
   QuestionPapersPreview and OverallAnalytics; Dashboard doesn't
   need it today but can pull from here if it ever shows
   subject-level stats.
   ============================================================ */
export const SUBJECT_META = {
  physics: { label: 'Physics', color: 'var(--phys)', icon: Atom },
  chemistry: { label: 'Chemistry', color: 'var(--chem)', icon: FlaskConical },
  maths: { label: 'Maths', color: 'var(--maths)', icon: Sigma },
};

/* ============================================================
   TIER METADATA — used by Achievements screen. Centralised here
   so badge colors stay in sync with the design palette; adding a
   new tier means one change in this file, not across every component.
   ============================================================ */
export const TIER = {
  bronze:  { label: 'Bronze',  color: '#cd7f32', glow: 'rgba(205,127,50,0.35)'  },
  silver:  { label: 'Silver',  color: '#c9ccd1', glow: 'rgba(201,204,209,0.35)' },
  gold:    { label: 'Gold',    color: '#ffcf3d', glow: 'rgba(255,207,61,0.35)'  },
  diamond: { label: 'Diamond', color: '#22d3ee', glow: 'rgba(34,211,238,0.35)'  },
};

// Sort order: highest prestige first so diamond badges appear before bronze in lists.
export const TIER_ORDER = ['diamond', 'gold', 'silver', 'bronze'];

// Per-exam accent colors — kept here so FilterTabs and AchievementCard
// both reference the same color without the two drifting apart.
export const EXAM_COLOR = {
  neet: 'var(--chem)',  // green — biology/life sciences
  jee:  'var(--phys)',  // cyan  — engineering/physics
};
