// geminiPipeline.js
// THE SEAM between Dev 2 (UploadScreen) and Dev 1 (geminiService).
//
// Why this file exists instead of calling geminiService directly from
// UploadScreen: UploadScreen is UI — it knows about files, progress bars,
// and status states. geminiService is AI — it knows about Gemini API.
// Neither should know about the other's shape. This file is the adapter:
//   File → base64 → Gemini → parse into QuestionPapersPreview's schema
//   → update localStorage paper → optionally persist to Firestore.
//
// All three steps are individually catch-able so a Gemini failure doesn't
// lose the already-saved paper, a Firestore failure doesn't lose the
// already-parsed questions, and each failure surfaces a user-facing message
// instead of an opaque "something went wrong".

import { parseTestPaperWithGemini } from './geminiService';
import { FIREBASE_CONFIGURED } from './firebase';

const UPLOADED_PAPERS_KEY = 'jbr_uploaded_papers_v1';

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

/** Reads a File as base64 (no data: URI prefix — Gemini wants the raw bytes). */
function fileToBase64(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload  = () => resolve(reader.result.split(',')[1]);
    reader.onerror = () => reject(new Error('Could not read the file. Is it corrupted?'));
    reader.readAsDataURL(file);
  });
}

/** Patches a paper already saved to localStorage by id. Silent on storage errors. */
function patchLocalPaper(paperId, updates) {
  try {
    const raw     = localStorage.getItem(UPLOADED_PAPERS_KEY);
    const papers  = raw ? JSON.parse(raw) : [];
    const patched = papers.map((p) => p.id === paperId ? { ...p, ...updates } : p);
    localStorage.setItem(UPLOADED_PAPERS_KEY, JSON.stringify(patched));
  } catch {
    // Private browsing or quota exceeded — the updated questions survive in
    // memory for this session via React state in QuestionPapersPreview.
  }
}

/**
 * Maps Gemini's flat question array into the nested subject map that
 * QuestionPapersPreview expects: { physics: [...], chemistry: [...], maths: [...] }.
 *
 * Gemini returns a `subject` field on each question OR a top-level `subject`
 * on the paper. We handle both shapes here so the schema can evolve without
 * changing the UI layer.
 */
function buildSubjectMap(questions, paperSubject) {
  const KNOWN = ['physics', 'chemistry', 'maths'];
  const map = {};

  questions.forEach((q) => {
    const raw = (q.subject || paperSubject || 'physics').toLowerCase();
    // Fuzzy match: "Physics" → "physics", "Math" → "maths", etc.
    const key = KNOWN.find((k) => raw.includes(k.replace('maths', 'math'))) || KNOWN[0];
    if (!map[key]) map[key] = [];
    map[key].push({
      number:       q.questionNumber,
      chapter:      q.chapter    || 'Uncategorized',
      topic:        q.topic      || '',
      difficulty:   q.difficulty || 'Medium',
      text:         q.questionText,
      options:      q.options    || [],
      correctIndex: q.options?.findIndex((o) => o === q.correctAnswer) ?? 0,
    });
  });

  // Ensure every subject in the map is sorted by question number
  Object.values(map).forEach((arr) => arr.sort((a, b) => a.number - b.number));
  return map;
}

// ---------------------------------------------------------------------------
// Main entry point
// Called by UploadScreen after saveUploadedPaper() succeeds.
//
// @param localPaperId  — the id of the paper already saved in localStorage
// @param file          — the File object from the upload form
// @param mimeType      — 'application/pdf' | 'image/jpeg' | etc.
// @param onProgress    — optional (message: string, percent: number) => void
// @returns { questionCount } on success, throws with a user-facing string on failure
// ---------------------------------------------------------------------------
export async function runUploadPipeline(localPaperId, file, mimeType, { onProgress } = {}) {
  // ── Step 1: Read file ───────────────────────────────────────────────────
  onProgress?.('Reading file…', 15);
  let base64;
  try {
    base64 = await fileToBase64(file);
  } catch (err) {
    patchLocalPaper(localPaperId, { status: 'error', errorMessage: err.message });
    throw err.message;
  }

  // ── Step 2: Gemini parse ────────────────────────────────────────────────
  onProgress?.('Sending to Gemini AI — this takes ~15 s…', 35);
  let geminiOutput;
  try {
    geminiOutput = await parseTestPaperWithGemini(base64, mimeType);
  } catch (err) {
    const msg = err.message?.includes('VITE_GEMINI_API_KEY')
      ? 'Add VITE_GEMINI_API_KEY to your .env to enable AI parsing.'
      : `AI parsing failed: ${err.message}`;
    patchLocalPaper(localPaperId, { status: 'error', errorMessage: msg });
    throw msg;
  }

  if (!geminiOutput?.questions?.length) {
    const msg = 'No questions found — try a clearer PDF or image.';
    patchLocalPaper(localPaperId, { status: 'error', errorMessage: msg });
    throw msg;
  }

  // ── Step 3: Transform output ────────────────────────────────────────────
  onProgress?.('Parsing questions…', 65);
  const subjects = buildSubjectMap(geminiOutput.questions, geminiOutput.subject);

  // ── Step 4: Update localStorage paper ──────────────────────────────────
  onProgress?.('Saving…', 80);
  patchLocalPaper(localPaperId, {
    status:        'ready',
    subjects,
    questionCount: geminiOutput.questions.length,
    // Overwrite the user-entered title only if Gemini found a better one
    ...(geminiOutput.testTitle ? { title: geminiOutput.testTitle } : {}),
  });

  // ── Step 5: Firestore ingest (optional, non-fatal) ──────────────────────
  if (FIREBASE_CONFIGURED) {
    onProgress?.('Syncing to cloud…', 90);
    try {
      // Lazy import so the Firebase SDK bundle is only loaded when Firebase
      // is actually configured — keeps the initial bundle smaller for the
      // common dev-without-Firebase case.
      const { ingestTestPaperFromGemini } = await import('./dev3-backend/ingestion.js');
      await ingestTestPaperFromGemini(geminiOutput);
    } catch (err) {
      // Non-fatal: questions are already saved to localStorage. The paper
      // just won't appear for other devices / sessions until Firestore syncs.
      console.warn('[pipeline] Firestore ingest failed (paper saved locally):', err);
    }
  }

  onProgress?.('Done!', 100);
  return { questionCount: geminiOutput.questions.length };
}
