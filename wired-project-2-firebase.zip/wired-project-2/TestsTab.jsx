import React, { useState, useEffect, useCallback, useMemo, memo, useRef } from 'react';
import {
  FileText, Atom, FlaskConical, Sigma, ChevronRight, ChevronLeft,
  Search, Calendar, Target, CheckCircle2, XCircle,
  Sparkles, AlertTriangle, RefreshCw, Trash2, Pencil, Check, X,
  ExternalLink, BarChart3, TrendingUp, 
  SortAsc,
} from 'lucide-react';
import { getTests, saveTests } from './testsStorage';

/* ============================================================
   THEME
   ============================================================ */
const THEME = `
  @import url('https://fonts.googleapis.com/css2?family=Orbitron:wght@500;700;900&family=Rajdhani:wght@500;600;700&display=swap');
  .jbr-root {
    --bg-color: #0a0710; --bg-glow: #2a0f3a; --card-bg: #130b1a; --panel-bg: #170d20;
    --gold: #ff6a00; --gold-bright: #ffcf3d; --xp: #ff3d7d;
    --phys: #22d3ee; --chem: #39ff88; --maths: #c77dff; --danger: #ff1a5e;
    --text-main: #f3ecff; --text-muted: #9a83b0; --border: #3a2452;
    font-family: 'Roboto', sans-serif;
    background: var(--bg-color); color: var(--text-main); min-height: 100vh;
  }
  .jbr-display  { font-family: 'Orbitron', sans-serif; letter-spacing: 1.5px; }
  .jbr-label    { font-family: 'Rajdhani', sans-serif; font-weight: 600; letter-spacing: 1px; }
  .jbr-gradient-text {
    background: linear-gradient(90deg, var(--gold-bright), var(--xp), var(--maths));
    -webkit-background-clip: text; background-clip: text; color: transparent;
  }
  .jbr-glow-bg  { background: radial-gradient(ellipse 80% 50% at 50% -10%, var(--bg-glow), transparent), var(--bg-color); }
  .jbr-card     { background: var(--card-bg); border: 1px solid var(--border); border-radius: 16px; transition: box-shadow .25s ease, border-color .25s ease; }
  .jbr-card:hover { border-color: var(--gold); box-shadow: 0 0 24px -6px rgba(255,106,0,.35); }
  .jbr-panel    { background: var(--panel-bg); border: 1px solid var(--border); border-radius: 12px; }
  .jbr-input    { background: var(--panel-bg); border: 1px solid var(--border); border-radius: 10px; color: var(--text-main); padding: 10px 14px; font-family: 'Roboto', sans-serif; width: 100%; transition: border-color .2s ease; }
  .jbr-input:focus { outline: none; border-color: var(--gold); }
  .jbr-input::placeholder { color: var(--text-muted); }
  .jbr-inline-input { background: transparent; border: none; border-bottom: 1px solid var(--gold); color: var(--text-main); font-family: 'Orbitron', sans-serif; font-size: 1rem; letter-spacing: 1.5px; outline: none; min-width: 0; flex: 1; padding-bottom: 2px; }
  .jbr-divider  { height: 2px; background: linear-gradient(90deg, var(--gold), var(--xp), var(--maths), transparent); border-radius: 2px; }
  .jbr-track    { background: var(--panel-bg); border-radius: 999px; overflow: hidden; }
  .jbr-fill     { height: 100%; border-radius: 999px; transition: width .6s ease; }
  .jbr-chip-filter { border-radius: 999px; padding: 5px 12px; border: 1px solid var(--border); background: var(--panel-bg); cursor: pointer; transition: border-color .2s, background .2s, transform .1s; font-family: 'Rajdhani', sans-serif; font-weight: 600; letter-spacing: 1px; font-size: 11px; }
  .jbr-chip-filter:active { transform: scale(0.96); }
  .jbr-icon-btn { display: inline-flex; align-items: center; justify-content: center; border-radius: 8px; border: 1px solid var(--border); background: var(--panel-bg); transition: border-color .2s, background .2s, transform .1s; }
  .jbr-icon-btn:active  { transform: scale(0.93); }
  .jbr-icon-btn:focus-visible { outline: 2px solid var(--gold-bright); outline-offset: 2px; }
  .jbr-icon-btn.danger:hover { border-color: var(--danger); background: rgba(255,26,94,0.08); }
  .jbr-icon-btn.confirm:hover { border-color: var(--chem); background: rgba(57,255,136,0.08); }
  .jbr-heatcell { border-radius: 8px; display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 2px; padding: 6px 4px; border: 1px solid; }
  @keyframes jbr-shimmer { 0% { background-position: -200% 0; } 100% { background-position: 200% 0; } }
  .jbr-skeleton { background: linear-gradient(90deg, var(--panel-bg) 25%, #241634 50%, var(--panel-bg) 75%); background-size: 200% 100%; animation: jbr-shimmer 1.6s infinite; border-radius: 8px; }
  @media (prefers-reduced-motion: reduce) { .jbr-skeleton { animation: none; } }
  @keyframes jbr-toast-in { from { transform: translateX(-50%) translateY(16px); opacity: 0; } to { transform: translateX(-50%) translateY(0); opacity: 1; } }
  .jbr-toast { animation: jbr-toast-in .2s ease; }
  @keyframes jbr-countdown { from { width: 100%; } to { width: 0%; } }
  .jbr-countdown { animation: jbr-countdown 5s linear forwards; }
  @keyframes jbr-saved { 0%,100% { opacity:0; transform: translateY(4px); } 20%,80% { opacity:1; transform: translateY(0); } }
  .jbr-saved { animation: jbr-saved 1.5s ease forwards; }
`;

/* ============================================================
   CONSTANTS
   ============================================================ */
const SUBJECT_META = {
  physics:   { label: 'Physics',   color: 'var(--phys)', icon: Atom },
  chemistry: { label: 'Chemistry', color: 'var(--chem)', icon: FlaskConical },
  maths:     { label: 'Maths',     color: 'var(--maths)', icon: Sigma },
};
const SUBJECT_ORDER = ['physics', 'chemistry', 'maths'];
const DIFFICULTIES  = ['Easy', 'Moderate', 'Tough'];

/* ============================================================
   DATA HOOK
   Reads from testsStorage (localStorage). Swap for a Firestore
   read once Dev 3's backend is live — the { data, isLoading,
   error } shape stays the same; nothing below needs to change.
   ============================================================ */
function useTestsData() {
  const [state, setState] = useState({ data: null, isLoading: true, error: null });
  const fetchData = useCallback(() => {
    setState({ data: null, isLoading: true, error: null });
    const t = setTimeout(() => setState({ data: getTests(), isLoading: false, error: null }), 300);
    return () => clearTimeout(t);
  }, []);
  useEffect(() => fetchData(), [fetchData]);
  return { ...state, retry: fetchData };
}

/* ============================================================
   HELPERS
   ============================================================ */
const scorePct    = (t) => Math.round((t.totalScore / t.maxScore) * 100);
const scoreColor  = (p) => p >= 75 ? 'var(--chem)' : p >= 50 ? 'var(--gold-bright)' : 'var(--danger)';
const uniqueSubjects = (tb) => SUBJECT_ORDER.filter((s) => tb.some((r) => r.subject === s));
const formatDate  = (d) => new Date(d).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' });
const accuracy    = (c, i) => (c + i) > 0 ? Math.round((c / (c + i)) * 100) : 0;

function cellStyle(pct) {
  if (pct === null) return { bg: 'rgba(58,36,82,0.4)', border: 'var(--border)', text: 'var(--text-muted)' };
  if (pct >= 70)    return { bg: 'rgba(57,255,136,0.10)', border: 'rgba(57,255,136,0.35)', text: 'var(--chem)' };
  if (pct >= 40)    return { bg: 'rgba(255,207,61,0.10)', border: 'rgba(255,207,61,0.35)', text: 'var(--gold-bright)' };
  return               { bg: 'rgba(255,26,94,0.10)',  border: 'rgba(255,26,94,0.35)',  text: 'var(--danger)' };
}

/* ============================================================
   PRIMITIVES
   ============================================================ */
const ScoreBadge = memo(function ScoreBadge({ pct, size = 'md' }) {
  const color = scoreColor(pct);
  return (
    <div
      className={`jbr-label ${size === 'lg' ? 'text-3xl' : 'text-sm'} font-bold shrink-0 rounded-xl flex items-center justify-center`}
      style={{
        color,
        background: `color-mix(in srgb, ${color} 10%, var(--panel-bg))`,
        border: `1px solid color-mix(in srgb, ${color} 30%, var(--border))`,
        minWidth: size === 'lg' ? 72 : 52,
        height: size === 'lg' ? 72 : 40,
        padding: '0 10px',
      }}
    >
      {pct}
    </div>
  );
});

const SubjectTags = memo(function SubjectTags({ subjects }) {
  return (
    <div className="flex gap-1.5 flex-wrap">
      {subjects.map((s) => {
        const meta = SUBJECT_META[s]; const Icon = meta.icon;
        return (
          <span key={s} className="jbr-label text-[10px] px-2 py-0.5 rounded-full flex items-center gap-1"
            style={{ background: 'var(--panel-bg)', border: `1px solid ${meta.color}`, color: meta.color }}>
            <Icon size={10} /> {meta.label}
          </span>
        );
      })}
    </div>
  );
});

/* ---- SVG Ring ---- */
function Ring({ pct, color, size = 72, stroke = 7 }) {
  const r    = (size - stroke * 2) / 2;
  const circ = 2 * Math.PI * r;
  const dash = Math.min(Math.max(pct, 0), 100) / 100 * circ;
  return (
    <svg width={size} height={size} style={{ display: 'block' }}>
      <circle cx={size/2} cy={size/2} r={r} fill="none" stroke="var(--border)" strokeWidth={stroke} />
      <circle cx={size/2} cy={size/2} r={r} fill="none" stroke={color} strokeWidth={stroke}
        strokeDasharray={`${dash} ${circ - dash}`} strokeLinecap="round"
        transform={`rotate(-90 ${size/2} ${size/2})`}
        style={{ transition: 'stroke-dasharray .8s ease' }} />
    </svg>
  );
}

/* ============================================================
   UNDO TOAST
   ============================================================ */
function UndoToast({ title, onUndo, onDismiss }) {
  return (
    <div className="jbr-toast fixed bottom-6 left-1/2 z-50 jbr-card overflow-hidden"
      style={{ transform: 'translateX(-50%)', width: 'min(calc(100vw - 40px), 420px)', borderColor: 'var(--gold)' }}
      role="alert" aria-live="polite">
      <div className="h-0.5 w-full" style={{ background: 'var(--border)' }}>
        <div className="jbr-countdown h-full"
          style={{ background: 'linear-gradient(90deg, var(--gold), var(--xp))', transformOrigin: 'left' }} />
      </div>
      <div className="flex items-center justify-between gap-3 px-4 py-3">
        <p className="text-xs" style={{ color: 'var(--text-main)' }}>
          <span style={{ color: 'var(--text-muted)' }}>Deleted </span>
          <span className="jbr-label">"{title}"</span>
        </p>
        <div className="flex items-center gap-2 shrink-0">
          <button onClick={onUndo} className="jbr-label text-xs px-3 py-1.5 rounded-lg"
            style={{ background: 'var(--gold)', color: '#160a00' }}>UNDO</button>
          <button onClick={onDismiss} className="jbr-icon-btn" style={{ width: 28, height: 28 }} aria-label="Dismiss">
            <X size={13} color="var(--text-muted)" />
          </button>
        </div>
      </div>
    </div>
  );
}

/* ============================================================
   TEST CARD
   ============================================================ */
const TestCard = memo(function TestCard({ test, onSelect, onDelete, onRename }) {
  const [editing,   setEditing]   = useState(false);
  const [draftName, setDraftName] = useState(test.testTitle);
  const [justSaved, setJustSaved] = useState(false);
  const inputRef = useRef(null);
  const pct      = scorePct(test);
  const subjects  = uniqueSubjects(test.topicBreakdown);
  const totalCorrect  = test.topicBreakdown.reduce((s, r) => s + r.correct, 0);
  const totalAttempted = test.topicBreakdown.reduce((s, r) => s + r.correct + r.incorrect, 0);

  const startEdit = (e) => {
    e.stopPropagation();
    setDraftName(test.testTitle);
    setEditing(true);
    setTimeout(() => inputRef.current?.focus(), 0);
  };

  const commitEdit = () => {
    const trimmed = draftName.trim();
    if (trimmed && trimmed !== test.testTitle) {
      onRename(test.id, trimmed);
      setJustSaved(true);
      setTimeout(() => setJustSaved(false), 1500);
    }
    setEditing(false);
  };

  const cancelEdit = () => { setDraftName(test.testTitle); setEditing(false); };
  const handleKeyDown = (e) => { if (e.key === 'Enter') commitEdit(); if (e.key === 'Escape') cancelEdit(); };

  return (
    <div className="jbr-card p-4 flex flex-col gap-3">
      {/* title row */}
      <div className="flex items-start justify-between gap-3">
        <div className="flex items-center gap-2 min-w-0 flex-1">
          {editing ? (
            <>
              <input ref={inputRef} className="jbr-inline-input" value={draftName}
                onChange={(e) => setDraftName(e.target.value)} onBlur={commitEdit}
                onKeyDown={handleKeyDown} onClick={(e) => e.stopPropagation()} />
              <button className="jbr-icon-btn confirm shrink-0" style={{ width: 28, height: 28 }}
                onClick={(e) => { e.stopPropagation(); commitEdit(); }}><Check size={13} color="var(--chem)" /></button>
              <button className="jbr-icon-btn shrink-0" style={{ width: 28, height: 28 }}
                onClick={(e) => { e.stopPropagation(); cancelEdit(); }}><X size={13} color="var(--text-muted)" /></button>
            </>
          ) : (
            <>
              <button className="jbr-display text-sm font-bold text-left truncate flex-1 min-w-0"
                style={{ color: 'var(--text-main)' }} onClick={() => onSelect(test.id)}>
                {test.testTitle}
              </button>
              {justSaved && (
                <span className="jbr-saved jbr-label text-[10px] shrink-0 flex items-center gap-1"
                  style={{ color: 'var(--chem)' }}>
                  <Check size={10} /> Saved
                </span>
              )}
              <button className="jbr-icon-btn shrink-0" style={{ width: 28, height: 28 }}
                onClick={startEdit} aria-label={`Rename ${test.testTitle}`}>
                <Pencil size={12} color="var(--text-muted)" />
              </button>
            </>
          )}
        </div>
        <ScoreBadge pct={pct} />
      </div>

      {/* meta */}
      <div className="flex items-center gap-3 flex-wrap">
        <span className="text-xs flex items-center gap-1" style={{ color: 'var(--text-muted)' }}>
          <Calendar size={11} /> {formatDate(test.date)}
        </span>
        <span className="text-xs flex items-center gap-1" style={{ color: 'var(--text-muted)' }}>
          <CheckCircle2 size={11} color="var(--chem)" />
          <span style={{ color: 'var(--chem)' }}>{totalCorrect}/{totalAttempted}</span> correct
        </span>
        {test.paperId && (
          <span className="jbr-label text-[10px] px-2 py-0.5 rounded-full"
            style={{ background: 'var(--panel-bg)', border: '1px solid var(--gold)', color: 'var(--gold-bright)' }}>
            PAPER LINKED
          </span>
        )}
      </div>

      <SubjectTags subjects={subjects} />

      {/* AI snippet */}
      <p className="text-xs line-clamp-2 leading-relaxed" style={{ color: 'var(--text-muted)' }}>
        <Sparkles size={10} color="var(--gold-bright)" style={{ display: 'inline', marginRight: 4, verticalAlign: 'middle' }} />
        {test.aiFeedback}
      </p>

      <div className="jbr-divider" />
      <div className="flex items-center justify-between">
        <button className="jbr-icon-btn danger" style={{ width: 32, height: 32 }}
          onClick={(e) => { e.stopPropagation(); onDelete(test.id); }}>
          <Trash2 size={14} color="var(--danger)" />
        </button>
        <button className="jbr-label text-xs flex items-center gap-1.5 px-3 py-1.5 rounded-lg"
          style={{ background: 'var(--panel-bg)', border: '1px solid var(--border)', color: 'var(--text-muted)' }}
          onClick={() => onSelect(test.id)}>
          VIEW ANALYSIS <ChevronRight size={13} />
        </button>
      </div>
    </div>
  );
});

/* ============================================================
   DETAIL SECTION — SUBJECT PERFORMANCE RINGS
   ============================================================ */
function SubjectRings({ topicBreakdown }) {
  const data = useMemo(() => SUBJECT_ORDER.map((s) => {
    const rows = topicBreakdown.filter((r) => r.subject === s);
    if (!rows.length) return null;
    const c = rows.reduce((a, r) => a + r.correct, 0);
    const i = rows.reduce((a, r) => a + r.incorrect, 0);
    const u = rows.reduce((a, r) => a + r.unattempted, 0);
    const acc = accuracy(c, i);
    return { s, c, i, u, acc, total: c + i + u };
  }).filter(Boolean), [topicBreakdown]);

  return (
    <div className="jbr-card p-5">
      <p className="jbr-label text-xs mb-5" style={{ color: 'var(--text-muted)' }}>SUBJECT OVERVIEW</p>
      <div className="grid grid-cols-3 gap-4">
        {data.map(({ s, c, i, u, acc, total }) => {
          const meta = SUBJECT_META[s]; const Icon = meta.icon;
          return (
            <div key={s} className="flex flex-col items-center gap-2">
              {/* ring + center label */}
              <div className="relative">
                <Ring pct={acc} color={meta.color} size={72} stroke={6} />
                <div className="absolute inset-0 flex items-center justify-center">
                  <span className="jbr-display text-sm font-bold" style={{ color: meta.color }}>{acc}%</span>
                </div>
              </div>
              {/* subject name */}
              <div className="flex items-center gap-1">
                <Icon size={11} color={meta.color} />
                <span className="jbr-label text-[10px]" style={{ color: meta.color }}>{meta.label}</span>
              </div>
              {/* counts */}
              <div className="flex gap-2">
                <span className="text-[10px]" style={{ color: 'var(--chem)' }}>{c}✓</span>
                <span className="text-[10px]" style={{ color: 'var(--danger)' }}>{i}✗</span>
                <span className="text-[10px]" style={{ color: 'var(--text-muted)' }}>{u}–</span>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

/* ============================================================
   DETAIL SECTION — SCORE POTENTIAL
   ============================================================ */
function ScorePotential({ test }) {
  const totalCorrect    = test.topicBreakdown.reduce((s, r) => s + r.correct, 0);
  const totalIncorrect  = test.topicBreakdown.reduce((s, r) => s + r.incorrect, 0);
  const totalUnattempted = test.topicBreakdown.reduce((s, r) => s + r.unattempted, 0);
  const totalQuestions  = totalCorrect + totalIncorrect + totalUnattempted;
  const totalAttempted  = totalCorrect + totalIncorrect;
  const currentPct      = Math.round((test.totalScore / test.maxScore) * 100);
  const potentialPct    = totalQuestions > 0 ? Math.round((totalAttempted / totalQuestions) * 100) : currentPct;
  const gain            = potentialPct - currentPct;
  const currentColor    = scoreColor(currentPct);

  const subjectPotentials = useMemo(() => SUBJECT_ORDER.map((sk) => {
    const rows = test.topicBreakdown.filter((r) => r.subject === sk);
    if (!rows.length) return null;
    const sc = rows.reduce((a, r) => a + r.correct, 0);
    const si = rows.reduce((a, r) => a + r.incorrect, 0);
    const su = rows.reduce((a, r) => a + r.unattempted, 0);
    const st = sc + si + su;
    const sCurrent  = st > 0 ? Math.round((sc / st) * 100) : 0;
    const sPotential = st > 0 ? Math.round(((sc + si) / st) * 100) : 0;
    return { sk, sCurrent, sPotential, sGain: sPotential - sCurrent, si };
  }).filter(Boolean), [test.topicBreakdown]);

  return (
    <div className="jbr-card p-5 space-y-5">
      <p className="jbr-label text-xs" style={{ color: 'var(--text-muted)' }}>SCORE POTENTIAL</p>
      <div className="flex items-center gap-4">
        <div className="flex-1 space-y-1.5">
          <p className="jbr-label text-[10px]" style={{ color: 'var(--text-muted)' }}>CURRENT</p>
          <p className="jbr-display text-3xl font-bold" style={{ color: currentColor }}>{currentPct}%</p>
          <div className="jbr-track h-2"><div className="jbr-fill" style={{ width: `${currentPct}%`, background: currentColor }} /></div>
        </div>
        <div className="flex flex-col items-center gap-1 shrink-0 px-1">
          <TrendingUp size={20} color="var(--gold-bright)" />
          <span className="jbr-label text-xs" style={{ color: 'var(--gold-bright)' }}>{gain > 0 ? `+${gain}pp` : 'MAX'}</span>
        </div>
        <div className="flex-1 space-y-1.5">
          <p className="jbr-label text-[10px]" style={{ color: 'var(--text-muted)' }}>100% ACCURACY</p>
          <p className="jbr-display text-3xl font-bold" style={{ color: 'var(--chem)' }}>{potentialPct}%</p>
          <div className="jbr-track h-2"><div className="jbr-fill" style={{ width: `${potentialPct}%`, background: 'var(--chem)' }} /></div>
        </div>
      </div>
      <div className="jbr-panel px-4 py-3">
        <p className="text-xs leading-relaxed" style={{ color: 'var(--text-muted)' }}>
          {totalIncorrect === 0
            ? <>Perfect accuracy on everything you attempted.</>
            : <><span style={{ color: 'var(--danger)' }}>{totalIncorrect} wrong answer{totalIncorrect !== 1 ? 's' : ''}</span> are
                the gap between <span style={{ color: currentColor }}>{currentPct}%</span> and{' '}
                <span style={{ color: 'var(--chem)' }}>{potentialPct}%</span>. Fix them and gain{' '}
                <span style={{ color: 'var(--gold-bright)' }}>+{gain} points</span> without attempting anything extra.</>}
        </p>
      </div>
      <div className="space-y-3">
        {subjectPotentials.map(({ sk, sCurrent, sPotential, sGain }) => {
          const meta = SUBJECT_META[sk]; const Icon = meta.icon;
          return (
            <div key={sk}>
              <div className="flex items-center justify-between mb-1.5">
                <span className="jbr-label text-[10px] flex items-center gap-1.5" style={{ color: meta.color }}>
                  <Icon size={11} /> {meta.label}
                </span>
                <span className="jbr-label text-[10px]" style={{ color: 'var(--text-muted)' }}>
                  {sCurrent}% → <span style={{ color: 'var(--chem)' }}>{sPotential}%</span>
                  {sGain > 0 && <span style={{ color: 'var(--gold-bright)' }}> (+{sGain}pp)</span>}
                </span>
              </div>
              <div className="jbr-track h-2 relative">
                <div className="absolute inset-y-0 left-0 rounded-full opacity-20"
                  style={{ width: `${sPotential}%`, background: 'var(--chem)' }} />
                <div className="jbr-fill relative" style={{ width: `${sCurrent}%`, background: meta.color }} />
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

/* ============================================================
   DETAIL SECTION — DIFFICULTY HEATMAP
   3×3 grid: rows = difficulty, cols = subject
   Each cell shows accuracy % color-coded green/yellow/red
   ============================================================ */
function DifficultyHeatmap({ difficultyBreakdown }) {
  const grid = useMemo(() => {
    return DIFFICULTIES.map((diff) => ({
      diff,
      cells: SUBJECT_ORDER.map((s) => {
        const row = difficultyBreakdown.find((r) => r.subject === s && r.difficulty === diff);
        if (!row) return null;
        const acc = accuracy(row.correct, row.incorrect);
        const total = row.correct + row.incorrect + row.unattempted;
        return { acc, total, correct: row.correct, incorrect: row.incorrect, unattempted: row.unattempted };
      }),
    }));
  }, [difficultyBreakdown]);

  return (
    <div className="jbr-card p-5">
      <p className="jbr-label text-xs mb-5" style={{ color: 'var(--text-muted)' }}>DIFFICULTY HEATMAP</p>

      {/* column headers */}
      <div className="grid gap-2" style={{ gridTemplateColumns: '56px repeat(3, 1fr)' }}>
        <div />
        {SUBJECT_ORDER.map((s) => {
          const meta = SUBJECT_META[s]; const Icon = meta.icon;
          return (
            <div key={s} className="flex flex-col items-center gap-1">
              <Icon size={13} color={meta.color} />
              <span className="jbr-label text-[10px] text-center" style={{ color: meta.color }}>{meta.label}</span>
            </div>
          );
        })}

        {/* rows */}
        {grid.map(({ diff, cells }) => (
          <React.Fragment key={diff}>
            <div className="flex items-center">
              <span className="jbr-label text-[10px]" style={{ color: 'var(--text-muted)' }}>{diff}</span>
            </div>
            {cells.map((cell, idx) => {
              const style = cellStyle(cell ? cell.acc : null);
              return (
                <div key={idx} className="jbr-heatcell"
                  style={{ background: style.bg, borderColor: style.border, minHeight: 52 }}
                  title={cell ? `${cell.correct}✓ ${cell.incorrect}✗ ${cell.unattempted}–` : 'No data'}>
                  {cell ? (
                    <>
                      <span className="jbr-display text-sm font-bold" style={{ color: style.text }}>{cell.acc}%</span>
                      <span className="jbr-label text-[9px]" style={{ color: 'var(--text-muted)' }}>{cell.total}q</span>
                    </>
                  ) : (
                    <span className="jbr-label text-[9px]" style={{ color: 'var(--text-muted)' }}>—</span>
                  )}
                </div>
              );
            })}
          </React.Fragment>
        ))}
      </div>

      {/* legend */}
      <div className="flex gap-4 mt-4">
        {[['rgba(57,255,136,0.25)', '≥70% Strong'], ['rgba(255,207,61,0.25)', '40–69% Mid'], ['rgba(255,26,94,0.2)', '<40% Weak']].map(([bg, label]) => (
          <span key={label} className="jbr-label text-[10px] flex items-center gap-1.5" style={{ color: 'var(--text-muted)' }}>
            <span style={{ width: 10, height: 10, borderRadius: 3, background: bg, display: 'inline-block', border: '1px solid rgba(255,255,255,0.1)' }} />
            {label}
          </span>
        ))}
      </div>
    </div>
  );
}

/* ============================================================
   DETAIL SECTION — CHAPTER BREAKDOWN (vertical bars)
   ============================================================ */
function ChapterBreakdown({ topicBreakdown }) {
  const bySubject = useMemo(() => {
    const map = new Map();
    SUBJECT_ORDER.forEach((s) => {
      const rows = topicBreakdown.filter((r) => r.subject === s);
      if (rows.length > 0) map.set(s, rows);
    });
    return map;
  }, [topicBreakdown]);

  const BAR_MAX_H = 88;

  return (
    <div className="jbr-card p-5 space-y-6">
      <p className="jbr-label text-xs" style={{ color: 'var(--text-muted)' }}>CHAPTER BREAKDOWN</p>
      {Array.from(bySubject.entries()).map(([subjectKey, rows]) => {
        const meta = SUBJECT_META[subjectKey]; const Icon = meta.icon;
        const maxVal = Math.max(1, ...rows.flatMap((r) => [r.correct, r.incorrect, r.unattempted]));
        return (
          <div key={subjectKey}>
            <div className="flex items-center gap-2 mb-4">
              <Icon size={13} color={meta.color} />
              <span className="jbr-label text-xs" style={{ color: meta.color }}>{meta.label}</span>
            </div>
            <div className="overflow-x-auto pb-1">
              <div className="flex items-end gap-5 min-w-max px-1" style={{ height: BAR_MAX_H + 52 }}>
                {rows.map((row) => (
                  <div key={row.chapter} className="flex flex-col items-center gap-2">
                    <div className="flex items-end gap-1" style={{ height: BAR_MAX_H }}>
                      {[
                        { val: row.correct,     color: 'var(--chem)',       label: 'C' },
                        { val: row.incorrect,   color: 'var(--danger)',     label: 'I' },
                        { val: row.unattempted, color: 'var(--text-muted)', label: 'U' },
                      ].map(({ val, color, label }) => {
                        const h = val > 0 ? Math.max(Math.round((val / maxVal) * BAR_MAX_H), 8) : 0;
                        return (
                          <div key={label} className="flex flex-col items-center justify-end gap-0.5" style={{ height: BAR_MAX_H }}>
                            <span className="jbr-label text-[10px]" style={{ color: val > 0 ? color : 'transparent', minHeight: 14 }}>
                              {val > 0 ? val : ''}
                            </span>
                            <div style={{ width: 14, height: h, background: val > 0 ? color : 'var(--border)', borderRadius: '3px 3px 0 0', opacity: val > 0 ? 1 : 0.25, transition: 'height .5s ease' }}
                              title={`${label === 'C' ? 'Correct' : label === 'I' ? 'Incorrect' : 'Unattempted'}: ${val}`} />
                          </div>
                        );
                      })}
                    </div>
                    <div style={{ width: 54, height: 1, background: 'var(--border)' }} />
                    <span className="text-[10px] text-center leading-tight" style={{ color: 'var(--text-muted)', maxWidth: 64 }}
                      title={row.chapter}>
                      {row.chapter.length > 14 ? row.chapter.slice(0, 13) + '…' : row.chapter}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        );
      })}
      <div className="flex items-center gap-4">
        {[['var(--chem)', 'Correct'], ['var(--danger)', 'Incorrect'], ['var(--text-muted)', 'Unattempted']].map(([color, label]) => (
          <span key={label} className="jbr-label text-[10px] flex items-center gap-1.5" style={{ color: 'var(--text-muted)' }}>
            <span style={{ width: 8, height: 8, borderRadius: 2, background: color, display: 'inline-block' }} /> {label}
          </span>
        ))}
      </div>
    </div>
  );
}

/* ============================================================
   DETAIL SECTION — CROSS-TEST CHAPTER COMPARISON
   For each chapter in this test, shows accuracy across every
   test where that chapter appeared — as a mini sparkline row.
   ============================================================ */
function CrossChapterComparison({ currentTest, allTests }) {
  const data = useMemo(() => {
    // Build a map: chapterKey → [{ date, testTitle, acc }]
    const map = new Map();

    currentTest.topicBreakdown.forEach((row) => {
      const key = `${row.subject}::${row.chapter}`;
      if (!map.has(key)) map.set(key, { subject: row.subject, chapter: row.chapter, history: [] });
    });

    const sorted = allTests.slice().sort((a, b) => new Date(a.date) - new Date(b.date));
    sorted.forEach((test) => {
      test.topicBreakdown.forEach((row) => {
        const key = `${row.subject}::${row.chapter}`;
        if (!map.has(key)) return;
        const acc = accuracy(row.correct, row.incorrect);
        map.get(key).history.push({
          date: test.date,
          label: new Date(test.date).toLocaleDateString('en-IN', { day: '2-digit', month: 'short' }),
          acc,
          isCurrent: test.id === currentTest.id,
        });
      });
    });

    // Only include chapters that appear in >1 test
    return Array.from(map.values()).filter((d) => d.history.length > 1);
  }, [currentTest, allTests]);

  if (!data.length) {
    return (
      <div className="jbr-card p-5">
        <p className="jbr-label text-xs mb-3" style={{ color: 'var(--text-muted)' }}>CHAPTER PROGRESS</p>
        <p className="text-xs" style={{ color: 'var(--text-muted)' }}>Take more tests with overlapping chapters to see trends here.</p>
      </div>
    );
  }

  const SPARK_W = 120;
  const SPARK_H = 36;

  return (
    <div className="jbr-card p-5 space-y-4">
      <p className="jbr-label text-xs" style={{ color: 'var(--text-muted)' }}>CHAPTER PROGRESS ACROSS TESTS</p>
      <div className="space-y-3">
        {data.map(({ subject, chapter, history }) => {
          const meta     = SUBJECT_META[subject]; const Icon = meta.icon;
          const latest   = history[history.length - 1].acc;
          const first    = history[0].acc;
          const improved = latest - first;
          const maxAcc   = Math.max(...history.map((h) => h.acc), 1);

          // Build SVG polyline points
          const pts = history.map((h, i) => {
            const x = history.length === 1 ? SPARK_W / 2 : (i / (history.length - 1)) * SPARK_W;
            const y = SPARK_H - (h.acc / 100) * SPARK_H;
            return `${x},${y}`;
          }).join(' ');

          return (
            <div key={`${subject}::${chapter}`} className="jbr-panel p-3 flex items-center gap-3">
              {/* subject icon + chapter name */}
              <div className="flex items-center gap-1.5 min-w-0 flex-1">
                <Icon size={11} color={meta.color} className="shrink-0" />
                <span className="text-xs truncate" style={{ color: 'var(--text-main)' }}>{chapter}</span>
              </div>

              {/* sparkline */}
              <svg width={SPARK_W} height={SPARK_H} style={{ flexShrink: 0 }}>
                {/* zero line */}
                <line x1={0} y1={SPARK_H} x2={SPARK_W} y2={SPARK_H} stroke="var(--border)" strokeWidth={1} />
                {/* line */}
                <polyline points={pts} fill="none" stroke={meta.color} strokeWidth={1.5} strokeLinejoin="round" strokeLinecap="round" />
                {/* dots */}
                {history.map((h, i) => {
                  const x = history.length === 1 ? SPARK_W / 2 : (i / (history.length - 1)) * SPARK_W;
                  const y = SPARK_H - (h.acc / 100) * SPARK_H;
                  return (
                    <circle key={i} cx={x} cy={y} r={h.isCurrent ? 4 : 2.5}
                      fill={h.isCurrent ? meta.color : 'var(--card-bg)'}
                      stroke={meta.color} strokeWidth={1.5}>
                      <title>{h.label}: {h.acc}%</title>
                    </circle>
                  );
                })}
              </svg>

              {/* latest acc + delta */}
              <div className="text-right shrink-0">
                <p className="jbr-label text-xs" style={{ color: meta.color }}>{latest}%</p>
                {Math.abs(improved) > 0 && (
                  <p className="jbr-label text-[10px]" style={{ color: improved >= 0 ? 'var(--chem)' : 'var(--danger)' }}>
                    {improved >= 0 ? '+' : ''}{improved}pp
                  </p>
                )}
              </div>
            </div>
          );
        })}
      </div>
      <p className="jbr-label text-[10px]" style={{ color: 'var(--text-muted)' }}>
        Filled dot = this test · open dot = previous tests
      </p>
    </div>
  );
}

/* ============================================================
   DETAIL SECTION — REVISION CHECKLIST
   AI recommendations as persistent checkable items.
   State lives in component for now; Firestore migration:
     setDoc(doc(db, 'artifacts', appId, 'users', uid,
       'checklists', test.id), { checked: Array.from(checked) })
   ============================================================ */
function RevisionChecklist({ testId, recommendations }) {
  const [checked, setChecked] = useState(() => new Set());
  const toggle = useCallback((rec) => {
    setChecked((prev) => {
      const next = new Set(prev);
      if (next.has(rec)) next.delete(rec); else next.add(rec);
      return next;
    });
  }, []);
  const doneCount = checked.size;
  const total     = recommendations.length;

  return (
    <div className="jbr-card p-5 space-y-4">
      <div className="flex items-center justify-between">
        <p className="jbr-label text-xs" style={{ color: 'var(--text-muted)' }}>REVISION CHECKLIST</p>
        <span className="jbr-label text-xs" style={{ color: doneCount === total ? 'var(--chem)' : 'var(--text-muted)' }}>
          {doneCount}/{total} done
        </span>
      </div>

      {/* progress bar */}
      <div className="jbr-track h-1.5">
        <div className="jbr-fill" style={{
          width: `${total > 0 ? (doneCount / total) * 100 : 0}%`,
          background: doneCount === total ? 'var(--chem)' : 'linear-gradient(90deg, var(--gold), var(--xp))',
        }} />
      </div>

      <div className="space-y-2">
        {recommendations.map((rec, i) => {
          const done = checked.has(rec);
          return (
            <button key={i} onClick={() => toggle(rec)}
              className="w-full text-left jbr-panel p-3 flex items-start gap-3 transition-colors"
              style={done ? { borderColor: 'var(--chem)', background: 'rgba(57,255,136,0.05)' } : {}}>
              <div className="w-5 h-5 rounded-md shrink-0 flex items-center justify-center mt-0.5"
                style={{ border: `1.5px solid ${done ? 'var(--chem)' : 'var(--border)'}`, background: done ? 'rgba(57,255,136,0.15)' : 'transparent' }}>
                {done && <Check size={11} color="var(--chem)" />}
              </div>
              <span className="text-xs leading-relaxed"
                style={{ color: done ? 'var(--text-muted)' : 'var(--text-main)', textDecoration: done ? 'line-through' : 'none' }}>
                {rec}
              </span>
            </button>
          );
        })}
      </div>

      {doneCount === total && total > 0 && (
        <div className="jbr-panel px-4 py-2 text-center">
          <p className="jbr-label text-xs" style={{ color: 'var(--chem)' }}>✓ All items revised — ready for the next battle.</p>
        </div>
      )}
    </div>
  );
}

/* ============================================================
   PAGE 1 — TESTS LIST  (with filter + sort)
   ============================================================ */
function TestsList({ tests, isLoading, error, onRetry, onSelect, onDelete, onRename, pendingDelete, onUndo, onDismissToast, onBack }) {
  const [search,     setSearch]     = useState('');
  const [subjFilter, setSubjFilter] = useState('all'); // 'all' | subject key
  const [sort,       setSort]       = useState('newest'); // newest | oldest | highest | lowest

  const filtered = useMemo(() => {
    if (!tests) return [];
    let list = tests;
    // subject filter
    if (subjFilter !== 'all') list = list.filter((t) => t.topicBreakdown.some((r) => r.subject === subjFilter));
    // search
    const q = search.trim().toLowerCase();
    if (q) list = list.filter((t) => t.testTitle.toLowerCase().includes(q));
    // sort
    list = list.slice().sort((a, b) => {
      if (sort === 'newest')  return new Date(b.date) - new Date(a.date);
      if (sort === 'oldest')  return new Date(a.date) - new Date(b.date);
      if (sort === 'highest') return scorePct(b) - scorePct(a);
      if (sort === 'lowest')  return scorePct(a) - scorePct(b);
      return 0;
    });
    return list;
  }, [tests, search, subjFilter, sort]);

  const sortOptions = [
    { key: 'newest', label: 'Newest' }, { key: 'oldest', label: 'Oldest' },
    { key: 'highest', label: 'Highest' }, { key: 'lowest', label: 'Lowest' },
  ];

  return (
    <div className="max-w-3xl mx-auto px-5 py-8 space-y-6">
      <header className="flex items-start gap-3">
        {onBack && (
          <button onClick={onBack} aria-label="Back to Dashboard" className="jbr-panel p-2 rounded-lg shrink-0 mt-0.5">
            <ChevronLeft size={18} color="var(--text-muted)" />
          </button>
        )}
        <div>
          <h1 className="jbr-display text-xl font-bold jbr-gradient-text">TESTS</h1>
          <p className="jbr-label text-xs mt-1" style={{ color: 'var(--text-muted)' }}>
            {tests ? `${tests.length} TEST${tests.length === 1 ? '' : 'S'} ON RECORD` : 'YOUR TEST HISTORY'}
          </p>
        </div>
      </header>

      {/* Search */}
      <div className="relative">
        <Search size={15} color="var(--text-muted)" className="absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
        <input className="jbr-input pl-9" placeholder="Search tests…" value={search}
          onChange={(e) => setSearch(e.target.value)} aria-label="Search tests" />
      </div>

      {/* Filter chips + sort */}
      <div className="flex flex-wrap gap-2 items-center justify-between">
        <div className="flex gap-2 flex-wrap">
          {[{ key: 'all', label: 'All' }, ...SUBJECT_ORDER.map((s) => ({ key: s, label: SUBJECT_META[s].label }))].map(({ key, label }) => {
            const active = subjFilter === key;
            const color  = key !== 'all' ? SUBJECT_META[key].color : 'var(--gold-bright)';
            return (
              <button key={key} className="jbr-chip-filter" aria-pressed={active}
                onClick={() => setSubjFilter(key)}
                style={active ? { borderColor: color, color, background: `color-mix(in srgb, ${color} 10%, var(--panel-bg))` } : { color: 'var(--text-muted)' }}>
                {label}
              </button>
            );
          })}
        </div>
        {/* sort */}
        <div className="flex items-center gap-1.5">
          <SortAsc size={13} color="var(--text-muted)" />
          <select value={sort} onChange={(e) => setSort(e.target.value)}
            className="jbr-label text-[11px] bg-transparent border-none outline-none cursor-pointer"
            style={{ color: 'var(--text-muted)' }}>
            {sortOptions.map((o) => <option key={o.key} value={o.key} style={{ background: 'var(--card-bg)' }}>{o.label}</option>)}
          </select>
        </div>
      </div>

      {error ? (
        <div className="jbr-card p-8 flex flex-col items-center text-center gap-3">
          <AlertTriangle size={28} color="var(--danger)" />
          <p className="jbr-label text-sm" style={{ color: 'var(--text-main)' }}>Couldn't load your tests.</p>
          <button onClick={onRetry} className="jbr-label mt-2 px-4 py-2 rounded-lg flex items-center gap-2 text-sm"
            style={{ background: 'var(--gold)', color: '#160a00' }}><RefreshCw size={14} /> RETRY</button>
        </div>
      ) : isLoading ? (
        <div className="space-y-4" aria-busy="true">
          {[0, 1, 2].map((i) => <div key={i} className="jbr-skeleton h-52 rounded-2xl" />)}
        </div>
      ) : filtered.length === 0 ? (
        <div className="jbr-card p-8 flex flex-col items-center text-center gap-3">
          <BarChart3 size={28} color="var(--gold)" />
          <p className="jbr-label text-sm" style={{ color: 'var(--text-main)' }}>
            {search.trim() || subjFilter !== 'all' ? 'No tests match your filters.' : 'No tests yet.'}
          </p>
        </div>
      ) : (
        <div className="space-y-4 pb-24">
          {filtered.map((test) => (
            <TestCard key={test.id} test={test} onSelect={onSelect} onDelete={onDelete} onRename={onRename} />
          ))}
        </div>
      )}

      {pendingDelete && (
        <UndoToast title={pendingDelete.item.testTitle} onUndo={onUndo} onDismiss={onDismissToast} />
      )}
    </div>
  );
}

/* ============================================================
   PAGE 2 — TEST DETAIL
   ============================================================ */
function TestDetail({ test, allTests, onBack, onViewPaper }) {
  const pct              = scorePct(test);
  const color            = scoreColor(pct);
  const totalCorrect     = test.topicBreakdown.reduce((s, r) => s + r.correct, 0);
  const totalIncorrect   = test.topicBreakdown.reduce((s, r) => s + r.incorrect, 0);
  const totalUnattempted = test.topicBreakdown.reduce((s, r) => s + r.unattempted, 0);
  const totalAttempted   = totalCorrect + totalIncorrect;
  const accuracyPct      = accuracy(totalCorrect, totalIncorrect);

  return (
    <div className="max-w-3xl mx-auto px-5 py-8 space-y-6">
      {/* Header */}
      <header className="flex items-center gap-3">
        <button onClick={onBack} aria-label="Back" className="jbr-panel p-2 rounded-lg shrink-0">
          <ChevronLeft size={18} color="var(--text-muted)" />
        </button>
        <div className="min-w-0 flex-1">
          <h1 className="jbr-display text-lg font-bold truncate" style={{ color: 'var(--text-main)' }}>{test.testTitle}</h1>
          <p className="jbr-label text-xs" style={{ color: 'var(--text-muted)' }}>
            <Calendar size={10} style={{ display: 'inline', marginRight: 4 }} />{formatDate(test.date)}
          </p>
        </div>
        <ScoreBadge pct={pct} />
      </header>

      {/* 1 — Overall stat cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {[
          { icon: Target,       label: 'Score',       value: `${test.totalScore}/${test.maxScore}`, color },
          { icon: CheckCircle2, label: 'Accuracy',    value: `${accuracyPct}%`,  color: 'var(--chem)' },
          { icon: CheckCircle2, label: 'Correct',     value: totalCorrect,        color: 'var(--chem)' },
          { icon: XCircle,      label: 'Incorrect',   value: totalIncorrect,      color: 'var(--danger)' },
        ].map(({ icon: Icon, label, value, color: c }) => (
          <div key={label} className="jbr-card p-4 flex flex-col gap-1.5">
            <div className="flex items-center gap-1.5">
              <Icon size={13} color={c} />
              <span className="jbr-label text-[10px]" style={{ color: 'var(--text-muted)' }}>{label.toUpperCase()}</span>
            </div>
            <span className="jbr-display text-xl font-bold" style={{ color: c }}>{value}</span>
          </div>
        ))}
      </div>

      {/* Score bar + breakdown */}
      <div className="jbr-card p-4">
        <div className="flex items-center justify-between mb-2">
          <span className="jbr-label text-xs" style={{ color: 'var(--text-muted)' }}>SCORE</span>
          <span className="jbr-label text-xs" style={{ color }}>{test.totalScore} / {test.maxScore}</span>
        </div>
        <div className="jbr-track h-3"><div className="jbr-fill" style={{ width: `${pct}%`, background: color }} /></div>
        <div className="flex h-1.5 rounded-full overflow-hidden gap-px mt-2" style={{ background: 'var(--panel-bg)' }}>
          {(totalCorrect + totalIncorrect + totalUnattempted) > 0 && <>
            <div style={{ width: `${(totalCorrect/(totalCorrect+totalIncorrect+totalUnattempted))*100}%`, background: 'var(--chem)' }} />
            <div style={{ width: `${(totalIncorrect/(totalCorrect+totalIncorrect+totalUnattempted))*100}%`, background: 'var(--danger)' }} />
            <div style={{ width: `${(totalUnattempted/(totalCorrect+totalIncorrect+totalUnattempted))*100}%`, background: 'var(--border)' }} />
          </>}
        </div>
        <div className="flex gap-4 mt-2">
          {[['var(--chem)', `${totalCorrect} correct`], ['var(--danger)', `${totalIncorrect} incorrect`], ['var(--border)', `${totalUnattempted} unattempted`]].map(([c, label]) => (
            <span key={label} className="jbr-label text-[10px] flex items-center gap-1" style={{ color: 'var(--text-muted)' }}>
              <span style={{ width: 7, height: 7, borderRadius: 2, background: c, display: 'inline-block' }} /> {label}
            </span>
          ))}
        </div>
      </div>

      {/* 2 — Subject Performance Rings */}
      <SubjectRings topicBreakdown={test.topicBreakdown} />

      {/* 3 — Score Potential */}
      <ScorePotential test={test} />

      {/* 4 — Difficulty Heatmap */}
      {test.difficultyBreakdown && <DifficultyHeatmap difficultyBreakdown={test.difficultyBreakdown} />}

      {/* 6 — Chapter Breakdown */}
      <ChapterBreakdown topicBreakdown={test.topicBreakdown} />

      {/* 7 — Cross-Test Chapter Comparison */}
      <CrossChapterComparison currentTest={test} allTests={allTests} />

      {/* 8 — Revision Checklist */}
      {test.aiRecommendations?.length > 0 && (
        <RevisionChecklist testId={test.id} recommendations={test.aiRecommendations} />
      )}

      {/* 10 — AI Insight */}
      <div className="jbr-card p-5 flex items-start gap-3">
        <div className="w-9 h-9 rounded-xl flex items-center justify-center shrink-0"
          style={{ background: 'var(--panel-bg)', border: '1px solid var(--gold)' }}>
          <Sparkles size={16} color="var(--gold-bright)" />
        </div>
        <div>
          <p className="jbr-label text-[10px] mb-1" style={{ color: 'var(--text-muted)' }}>AI INSIGHT</p>
          <p className="text-sm leading-relaxed" style={{ color: 'var(--text-main)' }}>{test.aiFeedback}</p>
        </div>
      </div>

      {/* 11 — View Paper */}
      {test.paperId ? (
        <button onClick={() => onViewPaper && onViewPaper(test.paperId)}
          className="jbr-label text-sm w-full py-3 rounded-xl flex items-center justify-center gap-2"
          style={{ background: 'var(--panel-bg)', border: '1px solid var(--gold)', color: 'var(--gold-bright)' }}>
          <FileText size={15} /> VIEW QUESTION PAPER <ExternalLink size={13} />
        </button>
      ) : (
        <div className="jbr-label text-xs w-full py-3 rounded-xl flex items-center justify-center gap-2"
          style={{ background: 'var(--panel-bg)', border: '1px solid var(--border)', color: 'var(--text-muted)' }}>
          <FileText size={14} /> No question paper linked to this test
        </div>
      )}
    </div>
  );
}

/* ============================================================
   ROOT
   ============================================================ */
export default function TestsTab({ onViewPaper, onBack }) {
  const { data: rawData, isLoading, error, retry } = useTestsData();
  const [view,       setView]       = useState('list');
  const [selectedId, setSelectedId] = useState(null);
  const [tests,      setTests]      = useState(null);
  useEffect(() => { if (rawData) setTests(rawData); }, [rawData]);

  const [pendingDelete, setPendingDelete] = useState(null);
  const deleteTimerRef = useRef(null);

  const selectedTest = useMemo(() =>
    tests && selectedId ? tests.find((t) => t.id === selectedId) ?? null : null,
    [tests, selectedId]);

  const commitDelete = useCallback(() => { setPendingDelete(null); }, []);

  const handleDelete = useCallback((id) => {
    if (pendingDelete) { clearTimeout(deleteTimerRef.current); setPendingDelete(null); }
    setTests((prev) => {
      const idx = prev.findIndex((t) => t.id === id);
      if (idx === -1) return prev;
      const item = prev[idx];
      setPendingDelete({ item, index: idx });
      const filtered = prev.filter((t) => t.id !== id);
      saveTests(filtered); // Bug 3 fix: persist delete immediately
      return filtered;
    });
    deleteTimerRef.current = setTimeout(commitDelete, 5000);
  }, [pendingDelete, commitDelete]);

  const handleUndo = useCallback(() => {
    if (!pendingDelete) return;
    clearTimeout(deleteTimerRef.current);
    setTests((prev) => {
      const next = [...prev];
      next.splice(pendingDelete.index, 0, pendingDelete.item);
      saveTests(next); // Bug 3 fix: persist undo restore
      return next;
    });
    setPendingDelete(null);
  }, [pendingDelete]);

  const handleDismissToast = useCallback(() => { clearTimeout(deleteTimerRef.current); commitDelete(); }, [commitDelete]);
  useEffect(() => () => clearTimeout(deleteTimerRef.current), []);

  const handleRename = useCallback((id, newTitle) => {
    setTests((prev) => {
      const updated = prev.map((t) => t.id === id ? { ...t, testTitle: newTitle } : t);
      saveTests(updated); // Bug 3 fix: persist so rename survives refresh
      return updated;
    });
  }, []);

  const handleSelect = useCallback((id) => { setSelectedId(id); setView('detail'); }, []);
  const handleBack   = useCallback(() => { setView('list'); setSelectedId(null); }, []);

  return (
    <div className="jbr-root jbr-glow-bg">
      <style>{THEME}</style>
      {view === 'detail' && selectedTest ? (
        <TestDetail
          test={selectedTest}
          allTests={tests || []}
          onBack={handleBack}
          onViewPaper={onViewPaper}
        />
      ) : (
        <TestsList
          tests={tests}
          isLoading={isLoading}
          error={error}
          onRetry={retry}
          onSelect={handleSelect}
          onDelete={handleDelete}
          onRename={handleRename}
          pendingDelete={pendingDelete}
          onUndo={handleUndo}
          onDismissToast={handleDismissToast}
          onBack={onBack}
        />
      )}
    </div>
  );
}
