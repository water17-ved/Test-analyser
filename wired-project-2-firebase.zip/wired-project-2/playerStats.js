/* ============================================================
   PLAYER STATS — XP, level, streak, attempt count.
   localStorage-backed (same pattern as uploadedPapers.js).
   Swap for Firestore once Dev 3's backend is live:
     - savePlayerStats → Firestore write to /users/{uid}/stats
     - getPlayerStats  → Firestore read with a real-time listener
   The shape here is what Dashboard and Achievements already
   expect, so the swap is a one-line change in each hook.
   ============================================================ */

const KEY            = 'jbr_player_stats_v1';
export const XP_PER_LEVEL = 1000; // XP needed per level

const DEFAULTS = {
  name:           'Student',
  xp:             0,
  level:          1,
  streak:         0,
  lastActiveDate: null,   // 'YYYY-MM-DD'
  attemptsCount:  0,
  rank:           null,   // { position, totalPlayers } — set by Firestore/leaderboard later
  aim:            null,   // { label, value } — set by AI rank prediction later
};

export function getPlayerStats() {
  try {
    const raw    = localStorage.getItem(KEY);
    const saved  = raw ? JSON.parse(raw) : {};
    return { ...DEFAULTS, ...saved };
  } catch {
    return { ...DEFAULTS };
  }
}

function savePlayerStats(stats) {
  try {
    localStorage.setItem(KEY, JSON.stringify(stats));
  } catch { /* storage unavailable */ }
}

/**
 * Call after every successful test submission (OMR or paper).
 * Increments streak, awards XP, levels up automatically.
 * Returns the updated stats object.
 */
export function recordTestCompletion({ xpAwarded = 100 } = {}) {
  const stats     = getPlayerStats();
  const today     = new Date().toISOString().slice(0, 10);
  const yesterday = new Date(Date.now() - 86_400_000).toISOString().slice(0, 10);

  let { streak, lastActiveDate } = stats;
  if (lastActiveDate === today) {
    // Already recorded activity today — don't double-count streak
  } else if (lastActiveDate === yesterday) {
    streak += 1;            // consecutive day
  } else {
    streak = 1;             // gap detected, restart
  }

  const xp    = stats.xp + xpAwarded;
  const level = Math.max(1, Math.floor(xp / XP_PER_LEVEL) + 1);

  const updated = {
    ...stats,
    xp,
    level,
    streak,
    lastActiveDate: today,
    attemptsCount:  stats.attemptsCount + 1,
  };
  savePlayerStats(updated);
  return updated;
}

/** Called after Firebase Auth resolves so the student's display name is stored. */
export function setPlayerName(name) {
  if (!name) return;
  const stats   = getPlayerStats();
  const updated = { ...stats, name };
  savePlayerStats(updated);
  return updated;
}
