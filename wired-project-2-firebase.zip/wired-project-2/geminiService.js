// geminiService.js
// Dev 1 — AI & Prompt Engineer
// Handles all Gemini API operations for the Test Analyzer pipeline:
//   1. parseTestPaperWithGemini  -> digitize test paper into master answer key JSON
//   2. parseOMRSheetWithGemini   -> digitize student OMR/answer sheet JSON
//   3. evaluateStudentTest       -> compare student vs master key, produce report JSON
//
// Includes exponential backoff retry logic for rate limits / transient errors.
//
// Setup: add VITE_GEMINI_API_KEY to your .env file.
// Get a key at https://aistudio.google.com/app/apikey (free tier available).

// Vite exposes env vars via import.meta.env, not process.env.
// VITE_ prefix is required for vars exposed to the browser bundle.
const apiKey = import.meta.env.VITE_GEMINI_API_KEY || '';
const MODEL = 'gemini-2.5-flash-preview-09-2025';
const BASE_URL = 'https://generativelanguage.googleapis.com/v1beta/models';

// ---------------------------------------------------------------------------
// Retry helper — exponential backoff for rate limits and transient errors.
// 429 (rate limit) and 5xx responses are retried; 4xx permission/auth errors
// are not (retrying won't help).
// ---------------------------------------------------------------------------
async function fetchWithRetry(url, options, maxRetries = 5) {
  let delay = 1000;
  for (let i = 0; i < maxRetries; i++) {
    try {
      const response = await fetch(url, options);
      if (response.status === 429) {
        // Rate limited — always retry with backoff
        if (i === maxRetries - 1) throw new Error('Rate limit exceeded after max retries.');
        await new Promise((res) => setTimeout(res, delay));
        delay = Math.min(delay * 2, 30000); // cap at 30s
        continue;
      }
      if (response.status === 400 || response.status === 403) {
        // Bad request or permission denied — don't retry, throw immediately
        const body = await response.json().catch(() => ({}));
        throw new Error(`Gemini API error ${response.status}: ${body?.error?.message || response.statusText}`);
      }
      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }
      return await response.json();
    } catch (err) {
      if (i === maxRetries - 1) throw err;
      // Don't retry hard errors (auth, bad request) — only network/transient
      if (err.message.startsWith('Gemini API error 4')) throw err;
      await new Promise((res) => setTimeout(res, delay));
      delay = Math.min(delay * 2, 30000);
    }
  }
}

// Gemini sometimes wraps JSON in ```json fences even when responseMimeType
// is set — strip them defensively before parsing.
function parseJsonFromResponse(data) {
  const rawText = data.candidates?.[0]?.content?.parts?.[0]?.text;
  if (!rawText) throw new Error('No content returned from Gemini — the model may have refused the input.');
  const clean = rawText.replace(/```json\s*|```/g, '').trim();
  try {
    return JSON.parse(clean);
  } catch {
    throw new Error(`Gemini returned non-JSON content: ${rawText.slice(0, 200)}`);
  }
}

// ---------------------------------------------------------------------------
// Prompt 1: Test Paper Digitizer
// ---------------------------------------------------------------------------
const DIGITIZER_SYSTEM_INSTRUCTION = `You are an expert academic examiner and vision parser.
Your task is to analyze the attached test paper image or PDF.
Extract all questions, options, correct answers, subject name, chapter name, topic name, and difficulty level.
Return ONLY valid JSON strictly matching this schema — no markdown, no preamble, just JSON:
{
  "testTitle": "string",
  "subject": "string",
  "totalMarks": number,
  "questions": [
    {
      "questionNumber": number,
      "questionText": "string",
      "options": ["string", "string", "string", "string"],
      "correctAnswer": "string",
      "chapter": "string",
      "topic": "string",
      "difficulty": "Easy|Medium|Hard",
      "marks": number
    }
  ]
}`;

/**
 * Digitize a test paper (image or PDF) into the master answer key JSON.
 * @param {string} base64Data - base64-encoded file contents (no data: prefix)
 * @param {string} mimeType - e.g. "image/jpeg" or "application/pdf"
 * @returns {Promise<object>} TestPaper object (Contract A)
 */
export async function parseTestPaperWithGemini(base64Data, mimeType = 'application/pdf') {
  if (!apiKey) {
    throw new Error(
      'VITE_GEMINI_API_KEY is not set. Add it to your .env file to enable AI paper parsing.'
    );
  }

  const endpoint = `${BASE_URL}/${MODEL}:generateContent?key=${apiKey}`;

  const payload = {
    contents: [
      {
        parts: [
          { text: 'Analyze this test paper. Extract all questions, options, answers, chapter, topic, and difficulty into a structured JSON object according to the predefined schema.' },
          { inlineData: { mimeType, data: base64Data } },
        ],
      },
    ],
    systemInstruction: { parts: [{ text: DIGITIZER_SYSTEM_INSTRUCTION }] },
    generationConfig: { responseMimeType: 'application/json', temperature: 0.1 },
  };

  const data = await fetchWithRetry(endpoint, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });

  return parseJsonFromResponse(data);
}

// ---------------------------------------------------------------------------
// Prompt 2: Student Answer / OMR Sheet Scanner
// ---------------------------------------------------------------------------
const OMR_SYSTEM_INSTRUCTION = `You are an expert Optical Mark Recognition (OMR) and student answer sheet digitizer.
Analyze the provided image of a student answer sheet, OMR sheet, or test paper. Carefully identify
student details and extract every marked question response into a structured, valid JSON array.
Handle partially filled bubbles, ticks, crosses, and handwritten text accurately.
Return ONLY valid JSON strictly matching this schema — no markdown, no preamble:
{
  "studentDetails": {
    "studentName": "string",
    "rollNumber": "string",
    "testCode": "string",
    "examDate": "string"
  },
  "extractedAnswers": [
    {
      "questionNumber": number,
      "subject": "string",
      "markedOption": "string",
      "status": "attempted|unattempted"
    }
  ]
}`;

/**
 * Digitize a student's OMR / answer sheet into structured JSON.
 * @param {string} base64Data - base64-encoded image contents (no data: prefix)
 * @param {string} mimeType - e.g. "image/jpeg"
 * @returns {Promise<object>} { studentDetails, extractedAnswers }
 */
export async function parseOMRSheetWithGemini(base64Data, mimeType = 'image/jpeg') {
  if (!apiKey) {
    throw new Error('VITE_GEMINI_API_KEY is not set. Add it to your .env file to enable OMR scanning.');
  }

  const endpoint = `${BASE_URL}/${MODEL}:generateContent?key=${apiKey}`;

  const payload = {
    contents: [
      {
        parts: [
          { text: 'Extract student details and marked answers from this OMR sheet.' },
          { inlineData: { mimeType, data: base64Data } },
        ],
      },
    ],
    systemInstruction: { parts: [{ text: OMR_SYSTEM_INSTRUCTION }] },
    generationConfig: { responseMimeType: 'application/json', temperature: 0.1 },
  };

  const data = await fetchWithRetry(endpoint, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });

  return parseJsonFromResponse(data);
}

// ---------------------------------------------------------------------------
// Prompt 3: Evaluation & Analytics Engine
// ---------------------------------------------------------------------------
const EVALUATION_SYSTEM_INSTRUCTION = `You are an expert educational assessment and analytics engine.
Compare student answer records against master answer key data. Calculate precise scores according
to exam marking rules, compute subject-wise performance breakdowns, and generate actionable
diagnostic feedback regarding student strengths and weak areas.
Return ONLY valid JSON strictly matching this schema — no markdown, no preamble:
{
  "overallPerformance": {
    "totalScore": number,
    "maxPossibleScore": number,
    "accuracyPercentage": number,
    "totalAttempted": number,
    "totalCorrect": number,
    "totalIncorrect": number,
    "totalUnattempted": number
  },
  "subjectBreakdown": [
    {
      "subject": "string",
      "score": number,
      "correctCount": number,
      "incorrectCount": number,
      "unattemptedCount": number
    }
  ],
  "diagnosticInsights": {
    "strongTopics": ["string"],
    "weakTopics": ["string"],
    "recommendations": ["string"]
  }
}`;

/**
 * Evaluate a student's submission against the master answer key.
 * @param {object[]} masterKey - questions array from parseTestPaperWithGemini
 * @param {object} studentAnswers - result of parseOMRSheetWithGemini
 * @param {object} [markingScheme] - e.g. { correct: 4, incorrect: -1, unattempted: 0 }
 * @returns {Promise<object>} { overallPerformance, subjectBreakdown, diagnosticInsights }
 */
export async function evaluateStudentTest(
  masterKey,
  studentAnswers,
  markingScheme = { correct: 4, incorrect: -1, unattempted: 0 }
) {
  if (!apiKey) {
    throw new Error('VITE_GEMINI_API_KEY is not set.');
  }

  const endpoint = `${BASE_URL}/${MODEL}:generateContent?key=${apiKey}`;

  const payload = {
    contents: [
      {
        parts: [
          {
            text: JSON.stringify({ testPaperKey: masterKey, studentSubmission: studentAnswers, markingScheme }),
          },
          { text: 'Evaluate student submission against master key.' },
        ],
      },
    ],
    systemInstruction: { parts: [{ text: EVALUATION_SYSTEM_INSTRUCTION }] },
    generationConfig: { responseMimeType: 'application/json', temperature: 0.1 },
  };

  const data = await fetchWithRetry(endpoint, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });

  return parseJsonFromResponse(data);
}

// ---------------------------------------------------------------------------
// Convenience: run the full 3-step pipeline end to end
// ---------------------------------------------------------------------------
export async function runFullPipeline(paperBase64, paperMimeType, omrBase64, omrMimeType) {
  const masterKey = await parseTestPaperWithGemini(paperBase64, paperMimeType);
  const studentSubmission = await parseOMRSheetWithGemini(omrBase64, omrMimeType);
  const report = await evaluateStudentTest(masterKey.questions || masterKey, studentSubmission);
  return { masterKey, studentSubmission, report };
}
