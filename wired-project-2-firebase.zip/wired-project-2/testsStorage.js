/* ============================================================
   TESTS STORAGE — persists attempt records to localStorage.
   Replaces the static MOCK_ATTEMPTS array so TestsTab and
   OverallAnalytics always show real user data.

   Schema per record (superset — OverallAnalytics only reads
   the fields it needs):
   {
     id, testTitle, date, totalScore, maxScore,
     examType: 'jee' | 'neet',
     subjects: string[],
     paperId?: string,
     aiFeedback: string | null,
     aiRecommendations: string[],
     topicBreakdown[]:      { subject, chapter, correct, incorrect, unattempted }
     difficultyBreakdown[]: { subject, difficulty, correct, incorrect, unattempted }
   }

   Firestore swap (Dev 3):
     getTests()  → listStudentAttempts(uid)
     saveTest()  → Firestore write to /attempts/{attemptId}
     deleteTest()→ Firestore delete
     saveTests() → batch write (used by TestsTab rename, not needed once Firestore is live)
   ============================================================ */

const KEY = 'jbr_tests_v1';

export function getTests() {
  try {
    const raw    = localStorage.getItem(KEY);
    const parsed = raw ? JSON.parse(raw) : [];
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

export function saveTests(tests) {
  try {
    localStorage.setItem(KEY, JSON.stringify(tests));
  } catch { /* storage unavailable */ }
}

/** Upserts a single test record. Adds to front if new, replaces in-place if id exists. */
export function saveTest(test) {
  const existing = getTests();
  const idx      = existing.findIndex((t) => t.id === test.id);
  const updated  = idx >= 0
    ? existing.map((t, i) => (i === idx ? test : t))
    : [test, ...existing];
  saveTests(updated);
  return test;
}

export function deleteTest(id) {
  saveTests(getTests().filter((t) => t.id !== id));
}
