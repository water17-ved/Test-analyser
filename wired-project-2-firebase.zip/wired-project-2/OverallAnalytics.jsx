import React, { useState, useEffect, useCallback, useMemo, memo } from 'react';
import {
  BarChart3, TrendingUp, TrendingDown, Target, ListChecks, CheckCircle2, Sparkles,
  AlertTriangle, RefreshCw, Layers, ArrowUpRight, ChevronLeft,
} from 'lucide-react';
import {
  ResponsiveContainer, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip,
} from 'recharts';
import { THEME, SUBJECT_META } from './theme';
import { getTests } from './testsStorage';

const SUBJECT_ORDER = Object.keys(SUBJECT_META);

/* ============================================================
   DATA LAYER
   Stand-in for the real Firestore read (Dev 3: getStudentAttempts,
   reading /attempts/{attemptId} filtered by studentId). Every
   attempt here matches the schema from the plan: totalScore,
   topicBreakdown, aiFeedback. Swapping this hook's guts for a
   Firestore query is a one-line change — everything below only
   depends on the { data, isLoading, error } shape.
   ============================================================ */
function useAnalyticsData() {
  const [state, setState] = useState({ data: null, isLoading: true, error: null });
  const fetchData = useCallback(() => {
    setState({ data: null, isLoading: true, error: null });
    // Reads from localStorage via testsStorage. Swap for Firestore once Dev 3 is live.
    const timer = setTimeout(() => setState({ data: getTests(), isLoading: false, error: null }), 300);
    return () => clearTimeout(timer);
  }, []);
  useEffect(() => fetchData(), [fetchData]);
  return { ...state, retry: fetchData };
}

/* ============================================================
   DERIVED ANALYTICS
   Pure aggregation over attempts — kept as one memoized pass so
   every widget on the screen reads from the same numbers instead
   of each recomputing its own slice.
   ============================================================ */
function useAnalytics(attempts) {
  return useMemo(() => {
    if (!attempts || attempts.length === 0) return null;

    const sorted = attempts.slice().sort((a, b) => new Date(a.date) - new Date(b.date));
    const scoreTrend = sorted.map((a) => ({
      date: a.date,
      label: new Date(a.date).toLocaleDateString('en-IN', { day: '2-digit', month: 'short' }),
      scorePct: Math.round((a.totalScore / a.maxScore) * 100),
    }));

    const bySubject = new Map();
    const byChapter = new Map();
    let totalCorrect = 0, totalIncorrect = 0, totalUnattempted = 0;

    attempts.forEach((attempt) => {
      attempt.topicBreakdown.forEach((row) => {
        totalCorrect += row.correct; totalIncorrect += row.incorrect; totalUnattempted += row.unattempted;

        const sAgg = bySubject.get(row.subject) || { correct: 0, incorrect: 0, unattempted: 0 };
        sAgg.correct += row.correct; sAgg.incorrect += row.incorrect; sAgg.unattempted += row.unattempted;
        bySubject.set(row.subject, sAgg);

        const cKey = `${row.subject}::${row.chapter}`;
        const cAgg = byChapter.get(cKey) || { subject: row.subject, chapter: row.chapter, correct: 0, incorrect: 0, unattempted: 0 };
        cAgg.correct += row.correct; cAgg.incorrect += row.incorrect; cAgg.unattempted += row.unattempted;
        byChapter.set(cKey, cAgg);
      });
    });

    const withAccuracy = (agg) => {
      const attempted = agg.correct + agg.incorrect;
      const total = attempted + agg.unattempted;
      const accuracyPct = attempted > 0 ? Math.round((agg.correct / attempted) * 100) : 0;
      return { ...agg, attempted, total, accuracyPct };
    };

    const subjects = SUBJECT_ORDER
      .filter((key) => bySubject.has(key))
      .map((key) => ({ subject: key, ...withAccuracy(bySubject.get(key)) }));

    const chapters = Array.from(byChapter.values()).map(withAccuracy);
    // Only rank chapters with enough attempted questions to mean something.
    const rankable = chapters.filter((c) => c.attempted >= 3);
    const strengths = rankable.slice().sort((a, b) => b.accuracyPct - a.accuracyPct).slice(0, 3);
    const weaknesses = rankable.slice().sort((a, b) => a.accuracyPct - b.accuracyPct).slice(0, 3);

    const totalAttempted = totalCorrect + totalIncorrect;
    const totalQuestions = totalAttempted + totalUnattempted;
    const overallAccuracyPct = totalAttempted > 0 ? Math.round((totalCorrect / totalAttempted) * 100) : 0;
    const avgScorePct = Math.round(scoreTrend.reduce((sum, p) => sum + p.scorePct, 0) / scoreTrend.length);
    const latest = sorted[sorted.length - 1];
    const prevScore = sorted.length > 1 ? Math.round((sorted[sorted.length - 2].totalScore / sorted[sorted.length - 2].maxScore) * 100) : null;
    const latestScorePct = Math.round((latest.totalScore / latest.maxScore) * 100);
    const trendDelta = prevScore === null ? null : latestScorePct - prevScore;

    return {
      attemptsCount: attempts.length, totalQuestions, totalAttempted, overallAccuracyPct, avgScorePct,
      scoreTrend, subjects, strengths, weaknesses, latestFeedback: latest.aiFeedback, trendDelta,
    };
  }, [attempts]);
}

/* ============================================================
   REUSABLE PIECES
   ============================================================ */
function StatCard({ icon: Icon, label, value, sub, accent }) {
  return (
    <div className="jbr-card p-4 flex flex-col gap-2">
      <div className="flex items-center gap-2">
        <Icon size={15} color={accent || 'var(--gold-bright)'} />
        <span className="jbr-label text-[10px]" style={{ color: 'var(--text-muted)' }}>{label.toUpperCase()}</span>
      </div>
      <div className="flex items-baseline gap-1">
        <span className="jbr-display text-2xl font-bold">{value}</span>
        {sub && <span className="jbr-label text-[10px]" style={{ color: 'var(--text-muted)' }}>{sub}</span>}
      </div>
    </div>
  );
}

const ChapterBar = memo(function ChapterBar({ row, tone }) {
  const meta = SUBJECT_META[row.subject];
  const color = tone === 'weak' ? 'var(--danger)' : 'var(--chem)';
  return (
    <div className="py-2">
      <div className="flex items-center justify-between mb-1.5 gap-2">
        <div className="flex items-center gap-1.5 min-w-0">
          <meta.icon size={12} color={meta.color} className="shrink-0" />
          <span className="text-xs truncate" style={{ color: 'var(--text-main)' }}>{row.chapter}</span>
        </div>
        <span className="jbr-label text-xs shrink-0" style={{ color }}>{row.accuracyPct}%</span>
      </div>
      <div className="jbr-track h-2">
        <div className="jbr-fill" style={{ width: `${row.accuracyPct}%`, background: color }} />
      </div>
    </div>
  );
});

function CustomTooltip({ active, payload }) {
  if (!active || !payload || !payload.length) return null;
  const p = payload[0].payload;
  return (
    <div className="jbr-panel px-3 py-2" style={{ borderColor: 'var(--gold)' }}>
      <p className="jbr-label text-[10px]" style={{ color: 'var(--text-muted)' }}>{p.label}</p>
      <p className="jbr-display text-sm font-bold" style={{ color: 'var(--gold-bright)' }}>{p.scorePct}%</p>
    </div>
  );
}

/* ---- Loading / error / empty states, matching the other screens ---- */
function AnalyticsSkeleton() {
  return (
    <div className="space-y-6" aria-busy="true" aria-label="Loading analytics">
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        {[0, 1, 2, 3].map((i) => <div key={i} className="jbr-skeleton h-20 rounded-2xl" />)}
      </div>
      <div className="jbr-skeleton h-56 rounded-2xl" />
      <div className="grid sm:grid-cols-2 gap-4">
        <div className="jbr-skeleton h-40 rounded-2xl" />
        <div className="jbr-skeleton h-40 rounded-2xl" />
      </div>
    </div>
  );
}

function AnalyticsError({ onRetry }) {
  return (
    <div className="jbr-card p-8 flex flex-col items-center text-center gap-3">
      <AlertTriangle size={28} color="var(--danger)" />
      <p className="jbr-label text-sm" style={{ color: 'var(--text-main)' }}>Couldn't load your analytics.</p>
      <p className="text-xs" style={{ color: 'var(--text-muted)' }}>Check your connection and try again.</p>
      <button
        onClick={onRetry}
        className="jbr-label mt-2 px-4 py-2 rounded-lg flex items-center gap-2 text-sm"
        style={{ background: 'var(--gold)', color: '#160a00' }}
      >
        <RefreshCw size={14} /> RETRY
      </button>
    </div>
  );
}

function EmptyAnalytics() {
  return (
    <div className="jbr-card p-8 flex flex-col items-center text-center gap-3">
      <BarChart3 size={28} color="var(--gold)" />
      <p className="jbr-label text-sm" style={{ color: 'var(--text-main)' }}>No analytics yet.</p>
      <p className="text-xs" style={{ color: 'var(--text-muted)' }}>Take your first test and this screen fills in with score trends, subject accuracy, and AI-spotted weak areas.</p>
    </div>
  );
}

/* ============================================================
   MAIN SCREEN
   ============================================================ */
export default function OverallAnalytics({ onBack }) {
  const { data: attempts, isLoading, error, retry } = useAnalyticsData();
  const analytics = useAnalytics(attempts);

  return (
    <div className="jbr-root jbr-glow-bg">
      <style>{THEME}</style>
      <div className="max-w-3xl mx-auto px-5 py-8 space-y-6">
        <header className="flex items-center gap-3">
          {onBack && (
            <button onClick={onBack} aria-label="Back to Dashboard" className="jbr-panel p-2 rounded-lg shrink-0">
              <ChevronLeft size={18} color="var(--text-muted)" />
            </button>
          )}
          <div>
            <h1 className="jbr-display text-xl font-bold jbr-gradient-text">OVERALL ANALYTICS</h1>
            <p className="jbr-label text-xs mt-1" style={{ color: 'var(--text-muted)' }}>YOUR PERFORMANCE ACROSS ALL TESTS</p>
          </div>
        </header>

        {error ? (
          <AnalyticsError onRetry={retry} />
        ) : isLoading ? (
          <AnalyticsSkeleton />
        ) : !analytics ? (
          <EmptyAnalytics />
        ) : (
          <>
            {/* Overview stats */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
              <StatCard icon={ListChecks} label="Attempts" value={analytics.attemptsCount} />
              <StatCard icon={Target} label="Avg Score" value={`${analytics.avgScorePct}%`} />
              <StatCard icon={CheckCircle2} label="Accuracy" value={`${analytics.overallAccuracyPct}%`} accent="var(--chem)" />
              <StatCard
                icon={analytics.trendDelta === null || analytics.trendDelta >= 0 ? TrendingUp : TrendingDown}
                label="Last Test"
                value={`${analytics.scoreTrend[analytics.scoreTrend.length - 1].scorePct}%`}
                sub={analytics.trendDelta === null ? undefined : `${analytics.trendDelta >= 0 ? '+' : ''}${analytics.trendDelta}pp`}
                accent={analytics.trendDelta === null || analytics.trendDelta >= 0 ? 'var(--chem)' : 'var(--danger)'}
              />
            </div>

            {/* Score trend */}
            <div className="jbr-card p-5">
              <p className="jbr-label text-xs mb-4" style={{ color: 'var(--text-muted)' }}>SCORE TREND</p>
              <div style={{ width: '100%', height: 200 }}>
                <ResponsiveContainer>
                  <LineChart data={analytics.scoreTrend} margin={{ top: 8, right: 8, left: -20, bottom: 0 }}>
                    <CartesianGrid stroke="var(--border)" strokeDasharray="3 3" vertical={false} />
                    <XAxis dataKey="label" tick={{ fill: 'var(--text-muted)', fontSize: 11 }} axisLine={{ stroke: 'var(--border)' }} tickLine={false} />
                    <YAxis domain={[0, 100]} tick={{ fill: 'var(--text-muted)', fontSize: 11 }} axisLine={false} tickLine={false} />
                    <Tooltip content={<CustomTooltip />} />
                    <Line type="monotone" dataKey="scorePct" stroke="var(--gold-bright)" strokeWidth={2.5} dot={{ r: 4, fill: 'var(--gold-bright)' }} activeDot={{ r: 6 }} />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Subject-wise accuracy */}
            <div className="jbr-card p-5">
              <p className="jbr-label text-xs mb-4" style={{ color: 'var(--text-muted)' }}>SUBJECT-WISE ACCURACY</p>
              <div className="space-y-4">
                {analytics.subjects.map((s) => {
                  const meta = SUBJECT_META[s.subject];
                  return (
                    <div key={s.subject}>
                      <div className="flex items-center justify-between mb-1.5">
                        <span className="jbr-label text-xs flex items-center gap-1.5" style={{ color: meta.color }}>
                          <meta.icon size={13} /> {meta.label}
                        </span>
                        <span className="text-[11px]" style={{ color: 'var(--text-muted)' }}>{s.correct}/{s.attempted} correct · {s.accuracyPct}%</span>
                      </div>
                      <div className="jbr-track h-2.5">
                        <div className="jbr-fill" style={{ width: `${s.accuracyPct}%`, background: meta.color }} />
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Strengths & weaknesses */}
            <div className="grid sm:grid-cols-2 gap-4">
              <div className="jbr-card p-4">
                <p className="jbr-label text-xs mb-1 flex items-center gap-1.5" style={{ color: 'var(--chem)' }}>
                  <ArrowUpRight size={13} /> STRONGEST CHAPTERS
                </p>
                {analytics.strengths.length === 0 ? (
                  <p className="text-xs mt-2" style={{ color: 'var(--text-muted)' }}>Not enough attempts per chapter yet.</p>
                ) : (
                  <div className="divide-y" style={{ borderColor: 'var(--border)' }}>
                    {analytics.strengths.map((row) => <ChapterBar key={`${row.subject}-${row.chapter}`} row={row} tone="strong" />)}
                  </div>
                )}
              </div>
              <div className="jbr-card p-4">
                <p className="jbr-label text-xs mb-1 flex items-center gap-1.5" style={{ color: 'var(--danger)' }}>
                  <Layers size={13} /> NEEDS WORK
                </p>
                {analytics.weaknesses.length === 0 ? (
                  <p className="text-xs mt-2" style={{ color: 'var(--text-muted)' }}>Not enough attempts per chapter yet.</p>
                ) : (
                  <div className="divide-y" style={{ borderColor: 'var(--border)' }}>
                    {analytics.weaknesses.map((row) => <ChapterBar key={`${row.subject}-${row.chapter}`} row={row} tone="weak" />)}
                  </div>
                )}
              </div>
            </div>

            {/* AI insight */}
            <div className="jbr-card p-5 flex items-start gap-3">
              <div className="w-9 h-9 rounded-xl flex items-center justify-center shrink-0" style={{ background: 'var(--panel-bg)', border: '1px solid var(--gold)' }}>
                <Sparkles size={16} color="var(--gold-bright)" />
              </div>
              <div>
                <p className="jbr-label text-[10px] mb-1" style={{ color: 'var(--text-muted)' }}>AI INSIGHT · FROM YOUR LATEST TEST</p>
                <p className="text-sm" style={{ color: 'var(--text-main)' }}>{analytics.latestFeedback}</p>
              </div>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
