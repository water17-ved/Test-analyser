/* ============================================================
   FIREBASE SINGLETON
   Single init point for the entire frontend. Three design decisions:

   1. Graceful degradation — if VITE_FIREBASE_API_KEY is not set (e.g.
      freshly cloned repo without a .env), the module still loads without
      throwing. FIREBASE_CONFIGURED is false, auth/db/storage are null,
      and components fall back to mock/localStorage data instead of
      crashing. This makes local dev possible with zero Firebase setup.

   2. No duplicate init — getApps() guard prevents a second initializeApp()
      call on hot-reloads, which throws in dev mode.

   3. One import path — every component imports { auth, db, FIREBASE_CONFIGURED }
      from './firebase', never from 'firebase/*' directly. This keeps the SDK
      version and emulator wiring as a single concern here, not scattered
      across every file that talks to Firestore.

   Setup instructions (see .env.example):
     1. Firebase Console → Project Settings → Your apps → Web app
     2. Copy config values into .env
     3. Authentication → enable Anonymous (+ Google if needed)
     4. Firestore + Storage → create in production mode
     5. Optional: set VITE_USE_EMULATOR=true to run against local emulators
   ============================================================ */

import { initializeApp, getApps } from 'firebase/app';
import { getAuth, signInAnonymously, connectAuthEmulator } from 'firebase/auth';
import {
  initializeFirestore,
  connectFirestoreEmulator,
  persistentLocalCache,
  persistentMultipleTabManager,
} from 'firebase/firestore';
import { getStorage, connectStorageEmulator } from 'firebase/storage';

const REQUIRED_VARS = [
  'VITE_FIREBASE_API_KEY',
  'VITE_FIREBASE_AUTH_DOMAIN',
  'VITE_FIREBASE_PROJECT_ID',
  'VITE_FIREBASE_STORAGE_BUCKET',
  'VITE_FIREBASE_MESSAGING_SENDER_ID',
  'VITE_FIREBASE_APP_ID',
];

// True when all required env vars are present. Gates all Firestore/Storage calls.
export const FIREBASE_CONFIGURED = REQUIRED_VARS.every((k) => !!import.meta.env[k]);

// Namespaces every Firestore/Storage path. Lets dev/staging/prod share one
// Firebase project if needed without data collisions.
export const APP_ID = import.meta.env.VITE_APP_ID || 'test-analytics-app';

let _auth    = null;
let _db      = null;
let _storage = null;

if (FIREBASE_CONFIGURED) {
  const app = getApps().length
    ? getApps()[0]
    : initializeApp({
        apiKey:            import.meta.env.VITE_FIREBASE_API_KEY,
        authDomain:        import.meta.env.VITE_FIREBASE_AUTH_DOMAIN,
        projectId:         import.meta.env.VITE_FIREBASE_PROJECT_ID,
        storageBucket:     import.meta.env.VITE_FIREBASE_STORAGE_BUCKET,
        messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID,
        appId:             import.meta.env.VITE_FIREBASE_APP_ID,
      });

  _auth    = getAuth(app);
  // Firebase 10: persistence is configured at init time via initializeFirestore,
  // not as a post-init call. persistentMultipleTabManager allows multiple tabs
  // to share the same IndexedDB cache without locking conflicts.
  _db      = initializeFirestore(app, {
    localCache: persistentLocalCache({
      tabManager: persistentMultipleTabManager(),
    }),
  });
  _storage = getStorage(app);

  // Emulator support — run `firebase emulators:start` and set
  // VITE_USE_EMULATOR=true to develop without burning free-tier quota.
  // MUST run before any other SDK call touches auth/db/storage.
  if (import.meta.env.VITE_USE_EMULATOR === 'true') {
    connectAuthEmulator(_auth, 'http://127.0.0.1:9099', { disableWarnings: true });
    connectFirestoreEmulator(_db, '127.0.0.1', 8080);
    connectStorageEmulator(_storage, '127.0.0.1', 9199);
    console.info('[firebase] Connected to local emulators.');
  }
}

export const auth    = _auth;
export const db      = _db;
export const storage = _storage;

// ---------------------------------------------------------------------------
// Auth — anonymous sign-in so students can use the app without creating an
// account. Once Dev 3 adds Google Sign-In this function gains a 'google' mode
// without changing any callers (they just start getting a real uid back).
//
// Returns the signed-in User, or null if Firebase isn't configured.
// Never throws — if sign-in fails the app runs in demo/mock mode.
// ---------------------------------------------------------------------------
export async function authenticateUser() {
  if (!FIREBASE_CONFIGURED || !_auth) return null;

  // Already signed in (e.g. returning visitor with a persisted session)
  if (_auth.currentUser) return _auth.currentUser;

  try {
    const credential = await signInAnonymously(_auth);
    return credential.user;
  } catch (err) {
    // Non-fatal: the app falls back to localStorage/mock data.
    // Common causes: network offline, project not yet created.
    console.warn('[firebase] Anonymous sign-in failed:', err.code, err.message);
    return null;
  }
}
