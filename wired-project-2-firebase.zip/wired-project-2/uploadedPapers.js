/* ============================================================
   UPLOADED PAPERS — shared between UploadScreen and
   QuestionPapersPreview so a successful upload actually shows up
   in the Question Papers list, instead of the two screens using
   disconnected mock data.

   This is a stand-in for a real Firestore write+read against
   /tests/{testId} (see the plan's schema). Persisted to
   localStorage for now, same pattern as useBookmarks() in
   QuestionPapersPreview. Once Dev 3's backend exists, saveUploadedPaper
   becomes a Firestore write and getUploadedPapers becomes a query —
   nothing that reads paper.subjects/.title/.questionCount elsewhere
   needs to change.
   ============================================================ */
const UPLOADED_PAPERS_KEY = 'jbr_uploaded_papers_v1';

export function getUploadedPapers() {
  try {
    const raw = localStorage.getItem(UPLOADED_PAPERS_KEY);
    const parsed = raw ? JSON.parse(raw) : [];
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

/* Turns an UploadScreen submit payload into a paper object matching
   QuestionPapersPreview's shape. We don't have real Gemini parsing
   yet, so `subjects` starts as empty arrays per selected subject —
   `status: 'processing'` marks that clearly in the UI rather than
   silently showing "0 questions" like something went wrong. */
export function saveUploadedPaper(payload) {
  const { testName, subjects, paperMode, totalQuestions } = payload;

  const emptySubjects = {};
  subjects.forEach((key) => { emptySubjects[key] = []; });

  const paper = {
    id: `upload-${Date.now()}`,
    title: testName,
    uploadedOn: new Date().toISOString().slice(0, 10),
    questionCount: paperMode === 'combined' && totalQuestions ? totalQuestions : 0,
    subjects: emptySubjects,
    status: 'processing', // becomes 'ready' once real parsing writes actual questions in
  };

  try {
    const existing = getUploadedPapers();
    localStorage.setItem(UPLOADED_PAPERS_KEY, JSON.stringify([paper, ...existing]));
  } catch {
    // Storage unavailable — the paper still shows in this session via
    // the in-memory success screen, it just won't survive a refresh.
  }

  return paper;
}
