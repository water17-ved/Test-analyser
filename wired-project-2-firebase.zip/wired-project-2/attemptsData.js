/* ============================================================
   SHARED ATTEMPTS DATA
   Single source of truth for test attempt records.

   Both TestsTab and OverallAnalytics import from here so:
   - Adding a test appears in both screens automatically
   - The two screens can never drift out of sync on mock data
   - The Firestore swap is one change: replace this array with a
     real listStudentAttempts() call in the consuming hooks

   Schema (superset — OverallAnalytics only reads the fields it needs):
   {
     id, testTitle, date, totalScore, maxScore, paperId?,
     aiFeedback, aiRecommendations[],
     topicBreakdown[]:    { subject, chapter, correct, incorrect, unattempted }
     difficultyBreakdown[]: { subject, difficulty, correct, incorrect, unattempted }
   }
   ============================================================ */

/* All attempt records now live in testsStorage.js (localStorage).
   This array is kept as an empty export so any file that still imports
   MOCK_ATTEMPTS doesn't crash during the migration — each consuming
   screen should switch to getTests() from testsStorage.js. */
export const MOCK_ATTEMPTS = [
  // empty — real data is in localStorage via testsStorage.js
  /*
  {
    id: 'attempt-1',
    testTitle: 'Weekly Test 1',
    date: '2026-07-14',
    totalScore: 58,
    maxScore: 100,
    paperId: null,
    aiFeedback: "Waves is coming along, but Basic Organic Chemistry nomenclature and Hydrocarbon acidity comparisons need another pass — you're guessing on priority-order and resonance questions rather than reasoning through them.",
    aiRecommendations: [
      'Drill IUPAC priority order rules for polyfunctional compounds — do 15 naming exercises.',
      'Revisit carbanion stability in Hydrocarbons before the next test.',
      'For Waves, focus on Doppler effect numericals — 4 of your 5 errors were calculation-type.',
    ],
    topicBreakdown: [
      { subject: 'physics',   chapter: 'Waves',                          correct: 2, incorrect: 3, unattempted: 0 },
      { subject: 'physics',   chapter: 'Oscillations',                   correct: 1, incorrect: 1, unattempted: 0 },
      { subject: 'chemistry', chapter: 'Basic Organic Chemistry',         correct: 1, incorrect: 2, unattempted: 1 },
      { subject: 'chemistry', chapter: 'Hydrocarbons',                    correct: 0, incorrect: 2, unattempted: 0 },
      { subject: 'maths',     chapter: 'Continuity & Differentiability',  correct: 3, incorrect: 1, unattempted: 0 },
      { subject: 'maths',     chapter: 'Limits',                          correct: 1, incorrect: 1, unattempted: 0 },
    ],
    difficultyBreakdown: [
      { subject: 'physics',   difficulty: 'Easy',     correct: 2, incorrect: 1, unattempted: 0 },
      { subject: 'physics',   difficulty: 'Moderate', correct: 1, incorrect: 2, unattempted: 0 },
      { subject: 'physics',   difficulty: 'Tough',    correct: 0, incorrect: 1, unattempted: 0 },
      { subject: 'chemistry', difficulty: 'Easy',     correct: 1, incorrect: 1, unattempted: 0 },
      { subject: 'chemistry', difficulty: 'Moderate', correct: 0, incorrect: 2, unattempted: 1 },
      { subject: 'chemistry', difficulty: 'Tough',    correct: 0, incorrect: 1, unattempted: 0 },
      { subject: 'maths',     difficulty: 'Easy',     correct: 2, incorrect: 0, unattempted: 0 },
      { subject: 'maths',     difficulty: 'Moderate', correct: 2, incorrect: 1, unattempted: 0 },
      { subject: 'maths',     difficulty: 'Tough',    correct: 0, incorrect: 1, unattempted: 0 },
    ],
  },
  {
    id: 'attempt-2',
    testTitle: 'Weekly Test 2',
    date: '2026-07-21',
    totalScore: 64,
    maxScore: 100,
    paperId: null,
    aiFeedback: 'Clear improvement on Waves and Continuity & Differentiability. Hydrocarbons is still the weakest link — revisit relative stability of carbanions before the next attempt.',
    aiRecommendations: [
      'Aldehydes/Carboxylic Acids: practice acidic strength ordering — inductive effect series.',
      'Hydrocarbons: carbanion stability is the recurring gap. One focused session should fix it.',
      'Application of Derivatives: monotonicity questions were hit-or-miss. Revisit the interval test method.',
    ],
    topicBreakdown: [
      { subject: 'physics',   chapter: 'Waves',                                correct: 3, incorrect: 2, unattempted: 0 },
      { subject: 'physics',   chapter: 'Oscillations',                         correct: 2, incorrect: 0, unattempted: 1 },
      { subject: 'chemistry', chapter: 'Aldehydes, Ketones & Carboxylic Acids', correct: 2, incorrect: 2, unattempted: 0 },
      { subject: 'chemistry', chapter: 'Hydrocarbons',                          correct: 1, incorrect: 1, unattempted: 0 },
      { subject: 'maths',     chapter: 'Application of Derivatives',            correct: 2, incorrect: 1, unattempted: 0 },
      { subject: 'maths',     chapter: 'Continuity & Differentiability',        correct: 3, incorrect: 1, unattempted: 0 },
    ],
    difficultyBreakdown: [
      { subject: 'physics',   difficulty: 'Easy',     correct: 3, incorrect: 0, unattempted: 0 },
      { subject: 'physics',   difficulty: 'Moderate', correct: 2, incorrect: 1, unattempted: 1 },
      { subject: 'physics',   difficulty: 'Tough',    correct: 0, incorrect: 1, unattempted: 0 },
      { subject: 'chemistry', difficulty: 'Easy',     correct: 2, incorrect: 0, unattempted: 0 },
      { subject: 'chemistry', difficulty: 'Moderate', correct: 1, incorrect: 2, unattempted: 0 },
      { subject: 'chemistry', difficulty: 'Tough',    correct: 0, incorrect: 1, unattempted: 0 },
      { subject: 'maths',     difficulty: 'Easy',     correct: 2, incorrect: 0, unattempted: 0 },
      { subject: 'maths',     difficulty: 'Moderate', correct: 2, incorrect: 1, unattempted: 0 },
      { subject: 'maths',     difficulty: 'Tough',    correct: 1, incorrect: 1, unattempted: 0 },
    ],
  },
  {
    id: 'attempt-3',
    testTitle: 'Weekly Test 3',
    date: '2026-07-28',
    totalScore: 71,
    maxScore: 100,
    paperId: null,
    aiFeedback: "Waves and Application of Derivatives are strong now — treat them as scoring guarantees. Acidic-strength ordering in Aldehydes/Carboxylic Acids is the next thing worth drilling.",
    aiRecommendations: [
      'Aldehydes/Carboxylic Acids acidity ordering: do a comparison table of inductive effects.',
      "Limits: the L'Hopital vs factorisation choice is slowing you down — build a decision rule.",
      'Oscillations damping questions: revisit exponential decay formula derivation.',
    ],
    topicBreakdown: [
      { subject: 'physics',   chapter: 'Waves',                                correct: 4, incorrect: 1, unattempted: 0 },
      { subject: 'physics',   chapter: 'Oscillations',                         correct: 1, incorrect: 1, unattempted: 0 },
      { subject: 'chemistry', chapter: 'Basic Organic Chemistry',               correct: 2, incorrect: 1, unattempted: 0 },
      { subject: 'chemistry', chapter: 'Aldehydes, Ketones & Carboxylic Acids', correct: 3, incorrect: 1, unattempted: 0 },
      { subject: 'maths',     chapter: 'Limits',                                correct: 2, incorrect: 0, unattempted: 1 },
      { subject: 'maths',     chapter: 'Application of Derivatives',            correct: 3, incorrect: 1, unattempted: 0 },
    ],
    difficultyBreakdown: [
      { subject: 'physics',   difficulty: 'Easy',     correct: 3, incorrect: 0, unattempted: 0 },
      { subject: 'physics',   difficulty: 'Moderate', correct: 2, incorrect: 1, unattempted: 0 },
      { subject: 'physics',   difficulty: 'Tough',    correct: 0, incorrect: 1, unattempted: 0 },
      { subject: 'chemistry', difficulty: 'Easy',     correct: 2, incorrect: 0, unattempted: 0 },
      { subject: 'chemistry', difficulty: 'Moderate', correct: 2, incorrect: 1, unattempted: 0 },
      { subject: 'chemistry', difficulty: 'Tough',    correct: 1, incorrect: 1, unattempted: 0 },
      { subject: 'maths',     difficulty: 'Easy',     correct: 2, incorrect: 0, unattempted: 0 },
      { subject: 'maths',     difficulty: 'Moderate', correct: 2, incorrect: 0, unattempted: 1 },
      { subject: 'maths',     difficulty: 'Tough',    correct: 1, incorrect: 1, unattempted: 0 },
    ],
  },
  {
    id: 'attempt-4',
    testTitle: 'JEE/NEET 020826',
    date: '2026-08-02',
    totalScore: 79,
    maxScore: 100,
    paperId: 'jee-neet-020826',
    aiFeedback: 'Best attempt yet. Waves and Limits were nearly flawless. Aldehydes/Carboxylic Acids acidity ordering is the one recurring miss across the last three tests — worth a focused revision session.',
    aiRecommendations: [
      'Aldehydes/Carboxylic Acids: this is the 3rd consecutive test with an acidity ordering error. Dedicate one full session.',
      'Continuity & Differentiability: the one miss was a parametric differentiation question — review the chain rule for parametric forms.',
      'Time management: you spent efficiently but Physics unattempted question cost you — attempt first, mark for review if unsure.',
    ],
    topicBreakdown: [
      { subject: 'physics',   chapter: 'Waves',                                correct: 4, incorrect: 0, unattempted: 1 },
      { subject: 'physics',   chapter: 'Oscillations',                         correct: 1, incorrect: 0, unattempted: 0 },
      { subject: 'chemistry', chapter: 'Basic Organic Chemistry',               correct: 1, incorrect: 0, unattempted: 0 },
      { subject: 'chemistry', chapter: 'Aldehydes, Ketones & Carboxylic Acids', correct: 2, incorrect: 1, unattempted: 0 },
      { subject: 'chemistry', chapter: 'Hydrocarbons',                          correct: 1, incorrect: 0, unattempted: 0 },
      { subject: 'maths',     chapter: 'Application of Derivatives',            correct: 1, incorrect: 0, unattempted: 0 },
      { subject: 'maths',     chapter: 'Continuity & Differentiability',        correct: 2, incorrect: 1, unattempted: 0 },
      { subject: 'maths',     chapter: 'Limits',                                correct: 1, incorrect: 0, unattempted: 0 },
    ],
    difficultyBreakdown: [
      { subject: 'physics',   difficulty: 'Easy',     correct: 3, incorrect: 0, unattempted: 0 },
      { subject: 'physics',   difficulty: 'Moderate', correct: 2, incorrect: 0, unattempted: 0 },
      { subject: 'physics',   difficulty: 'Tough',    correct: 0, incorrect: 0, unattempted: 1 },
      { subject: 'chemistry', difficulty: 'Easy',     correct: 2, incorrect: 0, unattempted: 0 },
      { subject: 'chemistry', difficulty: 'Moderate', correct: 2, incorrect: 0, unattempted: 0 },
      { subject: 'chemistry', difficulty: 'Tough',    correct: 0, incorrect: 1, unattempted: 0 },
      { subject: 'maths',     difficulty: 'Easy',     correct: 2, incorrect: 0, unattempted: 0 },
      { subject: 'maths',     difficulty: 'Moderate', correct: 1, incorrect: 1, unattempted: 0 },
      { subject: 'maths',     difficulty: 'Tough',    correct: 1, incorrect: 0, unattempted: 0 },
    ],
  },
  */
];
