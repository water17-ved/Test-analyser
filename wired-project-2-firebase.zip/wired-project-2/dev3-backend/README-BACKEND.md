# Backend Runbook — Dev 3 (Firebase Auth / Firestore / Storage)

Owns everything under `firebaseConfig.js`, `firestoreService.js`,
`storageService.js`, `validators.js`, `errors.js`, and the two `.rules` files.
Dev 1 and Dev 2 should **never** import `firebase/firestore` or
`firebase/storage` directly — they call into `firestoreService.js` /
`storageService.js` only. That boundary is what keeps this maintainable
past Day 4.

---

## 1. File map & why it's split this way

| File | Responsibility |
|---|---|
| `firebaseConfig.js` | SDK init only. Env validation, emulator wiring, offline persistence. No business logic. |
| `errors.js` | Typed errors (`AuthenticationError`, `ValidationError`, `NotFoundError`, `ServiceUnavailableError`) so the UI can branch on `err.code` instead of string-matching messages. |
| `validators.js` | Enforces Contract A (`TestPaper`) and Contract B (`AttemptData`) **before** any write. Gemini's JSON output is a suggestion, not a guarantee — this is the checkpoint. |
| `firestoreService.js` | All Firestore reads/writes. Retry-with-backoff on transient errors, pagination on every list query, atomic transaction for attempt + stats aggregate. |
| `storageService.js` | File upload/delete with progress callback, client-side pre-validation mirroring `storage.rules`. |
| `firestore.rules` / `storage.rules` | The actual security boundary — schema-validating, not just auth-checking. Assume the client-side validators can be bypassed; these cannot. |
| `firestore.indexes.json` | Composite indexes for the filtered/ordered queries in `listTestPapers`. |
| `firebase.json` | Wires rules/indexes + local emulator ports. |

**Why a service layer instead of calling Firestore directly from
components?** Three developers, four days, one shared repo. If Dev 2
writes `getDocs(collection(db, 'artifacts', ...))` inline in a React
component, and the path structure changes on Day 3 during integration,
you're now hunting for every inline call site under time pressure. One
service layer = one place to change.

---

## 2. First-time setup

```bash
npm install firebase
cp .env.example .env
# fill in .env with values from Firebase Console → Project Settings → Web app
```

Firebase Console steps (one-time):
1. Create project → Add Web App → copy config into `.env`.
2. **Authentication** → Sign-in method → enable **Anonymous**.
3. **Firestore Database** → Create database → **production mode**
   (we ship real rules from Day 1, so there's no reason to start in
   permissive test mode and forget to lock it down later — that's how
   free-tier projects get scraped or spammed).
4. **Storage** → Get started → same region as Firestore (cross-region
   adds latency and, on paid tiers, egress cost).

```bash
npm install -g firebase-tools
firebase login
firebase init   # choose "Use an existing project", point to the files above
```

---

## 3. Local development with the emulator suite (do this, don't skip it)

Free-tier Firestore is capped at **50K reads / 20K writes / 20K deletes
per day**. Three developers iterating against production Firestore all
day will hit that ceiling before lunch on Day 2 — and once you're
rate-limited, every developer is blocked, not just the one who caused it.

```bash
firebase emulators:start
```

Then in `.env`:
```
VITE_USE_EMULATOR=true
```

`firebaseConfig.js` detects this and routes Auth/Firestore/Storage to
`localhost` automatically — zero code changes needed elsewhere. Emulator
UI is at `http://localhost:4000` and lets you inspect documents, auth
users, and storage objects in real time. Set `VITE_USE_EMULATOR=false`
(or remove it) when you're ready to test against real Firebase, e.g.
right before the Day 3 integration merge.

---

## 4. Deploying rules & indexes

```bash
firebase deploy --only firestore:rules,firestore:indexes,storage:rules
```

Do this any time you touch `firestore.rules`, `storage.rules`, or
`firestore.indexes.json`. Rules changes are **not** picked up by Vercel's
frontend deploy — they live on the Firebase project, not in your app bundle.
Forgetting this step is the most common "it works on my machine
(emulator) but not in prod" bug on a project like this.

---

## 5. Data model (as actually enforced)

```
artifacts/{APP_ID}/
├── public/data/tests/{testId}        → TestPaper (readable by any signed-in user)
└── users/{uid}/
    ├── attempts/{attemptId}          → AttemptData (owner-only)
    └── meta/stats                    → { attemptCount, avgAccuracy, lastAttemptAt }
                                         (owner-only, written atomically alongside
                                          each attempt via a Firestore transaction —
                                          see saveStudentAttempt)
```

Storage:
```
uploads/{uid}/{timestamp}-{filename}   → PDF/image, ≤15MB, owner-only
```

---

## 6. Security model — defense in depth, three layers

1. **`validators.js`** (client, developer-facing): catches malformed
   Gemini output early with a specific, readable error. Bypassable by
   a determined attacker — not the real boundary.
2. **`firestore.rules` / `storage.rules`** (server-enforced, non-bypassable):
   re-validates schema shape, ownership, and field constraints
   independently of the client. This is what actually protects the data
   if someone opens dev tools and calls the SDK directly with garbage.
3. **`errors.js`**: normalizes whatever Firebase throws into typed errors
   so failures at any layer surface consistently to the UI.

Assume layer 1 will be bypassed. Never assume layer 2 will be.

---

## 7. Known limitations / explicitly deferred (documented, not accidental)

- **No role-based access (teacher vs. student).** Any signed-in
  (including anonymous) user can currently write a `TestPaper`. Fine
  for a 4-day demo scope; before any real use, add a custom auth claim
  (`isTeacher`) and gate `public/data/tests` writes on it.
- **No rate limiting beyond Firebase's own quota.** A malicious or
  buggy client could still spam writes within Firestore's normal limits.
  Acceptable for sprint scope; Cloud Functions + App Check would be the
  next step for a production launch.
- **Anonymous auth means attempt history is device-bound**, not
  account-bound, unless you also enable Google sign-in and prompt users
  to link their anonymous account (`linkWithCredential`) before it expires.

---

## 8. Day 1 sign-off checklist

- [ ] `.env` filled in, app boots without the "Missing required env vars" error
- [ ] `firebase emulators:start` runs; app connects to it with `VITE_USE_EMULATOR=true`
- [ ] Can call `authenticateUser()` → `auth.currentUser` is populated
- [ ] `saveTestPaper()` with a valid TestPaper succeeds; with a missing field, throws `ValidationError` with a useful `details` array
- [ ] `saveStudentAttempt()` succeeds and `getStudentStats()` reflects the updated `attemptCount`/`avgAccuracy`
- [ ] `uploadFile()` with a 20MB file is rejected client-side before any network call
- [ ] `firebase deploy --only firestore:rules,storage:rules` succeeds against the real project
