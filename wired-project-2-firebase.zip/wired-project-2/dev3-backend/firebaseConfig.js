// firebaseConfig.js
// Dev 3 — Backend & Database Architect
// SINGLE RESPONSIBILITY: initialize Firebase SDK instances only.
// All CRUD logic lives in firestoreService.js / storageService.js —
// keeping this file init-only means it can be imported anywhere
// (including test setup) without pulling in business logic.
//
// Firebase Console setup:
// 1. https://console.firebase.google.com → Create project
// 2. Add a Web App → copy config into .env (see .env.example)
// 3. Authentication → Sign-in method → enable Anonymous (+ Google if needed)
// 4. Firestore Database → create (production mode — we ship real rules, not test mode)
// 5. Storage → enable (same region as Firestore to avoid cross-region latency/cost)

import { initializeApp } from 'firebase/app';
import { getAuth, connectAuthEmulator } from 'firebase/auth';
import {
  initializeFirestore,
  connectFirestoreEmulator,
  persistentLocalCache,
  persistentMultipleTabManager,
} from 'firebase/firestore';
import { getStorage, connectStorageEmulator } from 'firebase/storage';

// ---------------------------------------------------------------------------
// Fail fast at boot when env vars are missing — surfaces a clear message
// rather than a cryptic SDK error three screens deep.
// Wrapped in a try so a missing .env doesn't crash the module during build.
// ---------------------------------------------------------------------------
const REQUIRED_ENV_VARS = [
  'VITE_FIREBASE_API_KEY',
  'VITE_FIREBASE_AUTH_DOMAIN',
  'VITE_FIREBASE_PROJECT_ID',
  'VITE_FIREBASE_STORAGE_BUCKET',
  'VITE_FIREBASE_MESSAGING_SENDER_ID',
  'VITE_FIREBASE_APP_ID',
];

function assertEnv() {
  const missing = REQUIRED_ENV_VARS.filter((key) => !import.meta.env[key]);
  if (missing.length > 0) {
    throw new Error(
      `[firebaseConfig] Missing required env vars: ${missing.join(', ')}. ` +
      `Copy .env.example to .env and fill in your Firebase web app config.`
    );
  }
}
assertEnv();

const firebaseConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY,
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN,
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID,
  storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID,
  appId: import.meta.env.VITE_FIREBASE_APP_ID,
};

// Namespaces every Firestore/Storage path — lets you run dev/staging/prod
// against the same Firebase project without data collisions if you ever need to.
export const APP_ID = import.meta.env.VITE_APP_ID || 'test-analytics-app';

// ---------------------------------------------------------------------------
// Init
// ---------------------------------------------------------------------------
export const app     = initializeApp(firebaseConfig);
export const auth    = getAuth(app);
// Firebase 10: persistence configured at init, not post-init.
export const db      = initializeFirestore(app, {
  localCache: persistentLocalCache({
    tabManager: persistentMultipleTabManager(),
  }),
});
export const storage = getStorage(app);

// ---------------------------------------------------------------------------
// Local emulator support.
// ---------------------------------------------------------------------------
if (import.meta.env.VITE_USE_EMULATOR === 'true') {
  connectAuthEmulator(auth, 'http://127.0.0.1:9099', { disableWarnings: true });
  connectFirestoreEmulator(db, '127.0.0.1', 8080);
  connectStorageEmulator(storage, '127.0.0.1', 9199);
  // eslint-disable-next-line no-console
  console.info('[firebaseConfig] Connected to local Firebase emulators.');
}
