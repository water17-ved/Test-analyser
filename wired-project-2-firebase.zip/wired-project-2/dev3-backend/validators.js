// validators.js
// Dev 3 — Backend & Database Architect
//
// WHY THIS FILE EXISTS:
// Dev 1's Gemini pipeline returns JSON, but "returns JSON matching the
// schema" is a prompt instruction, not a guarantee. Models drop fields,
// invent extra ones, return strings where numbers belong, or occasionally
// hallucinate a whole malformed object. If that goes straight into
// Firestore, Dev 2's dashboard breaks at render time with a confusing
// "cannot read property of undefined" three components deep.
//
// This is the checkpoint: validate the shape BEFORE it's written, fail
// loudly with a specific reason, and never let bad data become "someone
// else's problem" downstream. Firestore security rules (see firestore.rules)
// are the second, non-bypassable line of defense — this is the first,
// developer-friendly one that gives you a useful error message.

import { ValidationError } from './errors.js';

const DIFFICULTIES = new Set(['Easy', 'Medium', 'Hard']);

function isNonEmptyString(v) {
  return typeof v === 'string' && v.trim().length > 0;
}
function isFiniteNumber(v) {
  return typeof v === 'number' && Number.isFinite(v);
}
function isNumberInRange(v, min, max) {
  return isFiniteNumber(v) && v >= min && v <= max;
}

// ---------------------------------------------------------------------------
// Contract A — TestPaper
// ---------------------------------------------------------------------------
export function validateTestPaper(data) {
  const problems = [];

  if (!data || typeof data !== 'object') {
    throw new ValidationError('TestPaper must be an object.', ['root: not an object']);
  }

  if (!isNonEmptyString(data.testId)) problems.push('testId: required non-empty string');
  if (!isNonEmptyString(data.testTitle)) problems.push('testTitle: required non-empty string');
  if (!isNonEmptyString(data.subject)) problems.push('subject: required non-empty string');
  if (!isFiniteNumber(data.totalMarks) || data.totalMarks <= 0) {
    problems.push('totalMarks: required positive number');
  }
  if (!Array.isArray(data.questions) || data.questions.length === 0) {
    problems.push('questions: required non-empty array');
  } else {
    data.questions.forEach((q, i) => {
      const prefix = `questions[${i}]`;
      if (!isFiniteNumber(q.questionNumber)) problems.push(`${prefix}.questionNumber: required number`);
      if (!isNonEmptyString(q.questionText)) problems.push(`${prefix}.questionText: required string`);
      if (!Array.isArray(q.options) || q.options.length < 2) {
        problems.push(`${prefix}.options: required array with 2+ items`);
      }
      if (!isNonEmptyString(q.correctAnswer)) problems.push(`${prefix}.correctAnswer: required string`);
      if (Array.isArray(q.options) && isNonEmptyString(q.correctAnswer) && !q.options.includes(q.correctAnswer)) {
        problems.push(`${prefix}.correctAnswer: must be one of options`);
      }
      if (!isNonEmptyString(q.chapter)) problems.push(`${prefix}.chapter: required string`);
      if (!isNonEmptyString(q.topic)) problems.push(`${prefix}.topic: required string`);
      if (!DIFFICULTIES.has(q.difficulty)) {
        problems.push(`${prefix}.difficulty: must be one of Easy|Medium|Hard`);
      }
      if (!isFiniteNumber(q.marks) || q.marks <= 0) problems.push(`${prefix}.marks: required positive number`);
    });
  }

  if (problems.length > 0) {
    throw new ValidationError(
      `TestPaper failed validation (${problems.length} issue${problems.length > 1 ? 's' : ''}).`,
      problems
    );
  }
  return true;
}

// ---------------------------------------------------------------------------
// Contract B — AttemptData
// ---------------------------------------------------------------------------
export function validateAttemptData(data) {
  const problems = [];

  if (!data || typeof data !== 'object') {
    throw new ValidationError('AttemptData must be an object.', ['root: not an object']);
  }

  if (!isNonEmptyString(data.attemptId)) problems.push('attemptId: required non-empty string');
  if (!isNonEmptyString(data.testId)) problems.push('testId: required non-empty string');
  if (!isNonEmptyString(data.studentId)) problems.push('studentId: required non-empty string');
  if (!isNonEmptyString(data.timestamp) || Number.isNaN(Date.parse(data.timestamp))) {
    problems.push('timestamp: required ISO 8601 date string');
  }
  if (!isFiniteNumber(data.totalScore) || data.totalScore < 0) problems.push('totalScore: required number >= 0');
  if (!isFiniteNumber(data.maxMarks) || data.maxMarks <= 0) problems.push('maxMarks: required positive number');
  if (!isNumberInRange(data.accuracyPercentage, 0, 100)) {
    problems.push('accuracyPercentage: required number 0-100');
  }
  if (isFiniteNumber(data.totalScore) && isFiniteNumber(data.maxMarks) && data.totalScore > data.maxMarks) {
    problems.push('totalScore: cannot exceed maxMarks');
  }

  if (!Array.isArray(data.topicBreakdown) || data.topicBreakdown.length === 0) {
    problems.push('topicBreakdown: required non-empty array');
  } else {
    data.topicBreakdown.forEach((t, i) => {
      const prefix = `topicBreakdown[${i}]`;
      if (!isNonEmptyString(t.chapter)) problems.push(`${prefix}.chapter: required string`);
      if (!isNonEmptyString(t.topic)) problems.push(`${prefix}.topic: required string`);
      if (!isFiniteNumber(t.totalQuestions) || t.totalQuestions <= 0) {
        problems.push(`${prefix}.totalQuestions: required positive number`);
      }
      if (!isFiniteNumber(t.correct) || t.correct < 0) problems.push(`${prefix}.correct: required number >= 0`);
      if (isFiniteNumber(t.correct) && isFiniteNumber(t.totalQuestions) && t.correct > t.totalQuestions) {
        problems.push(`${prefix}.correct: cannot exceed totalQuestions`);
      }
      if (!isNumberInRange(t.accuracy, 0, 100)) problems.push(`${prefix}.accuracy: required number 0-100`);
    });
  }

  if (!Array.isArray(data.topWeaknesses)) problems.push('topWeaknesses: required array (can be empty)');
  if (!Array.isArray(data.recommendedActionPlan)) {
    problems.push('recommendedActionPlan: required array (can be empty)');
  }

  if (problems.length > 0) {
    throw new ValidationError(
      `AttemptData failed validation (${problems.length} issue${problems.length > 1 ? 's' : ''}).`,
      problems
    );
  }
  return true;
}
