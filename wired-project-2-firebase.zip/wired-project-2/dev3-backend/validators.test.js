// validators.test.js
// Run with: npx vitest run
//
// These tests exist because validators.js is the checkpoint that decides
// whether garbage from Gemini reaches production data. Untested validation
// logic is worse than no validation logic — it gives false confidence.

import { describe, it, expect } from 'vitest';
import { validateTestPaper, validateAttemptData } from './validators.js';
import { ValidationError } from './errors.js';

const validQuestion = {
  questionNumber: 1,
  questionText: 'What is the SI unit of Force?',
  options: ['Joule', 'Newton', 'Watt', 'Pascal'],
  correctAnswer: 'Newton',
  chapter: 'Laws of Motion',
  topic: 'Units and Dimensions',
  difficulty: 'Easy',
  marks: 4,
};

const validTestPaper = {
  testId: 'physics-mock-01',
  testTitle: 'Physics Chapterwise Mock Test 1',
  subject: 'Physics',
  totalMarks: 100,
  questions: [validQuestion],
};

const validAttempt = {
  attemptId: 'att-99821',
  testId: 'physics-mock-01',
  studentId: 'user_xyz',
  timestamp: '2026-08-03T16:00:00Z',
  totalScore: 76,
  maxMarks: 100,
  accuracyPercentage: 76.0,
  topicBreakdown: [
    { chapter: 'Laws of Motion', topic: 'Units and Dimensions', totalQuestions: 5, correct: 4, accuracy: 80.0 },
  ],
  topWeaknesses: ['Carnot Cycle efficiency calculations'],
  recommendedActionPlan: ['Review Carnot Engine formulas.'],
};

describe('validateTestPaper', () => {
  it('accepts a valid TestPaper matching Contract A', () => {
    expect(validateTestPaper(validTestPaper)).toBe(true);
  });

  it('rejects null/non-object input', () => {
    expect(() => validateTestPaper(null)).toThrow(ValidationError);
    expect(() => validateTestPaper('not an object')).toThrow(ValidationError);
  });

  it('rejects a missing testId', () => {
    const { testId, ...rest } = validTestPaper;
    expect(() => validateTestPaper(rest)).toThrow(ValidationError);
  });

  it('rejects an empty questions array', () => {
    expect(() => validateTestPaper({ ...validTestPaper, questions: [] })).toThrow(ValidationError);
  });

  it('rejects a correctAnswer not present in options (common Gemini hallucination)', () => {
    const badQuestion = { ...validQuestion, correctAnswer: 'Ampere' };
    expect(() => validateTestPaper({ ...validTestPaper, questions: [badQuestion] })).toThrow(ValidationError);
  });

  it('rejects an invalid difficulty value', () => {
    const badQuestion = { ...validQuestion, difficulty: 'Impossible' };
    expect(() => validateTestPaper({ ...validTestPaper, questions: [badQuestion] })).toThrow(ValidationError);
  });

  it('rejects totalMarks <= 0', () => {
    expect(() => validateTestPaper({ ...validTestPaper, totalMarks: 0 })).toThrow(ValidationError);
  });

  it('error details list every problem found, not just the first', () => {
    try {
      validateTestPaper({ testId: '', testTitle: '', subject: '', totalMarks: -1, questions: [] });
      throw new Error('should have thrown');
    } catch (err) {
      expect(err).toBeInstanceOf(ValidationError);
      expect(err.details.length).toBeGreaterThanOrEqual(4);
    }
  });
});

describe('validateAttemptData', () => {
  it('accepts a valid AttemptData matching Contract B', () => {
    expect(validateAttemptData(validAttempt)).toBe(true);
  });

  it('rejects totalScore greater than maxMarks (impossible score)', () => {
    expect(() => validateAttemptData({ ...validAttempt, totalScore: 150 })).toThrow(ValidationError);
  });

  it('rejects accuracyPercentage outside 0-100', () => {
    expect(() => validateAttemptData({ ...validAttempt, accuracyPercentage: 140 })).toThrow(ValidationError);
    expect(() => validateAttemptData({ ...validAttempt, accuracyPercentage: -5 })).toThrow(ValidationError);
  });

  it('rejects an unparsable timestamp', () => {
    expect(() => validateAttemptData({ ...validAttempt, timestamp: 'not-a-date' })).toThrow(ValidationError);
  });

  it('rejects topicBreakdown.correct greater than totalQuestions', () => {
    const badBreakdown = [{ chapter: 'X', topic: 'Y', totalQuestions: 3, correct: 5, accuracy: 90 }];
    expect(() => validateAttemptData({ ...validAttempt, topicBreakdown: badBreakdown })).toThrow(ValidationError);
  });

  it('accepts empty topWeaknesses/recommendedActionPlan (perfect score case)', () => {
    const perfect = { ...validAttempt, totalScore: 100, accuracyPercentage: 100, topWeaknesses: [], recommendedActionPlan: [] };
    expect(validateAttemptData(perfect)).toBe(true);
  });
});
