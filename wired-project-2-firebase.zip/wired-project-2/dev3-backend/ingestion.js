// ingestion.js
// Dev 3 — Backend & Database Architect
// THE MERGE POINT: Dev 1's geminiService.js returns raw parsed JSON.
// This file is the only place that JSON is allowed to touch Firestore.
// Dev 1 never calls firestoreService directly, and Dev 3 never calls
// Gemini directly — this module is the seam between the two halves of
// the pipeline, so when integration day (Day 3 PM) comes, there's one
// well-defined contract to test, not a tangle of cross-imports.

import { saveTestPaper, saveStudentAttempt } from './firestoreService.js';
import { ValidationError } from './errors.js';

// ---------------------------------------------------------------------------
// Ingest a test paper parsed by Gemini (Prompt 1 in the blueprint).
// Gemini's output is missing `testId` (it only returns testTitle, subject,
// totalMarks, questions — see Prompt 1's schema) so we generate one here,
// deterministically, rather than trusting the model to invent a stable id.
// ---------------------------------------------------------------------------
export async function ingestTestPaperFromGemini(geminiOutput) {
  if (!geminiOutput || typeof geminiOutput !== 'object') {
    throw new ValidationError('Gemini returned no parsable object.', ['response: empty or non-JSON']);
  }

  const testId = slugify(geminiOutput.testTitle) + '-' + Date.now().toString(36);

  const testPaper = {
    testId,
    testTitle: geminiOutput.testTitle,
    subject: geminiOutput.subject,
    totalMarks: geminiOutput.totalMarks,
    questions: geminiOutput.questions,
  };

  // saveTestPaper() runs validateTestPaper() internally — if Gemini
  // hallucinated a malformed question, this throws HERE, with a specific
  // field-level reason, instead of silently corrupting the test bank.
  try {
    await saveTestPaper(testPaper);
    return { testId, questionCount: testPaper.questions?.length ?? 0 };
  } catch (err) {
    if (err instanceof ValidationError) {
      // Re-throw with ingestion context so logs/UI can tell "Gemini gave us
      // garbage" apart from "the user submitted garbage" elsewhere in the app.
      throw new ValidationError(
        `AI-extracted test paper failed validation: ${err.message}`,
        err.details
      );
    }
    throw err;
  }
}

// ---------------------------------------------------------------------------
// Ingest a student attempt evaluated by Gemini (Prompt 2 in the blueprint).
// Gemini's evaluation prompt doesn't know the signed-in user's uid — that's
// an app-layer fact, not something to trust the model to fill in correctly.
// We inject studentId and a server-verifiable timestamp/id here rather than
// accepting whatever Gemini put in those fields.
// ---------------------------------------------------------------------------
export async function ingestAttemptFromGemini(geminiOutput, { testId, studentId }) {
  if (!geminiOutput || typeof geminiOutput !== 'object') {
    throw new ValidationError('Gemini returned no parsable object.', ['response: empty or non-JSON']);
  }
  if (!studentId) {
    throw new ValidationError('studentId is required and must come from the auth session, not the AI.');
  }

  const attemptData = {
    ...geminiOutput,
    attemptId: `att-${Date.now().toString(36)}-${studentId.slice(0, 6)}`,
    testId,
    studentId,               // authoritative — overwrites anything Gemini put here
    timestamp: new Date().toISOString(), // authoritative — client clock, server timestamp added on write
  };

  try {
    await saveStudentAttempt(attemptData);
    return { attemptId: attemptData.attemptId, accuracyPercentage: attemptData.accuracyPercentage };
  } catch (err) {
    if (err instanceof ValidationError) {
      throw new ValidationError(
        `AI-evaluated attempt failed validation: ${err.message}`,
        err.details
      );
    }
    throw err;
  }
}

function slugify(str) {
  return String(str || 'test')
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 60) || 'test';
}
