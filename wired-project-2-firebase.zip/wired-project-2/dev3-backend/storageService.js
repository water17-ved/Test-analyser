// storageService.js
// Dev 3 — Backend & Database Architect
//
// Mirrors the constraints in storage.rules on the CLIENT side too. This is
// not redundant — it's defense in depth AND user experience: rejecting a
// 40MB PDF instantly with a clear message beats letting the user wait for
// a full upload attempt just to get bounced by the server-side rule.
// The rules file remains the actual security boundary; this is the
// fast-fail, friendly layer in front of it.

import { ref, uploadBytesResumable, getDownloadURL, deleteObject } from 'firebase/storage';
import { storage, auth } from './firebaseConfig.js';
import { AuthenticationError, ValidationError, normalizeFirebaseError } from './errors.js';

const MAX_FILE_BYTES = 15 * 1024 * 1024; // 15MB — keep in sync with storage.rules
const ALLOWED_TYPES = [/^application\/pdf$/, /^image\/.+/];

function requireAuth() {
  const user = auth.currentUser;
  if (!user) throw new AuthenticationError();
  return user;
}

function assertValidFile(file) {
  const problems = [];
  if (!file) problems.push('No file provided.');
  if (file && file.size > MAX_FILE_BYTES) {
    problems.push(`File is ${(file.size / 1024 / 1024).toFixed(1)}MB — max allowed is 15MB.`);
  }
  if (file && !ALLOWED_TYPES.some((re) => re.test(file.type))) {
    problems.push(`File type "${file.type || 'unknown'}" not allowed — only PDF and images.`);
  }
  if (problems.length > 0) {
    throw new ValidationError('File failed validation.', problems);
  }
}

// Uploads a file to uploads/{uid}/{timestamp}-{filename}. Accepts an
// optional onProgress(percent) callback — essential for large PDF scans
// on slow classroom wifi, where a frozen UI with no feedback reads as broken.
export async function uploadFile(file, { pathPrefix = 'uploads', onProgress } = {}) {
  const user = requireAuth();
  assertValidFile(file);

  const safeName = file.name.replace(/[^a-zA-Z0-9._-]/g, '_'); // strip path separators etc.
  const fileRef = ref(storage, `${pathPrefix}/${user.uid}/${Date.now()}-${safeName}`);

  return new Promise((resolve, reject) => {
    const task = uploadBytesResumable(fileRef, file);
    task.on(
      'state_changed',
      (snapshot) => {
        if (onProgress) {
          const pct = Math.round((snapshot.bytesTransferred / snapshot.totalBytes) * 100);
          onProgress(pct);
        }
      },
      (err) => reject(normalizeFirebaseError(err)),
      async () => {
        try {
          const url = await getDownloadURL(task.snapshot.ref);
          resolve({ url, path: fileRef.fullPath });
        } catch (err) {
          reject(normalizeFirebaseError(err));
        }
      }
    );
  });
}

export async function deleteFile(path) {
  const user = requireAuth();
  if (!path.startsWith(`uploads/${user.uid}/`)) {
    // Client-side guard mirroring the rule — you can only ever pass in
    // your own path anyway since paths are returned from uploadFile(),
    // but this catches accidental misuse (e.g. a stale path from another user).
    throw new AuthenticationError('You can only delete your own files.');
  }
  try {
    await deleteObject(ref(storage, path));
  } catch (err) {
    throw normalizeFirebaseError(err);
  }
}
