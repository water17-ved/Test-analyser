// errors.js
// Dev 3 — Backend & Database Architect
//
// Typed errors instead of throwing raw strings/Error objects everywhere.
// Why this matters at scale: your UI layer (Dev 2) needs to distinguish
// "you're not logged in" from "the data was malformed" from "Firestore is
// down" — each deserves a different toast/message/retry behavior. A single
// generic Error forces the frontend to string-match err.message, which is
// exactly the kind of fragile coupling that breaks in week 2 of production.

export class AppError extends Error {
  constructor(message, code, isOperational = true) {
    super(message);
    this.name = this.constructor.name;
    this.code = code;               // machine-readable, safe to switch() on
    this.isOperational = isOperational; // true = expected/handleable, false = bug
    Error.captureStackTrace?.(this, this.constructor);
  }
}

// Thrown when an action requires a signed-in user and none is present.
export class AuthenticationError extends AppError {
  constructor(message = 'You must be signed in to do this.') {
    super(message, 'AUTH_REQUIRED');
  }
}

// Thrown when data fails schema validation BEFORE it reaches Firestore.
// Carries `details` — an array of human-readable field-level problems —
// so the UI can show exactly what's wrong instead of a generic failure.
export class ValidationError extends AppError {
  constructor(message, details = []) {
    super(message, 'VALIDATION_FAILED');
    this.details = details;
  }
}

// Thrown when a requested document doesn't exist.
export class NotFoundError extends AppError {
  constructor(message = 'The requested item was not found.') {
    super(message, 'NOT_FOUND');
  }
}

// Thrown after retry exhaustion on a transient Firestore/Storage failure.
export class ServiceUnavailableError extends AppError {
  constructor(message = 'The service is temporarily unavailable. Please try again.') {
    super(message, 'SERVICE_UNAVAILABLE');
  }
}

// Maps a raw Firebase SDK error to one of the above, so callers never have
// to know Firebase-specific error codes ('permission-denied', etc).
export function normalizeFirebaseError(err) {
  const code = err?.code || '';
  if (code.includes('permission-denied')) {
    return new AuthenticationError('You do not have permission to do that.');
  }
  if (code.includes('unavailable') || code.includes('deadline-exceeded')) {
    return new ServiceUnavailableError();
  }
  if (code.includes('not-found')) {
    return new NotFoundError();
  }
  return new AppError(err?.message || 'Unknown error', code || 'UNKNOWN', false);
}
