// firestoreService.js
// Dev 3 — Backend & Database Architect
//
// All Firestore access for the app goes through this file. Nobody else
// (Dev 2's components, Dev 1's AI wrapper) should import 'firebase/firestore'
// directly — that would scatter path strings, retry logic, and validation
// across the codebase and guarantee drift. One service layer, one source
// of truth for how data gets in and out.

import {
  doc,
  setDoc,
  getDoc,
  getDocs,
  collection,
  query,
  orderBy,
  limit,
  startAfter,
  where,
  runTransaction,
  serverTimestamp,
} from 'firebase/firestore';
import { db, auth, APP_ID } from './firebaseConfig.js';
import { validateTestPaper, validateAttemptData } from './validators.js';
import { AuthenticationError, normalizeFirebaseError } from './errors.js';

// ---------------------------------------------------------------------------
// Retry wrapper for transient Firestore failures (network blips, brief
// backend unavailability). Does NOT retry permission-denied or not-found —
// those are permanent failures and retrying just wastes time and quota.
// Same exponential-backoff shape as Dev 1's geminiService.js fetchWithRetry,
// kept consistent across the codebase on purpose.
// ---------------------------------------------------------------------------
async function withRetry(fn, { maxRetries = 3, baseDelayMs = 500 } = {}) {
  let attempt = 0;
  // eslint-disable-next-line no-constant-condition
  while (true) {
    try {
      return await fn();
    } catch (err) {
      const retryable = err?.code === 'unavailable' || err?.code === 'deadline-exceeded';
      attempt += 1;
      if (!retryable || attempt >= maxRetries) {
        throw normalizeFirebaseError(err);
      }
      const delay = baseDelayMs * 2 ** (attempt - 1);
      await new Promise((res) => setTimeout(res, delay));
    }
  }
}

function requireAuth() {
  const user = auth.currentUser;
  if (!user) throw new AuthenticationError();
  return user;
}

// ---------------------------------------------------------------------------
// Test Papers — public, shared. Path: artifacts/{APP_ID}/public/data/tests/{testId}
// ---------------------------------------------------------------------------

export async function saveTestPaper(testData) {
  requireAuth();
  validateTestPaper(testData); // throws ValidationError with field-level detail on failure

  return withRetry(async () => {
    const testRef = doc(db, 'artifacts', APP_ID, 'public', 'data', 'tests', testData.testId);
    await setDoc(testRef, {
      ...testData,
      createdAt: serverTimestamp(), // server-assigned, never trust client clocks
      updatedAt: serverTimestamp(),
    });
    return testRef.id;
  });
}

export async function getTestPaper(testId) {
  return withRetry(async () => {
    const testRef = doc(db, 'artifacts', APP_ID, 'public', 'data', 'tests', testId);
    const snap = await getDoc(testRef);
    return snap.exists() ? snap.data() : null;
  });
}

// Paginated list — NEVER fetch an entire collection unbounded. Free-tier
// Firestore bills per document read; an unbounded getDocs() on a growing
// `tests` collection is the single most common way free-tier projects
// blow their daily quota by week 2.
export async function listTestPapers({ subject = null, pageSize = 20, cursor = null } = {}) {
  return withRetry(async () => {
    const testsCol = collection(db, 'artifacts', APP_ID, 'public', 'data', 'tests');
    const clauses = [];
    if (subject) clauses.push(where('subject', '==', subject));
    clauses.push(orderBy('createdAt', 'desc'), limit(pageSize));
    if (cursor) clauses.push(startAfter(cursor));

    const q = query(testsCol, ...clauses);
    const snap = await getDocs(q);
    return {
      items: snap.docs.map((d) => d.data()),
      lastDoc: snap.docs[snap.docs.length - 1] || null, // pass back in as `cursor` for next page
      hasMore: snap.docs.length === pageSize,
    };
  });
}

// ---------------------------------------------------------------------------
// Student Attempts — private. Path: artifacts/{APP_ID}/users/{uid}/attempts/{attemptId}
//
// saveStudentAttempt also updates a lightweight per-user stats doc
// (attemptCount, avgAccuracy) in the SAME transaction. Why a transaction
// and not "write the attempt, then separately increment a counter"?
// Two independent writes can race or partially fail (e.g. tab closes
// between them), silently corrupting the aggregate. A transaction makes
// the pair atomic: both succeed or neither does.
// ---------------------------------------------------------------------------

export async function saveStudentAttempt(attemptData) {
  const user = requireAuth();
  validateAttemptData(attemptData);

  if (attemptData.studentId !== user.uid) {
    // Defense in depth: catch this here with a clear message rather than
    // letting it silently fail against the security rule at write time.
    throw new AuthenticationError('attemptData.studentId does not match the signed-in user.');
  }

  return withRetry(async () => {
    const attemptRef = doc(
      db, 'artifacts', APP_ID, 'users', user.uid, 'attempts', attemptData.attemptId
    );
    const statsRef = doc(db, 'artifacts', APP_ID, 'users', user.uid, 'meta', 'stats');

    await runTransaction(db, async (tx) => {
      const statsSnap = await tx.get(statsRef);
      const prev = statsSnap.exists() ? statsSnap.data() : { attemptCount: 0, avgAccuracy: 0 };

      const newCount = prev.attemptCount + 1;
      const newAvg = (prev.avgAccuracy * prev.attemptCount + attemptData.accuracyPercentage) / newCount;

      tx.set(attemptRef, { ...attemptData, createdAt: serverTimestamp() });
      tx.set(statsRef, {
        attemptCount: newCount,
        avgAccuracy: Math.round(newAvg * 100) / 100,
        lastAttemptAt: serverTimestamp(),
      });
    });

    return attemptRef.id;
  });
}

export async function getStudentAttempt(attemptId) {
  const user = requireAuth();
  return withRetry(async () => {
    const attemptRef = doc(db, 'artifacts', APP_ID, 'users', user.uid, 'attempts', attemptId);
    const snap = await getDoc(attemptRef);
    return snap.exists() ? snap.data() : null;
  });
}

export async function listStudentAttempts({ pageSize = 20, cursor = null } = {}) {
  const user = requireAuth();
  return withRetry(async () => {
    const attemptsCol = collection(db, 'artifacts', APP_ID, 'users', user.uid, 'attempts');
    const clauses = [orderBy('createdAt', 'desc'), limit(pageSize)];
    if (cursor) clauses.push(startAfter(cursor));

    const snap = await getDocs(query(attemptsCol, ...clauses));
    return {
      items: snap.docs.map((d) => d.data()),
      lastDoc: snap.docs[snap.docs.length - 1] || null,
      hasMore: snap.docs.length === pageSize,
    };
  });
}

export async function getStudentStats() {
  const user = requireAuth();
  return withRetry(async () => {
    const statsRef = doc(db, 'artifacts', APP_ID, 'users', user.uid, 'meta', 'stats');
    const snap = await getDoc(statsRef);
    return snap.exists() ? snap.data() : { attemptCount: 0, avgAccuracy: 0 };
  });
}
