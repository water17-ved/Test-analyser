import React, { useState, useCallback, useRef, useMemo } from 'react';
import { saveUploadedPaper } from './uploadedPapers';
import { runUploadPipeline } from './geminiPipeline';
import { saveTest } from './testsStorage';
import { recordTestCompletion } from './playerStats';
import {
  FileText, ScanLine, UploadCloud, X, CheckCircle2, ChevronLeft,
  AlertTriangle, Loader2, RefreshCw, Image as ImageIcon, ClipboardPaste, Layers, Rows3,
  BookOpen, SlidersHorizontal, Award, Sigma, FlaskConical,
} from 'lucide-react';
import { THEME, SUBJECT_META } from './theme';

const SUBJECTS = Object.entries(SUBJECT_META).map(([key, meta]) => ({
  key, label: meta.label, icon: meta.icon, color: meta.color,
}));

const TEST_TYPES = [
  { key: 'topic', label: 'Topic-wise', icon: BookOpen },
  { key: 'custom', label: 'Custom', icon: SlidersHorizontal },
  { key: 'major', label: 'Major', icon: Award },
];

/* Parses the pasted OMR text (# Key Stu Pts Poss, whitespace-separated,
   Stu column blank for unattempted) into a summary. Real implementation,
   not a placeholder — this is exactly what Dev 1's ingestion step will
   need, so building it here means the format is validated before it
   ever reaches the backend. */
function parseOmrPaste(text) {
  const lines = text.split('\n').map((l) => l.trim()).filter(Boolean);
  const rowPattern = /^(\d+)\s+([A-Za-z])\s+(?:([A-Za-z])\s+)?(-?\d+(?:\.\d+)?)\s+(-?\d+(?:\.\d+)?)\s*$/;

  let correct = 0, incorrect = 0, unattempted = 0, pointsEarned = 0, pointsPossible = 0;
  const invalidLines = [];

  lines.forEach((line, idx) => {
    // Skip an optional header row like "# Key Stu Pts Poss"
    if (idx === 0 && /^#?\s*key/i.test(line)) return;
    const m = line.match(rowPattern);
    if (!m) { invalidLines.push(idx + 1); return; }
    const [, , key, stu, pts, poss] = m;
    pointsEarned += parseFloat(pts);
    pointsPossible += parseFloat(poss);
    if (!stu) unattempted += 1;
    else if (stu.toUpperCase() === key.toUpperCase()) correct += 1;
    else incorrect += 1;
  });

  const parsedCount = correct + incorrect + unattempted;
  return { parsedCount, correct, incorrect, unattempted, pointsEarned, pointsPossible, invalidLines };
}

const OMR_PASTE_PLACEHOLDER = `#  Key  Stu  Pts   Poss
1  A    B    -1.0  4.0
2  A    A    4.0   4.0
3  A         0.0   4.0
4  B    C    -1.0  4.0`;

/* ============================================================
   DATA LAYER — simulated submit. Real version will:
   1. upload file(s) to Firebase Storage (or send pasted text directly)
   2. if combined mode: run Dev 1's OCR + auto-split questions into
      subject blocks by index (e.g. 75 Qs -> 1-25 Physics, 26-50
      Chemistry, 51-75 Maths) before handing to the schema
   3. saveTestPaper(testData) to Firestore
   ============================================================ */
function useTestUpload() {
  // status: idle | uploading | parsing | success | error
  // 'uploading' = saving the file reference (instant)
  // 'parsing'   = Gemini is reading the paper (~15s) — shown with a progress message
  const [status,   setStatus]   = useState('idle');
  const [error,    setError]    = useState(null);
  const [progress, setProgress] = useState({ message: '', percent: 0 });

  const submit = useCallback(async (payload) => {
    setStatus('uploading');
    setError(null);
    setProgress({ message: 'Saving…', percent: 5 });

    // Step 1: persist the paper shell to localStorage immediately so it
    // appears in the papers list even before Gemini finishes parsing it.
    const paper = saveUploadedPaper(payload);

    // Bug 1 fix: combinedFile is stored as File[] (supports multi-page image
    // scans). The pipeline expects a single File — take the first element.
    const file = payload.paperMode === 'combined'
      ? (Array.isArray(payload.combinedFile) ? payload.combinedFile[0] : payload.combinedFile)
      : Object.values(payload.files || {})[0];

    const shouldParse = payload.mode === 'testpaper' && !!file;

    if (shouldParse) {
      setStatus('parsing');
      const mimeType = payload.fileFormat === 'pdf' ? 'application/pdf' : (file.type || 'image/jpeg');
      try {
        await runUploadPipeline(paper.id, file, mimeType, {
          onProgress: (message, percent) => setProgress({ message, percent }),
        });
      } catch (pipelineError) {
        // Non-fatal: paper already saved with status:'error'. The user sees it
        // in the Papers list with a "parse failed" badge and can retry.
        console.warn('[upload] AI parsing failed (paper saved):', pipelineError);
      }
    }

    // Step 2: OMR paste mode has fully parsed score data client-side.
    // Save an attempt record immediately so it appears in TestsTab and feeds
    // Achievements — no backend needed for this path.
    if (payload.mode === 'omr' && payload.omrInputType === 'paste' && payload.omrPreview) {
      const { correct, incorrect, unattempted, pointsEarned, pointsPossible } = payload.omrPreview;
      saveTest({
        id:                  paper.id,
        testTitle:           payload.testName,
        date:                new Date().toISOString().slice(0, 10),
        totalScore:          Math.round(pointsEarned * 10) / 10,
        maxScore:            Math.round(pointsPossible * 10) / 10,
        examType:            payload.examType,
        subjects:            payload.subjects,
        paperId:             null,
        aiFeedback:          null,
        aiRecommendations:   [],
        // topicBreakdown & difficultyBreakdown require OMR file + Gemini Vision (Dev 1)
        topicBreakdown:      [],
        difficultyBreakdown: [],
        // Raw counts for quick stats while detailed breakdown is pending
        _rawCounts: { correct, incorrect, unattempted },
      });
      recordTestCompletion({ xpAwarded: 100 });
    }

    setStatus('success');
    setProgress({ message: '', percent: 100 });
  }, []);

  const reset = useCallback(() => {
    setStatus('idle');
    setError(null);
    setProgress({ message: '', percent: 0 });
  }, []);

  return { status, error, progress, submit, reset };
}

/* ============================================================
   REUSABLE TOGGLE COMPONENTS
   Generic segmented-control pattern reused 3 times below —
   built once instead of copy-pasting per toggle.
   ============================================================ */
function SegmentedToggle({ value, onChange, options, ariaLabel }) {
  return (
    <div className="jbr-panel p-1 inline-flex gap-1" role="tablist" aria-label={ariaLabel}>
      {options.map((opt) => {
        const Icon = opt.icon;
        const active = value === opt.key;
        return (
          <button
            key={opt.key}
            role="tab"
            aria-selected={active}
            onClick={() => onChange(opt.key)}
            className="jbr-label text-sm px-4 py-2 rounded-lg flex items-center gap-2 transition-colors"
            style={{
              background: active ? 'linear-gradient(90deg, var(--gold), var(--xp))' : 'transparent',
              color: active ? '#160a00' : 'var(--text-muted)',
            }}
          >
            <Icon size={15} /> {opt.label.toUpperCase()}
          </button>
        );
      })}
    </div>
  );
}

function SubjectSelector({ selected, onToggle }) {
  return (
    <div className="flex gap-3 flex-wrap" role="group" aria-label="Select subjects">
      {SUBJECTS.map((s) => {
        const Icon = s.icon;
        const active = selected.includes(s.key);
        return (
          <button
            key={s.key}
            className="jbr-chip"
            aria-pressed={active}
            onClick={() => onToggle(s.key)}
            style={active ? { borderColor: s.color, boxShadow: `0 0 16px -6px ${s.color}` } : {}}
          >
            <Icon size={16} color={active ? s.color : 'var(--text-muted)'} />
            <span className="jbr-label text-sm" style={{ color: active ? 'var(--text-main)' : 'var(--text-muted)' }}>
              {s.label}
            </span>
          </button>
        );
      })}
    </div>
  );
}

function FileDropzone({ label, color, icon: Icon, accept, multiple, files, onAddFiles, onRemoveFile }) {
  const inputRef = useRef(null);
  const [dragActive, setDragActive] = useState(false);
  const list = files || [];

  const handleDrop = (e) => {
    e.preventDefault();
    setDragActive(false);
    const dropped = Array.from(e.dataTransfer.files || []);
    if (dropped.length) onAddFiles(dropped);
  };

  const handlePick = (e) => {
    const picked = Array.from(e.target.files || []);
    if (picked.length) onAddFiles(picked);
    e.target.value = ''; // reset so picking the same file(s) again still fires onChange
  };

  // Single-file mode hides the dropzone once a file is attached (replace, not add-to).
  // Multi-file mode keeps it visible so more pages can be added.
  const showDropzone = multiple || list.length === 0;

  return (
    <div className="jbr-panel p-4">
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <Icon size={16} color={color} />
          <span className="jbr-label text-xs" style={{ color: 'var(--text-muted)' }}>{label.toUpperCase()}</span>
        </div>
        {multiple && list.length > 0 && (
          <span className="jbr-label text-[10px]" style={{ color: 'var(--text-muted)' }}>{list.length} FILE{list.length > 1 ? 'S' : ''}</span>
        )}
      </div>

      {list.length > 0 && (
        <div className="space-y-2 mb-3">
          {list.map((f, idx) => (
            <div key={`${f.name}-${f.lastModified}-${idx}`} className="flex items-center justify-between gap-2 rounded-lg px-3 py-2" style={{ background: 'var(--card-bg)', border: `1px solid ${color}` }}>
              <div className="flex items-center gap-2 min-w-0">
                <CheckCircle2 size={16} color={color} className="shrink-0" />
                <span className="text-xs truncate" style={{ color: 'var(--text-main)' }}>{f.name}</span>
              </div>
              <button onClick={() => onRemoveFile(idx)} aria-label={`Remove ${f.name}`} className="shrink-0">
                <X size={14} color="var(--text-muted)" />
              </button>
            </div>
          ))}
        </div>
      )}

      {showDropzone && (
        <div
          className={`jbr-dropzone ${dragActive ? 'active' : ''} p-5 flex flex-col items-center gap-2 cursor-pointer text-center`}
          onClick={() => inputRef.current?.click()}
          onDragOver={(e) => { e.preventDefault(); setDragActive(true); }}
          onDragLeave={() => setDragActive(false)}
          onDrop={handleDrop}
          role="button"
          tabIndex={0}
          aria-label={`Upload ${label}`}
          onKeyDown={(e) => { if (e.key === 'Enter' || e.key === ' ') inputRef.current?.click(); }}
        >
          <UploadCloud size={20} color="var(--text-muted)" />
          <span className="jbr-label text-xs" style={{ color: 'var(--text-muted)' }}>
            {multiple ? (list.length > 0 ? 'ADD MORE PAGES' : 'DROP FILES OR TAP · MULTIPLE ALLOWED') : 'DROP FILE OR TAP'}
          </span>
          <input
            ref={inputRef}
            type="file"
            accept={accept}
            multiple={multiple}
            className="hidden"
            onChange={handlePick}
          />
        </div>
      )}
    </div>
  );
}

/* Combined-mode question split — auto-divides evenly across
   selected subjects, but stays editable in case a paper isn't
   split evenly (e.g. 30/25/20 instead of 25/25/25). */
function QuestionSplitInputs({ subjects, totalQuestions, split, onChange }) {
  const sum = subjects.reduce((acc, s) => acc + (split[s] || 0), 0);
  const mismatch = totalQuestions > 0 && sum !== totalQuestions;

  return (
    <div className="jbr-panel p-4">
      <p className="jbr-label text-xs mb-3" style={{ color: 'var(--text-muted)' }}>QUESTION SPLIT (IN PAPER ORDER)</p>
      <div className="flex flex-col gap-2">
        {SUBJECTS.filter((s) => subjects.includes(s.key)).map((s, idx) => {
          const Icon = s.icon;
          return (
            <div key={s.key} className="flex items-center justify-between gap-3">
              <div className="flex items-center gap-2">
                <span className="jbr-label text-xs" style={{ color: 'var(--text-muted)' }}>{idx + 1}.</span>
                <Icon size={14} color={s.color} />
                <span className="text-xs" style={{ color: 'var(--text-main)' }}>{s.label}</span>
              </div>
              <input
                type="number"
                min={0}
                className="jbr-num-input"
                value={split[s.key] ?? ''}
                onChange={(e) => onChange(s.key, Math.max(0, parseInt(e.target.value || '0', 10)))}
              />
            </div>
          );
        })}
      </div>
      {mismatch && (
        <p className="text-xs mt-2" style={{ color: 'var(--danger)' }}>
          Split adds up to {sum}, but total questions is {totalQuestions}.
        </p>
      )}
    </div>
  );
}

/* ============================================================
   MAIN UPLOAD SCREEN
   ============================================================ */
export default function UploadScreen({ onBack }) {
  const [testName, setTestName] = useState('');
  const [testType, setTestType] = useState('topic'); // topic | custom | major
  const [topicName, setTopicName] = useState('');
  const [mode, setMode] = useState('testpaper'); // testpaper | omr
  const [fileFormat, setFileFormat] = useState('pdf'); // pdf | image
  const [paperMode, setPaperMode] = useState('separate'); // separate | combined
  const [subjects, setSubjects] = useState([]);
  const [files, setFiles] = useState({}); // separate mode: { physics: File[], ... } — images can be multiple pages, PDF stays single-item
  const [combinedFile, setCombinedFile] = useState([]); // array too, for the same reason
  const [totalQuestions, setTotalQuestions] = useState(75);
  const [split, setSplit] = useState({ physics: 25, chemistry: 25, maths: 25 });
  const [omrInputType, setOmrInputType] = useState('file'); // file | paste
  const [omrPasteText, setOmrPasteText] = useState('');
  const [examType, setExamType] = useState('jee'); // 'jee' | 'neet'
  const [touched, setTouched] = useState(false);

  const { status, error, progress, submit, reset } = useTestUpload();

  const accept = fileFormat === 'pdf' ? 'application/pdf' : 'image/*';
  const allowMultipleFiles = fileFormat === 'image'; // a scanned paper is often several page photos; a PDF is one file

  const toggleSubject = (key) => {
    setSubjects((prev) => (prev.includes(key) ? prev.filter((k) => k !== key) : [...prev, key]));
  };

  const addSubjectFiles = (key, newFiles) => setFiles((prev) => {
    const existing = prev[key] || [];
    return { ...prev, [key]: allowMultipleFiles ? [...existing, ...newFiles] : newFiles.slice(0, 1) };
  });
  const removeSubjectFile = (key, index) => setFiles((prev) => {
    const remaining = (prev[key] || []).filter((_, i) => i !== index);
    const next = { ...prev };
    if (remaining.length) next[key] = remaining; else delete next[key];
    return next;
  });

  const addCombinedFiles = (newFiles) => setCombinedFile((prev) => (allowMultipleFiles ? [...prev, ...newFiles] : newFiles.slice(0, 1)));
  const removeCombinedFile = (index) => setCombinedFile((prev) => prev.filter((_, i) => i !== index));

  const updateSplit = (key, value) => setSplit((prev) => ({ ...prev, [key]: value }));

  const missingFiles = subjects.filter((s) => !(files[s] && files[s].length > 0));
  const splitSum = useMemo(() => subjects.reduce((acc, s) => acc + (split[s] || 0), 0), [subjects, split]);

  const omrPreview = useMemo(() => {
    if (mode !== 'omr' || omrInputType !== 'paste' || !omrPasteText.trim()) return null;
    return parseOmrPaste(omrPasteText);
  }, [mode, omrInputType, omrPasteText]);

  const isValid = useMemo(() => {
    if (!testName.trim() || subjects.length === 0) return false;
    if (testType === 'topic' && !topicName.trim()) return false;
    if (mode === 'omr' && omrInputType === 'paste') {
      return omrPasteText.trim().length > 0 && !!omrPreview && omrPreview.parsedCount > 0 && omrPreview.invalidLines.length === 0;
    }
    if (paperMode === 'combined') return combinedFile.length > 0 && totalQuestions > 0 && splitSum === totalQuestions;
    return missingFiles.length === 0;
  }, [testName, testType, topicName, subjects, mode, omrInputType, omrPasteText, omrPreview, paperMode, combinedFile, totalQuestions, splitSum, missingFiles]);

  // Bug 2 fix: must be async so rejected promises from submit() surface
  // as the 'error' status rather than escaping silently.
  const handleSubmit = async () => {
    setTouched(true);
    if (!isValid) return;
    await submit({
      testName, testType, topicName, mode, fileFormat, paperMode,
      subjects, files, combinedFile, split, omrInputType, omrPasteText,
      examType,
      omrPreview, // needed by submit() to build the attempt record for paste mode
    });
  };

  const handleUploadAnother = () => {
    setTestName(''); setTestType('topic'); setTopicName(''); setSubjects([]); setFiles({}); setCombinedFile([]);
    setOmrPasteText(''); setExamType('jee'); setTouched(false); reset();
  };

  return (
    <div className="jbr-root jbr-glow-bg">
      <style>{THEME}</style>
      <div className="max-w-xl mx-auto px-5 py-8 space-y-6">
        <header className="flex items-center gap-3">
          {onBack && (
            <button onClick={onBack} aria-label="Back to Dashboard" className="jbr-panel p-2 rounded-lg shrink-0">
              <ChevronLeft size={18} color="var(--text-muted)" />
            </button>
          )}
          <div>
            <h1 className="jbr-display text-xl font-bold jbr-gradient-text">UPLOAD TEST</h1>
            <p className="jbr-label text-xs mt-1" style={{ color: 'var(--text-muted)' }}>ADD A NEW BATTLE TO YOUR LOG</p>
          </div>
        </header>

        {status === 'success' ? (
          <div className="jbr-card p-8 flex flex-col items-center text-center gap-3">
            <CheckCircle2 size={32} color="var(--chem)" />
            <p className="jbr-label text-sm" style={{ color: 'var(--text-main)' }}>Upload received.</p>
            <p className="text-xs" style={{ color: 'var(--text-muted)' }}>
              "{testName}" is being processed — you'll see it under Tests once analysis finishes.
            </p>
            <button onClick={handleUploadAnother} className="jbr-btn-primary jbr-label text-sm mt-2">
              UPLOAD ANOTHER
            </button>
          </div>
        ) : (
          <>
            {/* Test name */}
            <div>
              <label htmlFor="test-name" className="jbr-label text-xs block mb-2" style={{ color: 'var(--text-muted)' }}>
                NAME OF TEST
              </label>
              <input
                id="test-name"
                className="jbr-input"
                placeholder="e.g. Physics Chapterwise Mock Test 1"
                value={testName}
                onChange={(e) => setTestName(e.target.value)}
                style={touched && !testName.trim() ? { borderColor: 'var(--danger)' } : {}}
              />
              {touched && !testName.trim() && <p className="text-xs mt-1" style={{ color: 'var(--danger)' }}>Give the test a name.</p>}
            </div>

            {/* Exam type — JEE or NEET, drives per-exam achievements + leaderboard */}
            <div>
              <p className="jbr-label text-xs mb-2" style={{ color: 'var(--text-muted)' }}>EXAM</p>
              <SegmentedToggle
                ariaLabel="Exam type"
                value={examType}
                onChange={setExamType}
                options={[
                  { key: 'jee',  label: 'JEE',  icon: Sigma },
                  { key: 'neet', label: 'NEET', icon: FlaskConical },
                ]}
              />
            </div>

            {/* Test type */}
            <div>
              <p className="jbr-label text-xs mb-2" style={{ color: 'var(--text-muted)' }}>TEST TYPE</p>
              <SegmentedToggle ariaLabel="Test type" value={testType} onChange={setTestType} options={TEST_TYPES} />
            </div>

            {/* Topic-wise: needs the specific topic/chapter */}
            {testType === 'topic' && (
              <div>
                <label htmlFor="topic-name" className="jbr-label text-xs block mb-2" style={{ color: 'var(--text-muted)' }}>
                  TOPIC / CHAPTER
                </label>
                <input
                  id="topic-name"
                  className="jbr-input"
                  placeholder="e.g. Thermodynamics"
                  value={topicName}
                  onChange={(e) => setTopicName(e.target.value)}
                  style={touched && testType === 'topic' && !topicName.trim() ? { borderColor: 'var(--danger)' } : {}}
                />
                {touched && !topicName.trim() && <p className="text-xs mt-1" style={{ color: 'var(--danger)' }}>Name the topic this test covers.</p>}
              </div>
            )}

            {/* Test Paper vs OMR */}
            <div>
              <p className="jbr-label text-xs mb-2" style={{ color: 'var(--text-muted)' }}>UPLOAD TYPE</p>
              <SegmentedToggle
                ariaLabel="Upload type"
                value={mode}
                onChange={setMode}
                options={[
                  { key: 'testpaper', label: 'Test Paper', icon: FileText },
                  { key: 'omr', label: 'OMR', icon: ScanLine },
                ]}
              />
            </div>

            {/* File format: PDF vs Image — irrelevant when pasting OMR data */}
            {!(mode === 'omr' && omrInputType === 'paste') && (
              <div>
                <p className="jbr-label text-xs mb-2" style={{ color: 'var(--text-muted)' }}>FILE FORMAT</p>
                <SegmentedToggle
                  ariaLabel="File format"
                  value={fileFormat}
                  onChange={setFileFormat}
                  options={[
                    { key: 'pdf', label: 'PDF', icon: FileText },
                    { key: 'image', label: 'Images', icon: ImageIcon },
                  ]}
                />
              </div>
            )}

            {/* OMR-only: file vs paste data */}
            {mode === 'omr' && (
              <div>
                <p className="jbr-label text-xs mb-2" style={{ color: 'var(--text-muted)' }}>OMR INPUT METHOD</p>
                <SegmentedToggle
                  ariaLabel="OMR input method"
                  value={omrInputType}
                  onChange={setOmrInputType}
                  options={[
                    { key: 'file', label: 'Upload File', icon: UploadCloud },
                    { key: 'paste', label: 'Paste Data', icon: ClipboardPaste },
                  ]}
                />
              </div>
            )}

            {/* OMR paste textarea */}
            {mode === 'omr' && omrInputType === 'paste' && (
              <div>
                <label htmlFor="omr-paste" className="jbr-label text-xs block mb-2" style={{ color: 'var(--text-muted)' }}>
                  PASTE OMR DATA
                </label>
                <textarea
                  id="omr-paste"
                  className="jbr-textarea"
                  placeholder={OMR_PASTE_PLACEHOLDER}
                  value={omrPasteText}
                  onChange={(e) => setOmrPasteText(e.target.value)}
                  style={touched && !omrPasteText.trim() ? { borderColor: 'var(--danger)' } : {}}
                />
                <p className="text-xs mt-1" style={{ color: 'var(--text-muted)' }}>
                  Columns: <span style={{ color: 'var(--text-main)' }}>Question # · Key · Student Answer · Points · Possible</span>. Leave Student Answer blank for unattempted questions.
                </p>
                {touched && !omrPasteText.trim() && <p className="text-xs mt-1" style={{ color: 'var(--danger)' }}>Paste your OMR data, or switch to file upload.</p>}

                {omrPreview && (
                  <div className="jbr-panel p-4 mt-3">
                    <p className="jbr-label text-xs mb-3" style={{ color: 'var(--text-muted)' }}>PARSED PREVIEW</p>
                    <div className="grid grid-cols-3 gap-3 mb-2">
                      <div>
                        <p className="jbr-display text-lg font-bold" style={{ color: 'var(--chem)' }}>{omrPreview.correct}</p>
                        <p className="jbr-label text-[10px]" style={{ color: 'var(--text-muted)' }}>CORRECT</p>
                      </div>
                      <div>
                        <p className="jbr-display text-lg font-bold" style={{ color: 'var(--danger)' }}>{omrPreview.incorrect}</p>
                        <p className="jbr-label text-[10px]" style={{ color: 'var(--text-muted)' }}>INCORRECT</p>
                      </div>
                      <div>
                        <p className="jbr-display text-lg font-bold" style={{ color: 'var(--text-muted)' }}>{omrPreview.unattempted}</p>
                        <p className="jbr-label text-[10px]" style={{ color: 'var(--text-muted)' }}>UNATTEMPTED</p>
                      </div>
                    </div>
                    <p className="text-xs" style={{ color: 'var(--text-main)' }}>
                      {omrPreview.parsedCount} questions parsed · {omrPreview.pointsEarned.toFixed(1)} / {omrPreview.pointsPossible.toFixed(1)} pts
                    </p>
                    {omrPreview.invalidLines.length > 0 && (
                      <p className="text-xs mt-2 flex items-center gap-1" style={{ color: 'var(--danger)' }}>
                        <AlertTriangle size={12} /> Couldn't read line{omrPreview.invalidLines.length > 1 ? 's' : ''} {omrPreview.invalidLines.join(', ')} — check the format.
                      </p>
                    )}
                  </div>
                )}
              </div>
            )}

            {/* Subject selector */}
            <div>
              <p className="jbr-label text-xs mb-2" style={{ color: 'var(--text-muted)' }}>SUBJECT</p>
              <SubjectSelector selected={subjects} onToggle={toggleSubject} />
              {touched && subjects.length === 0 && <p className="text-xs mt-1" style={{ color: 'var(--danger)' }}>Pick at least one subject.</p>}
            </div>

            {/* Separate vs Combined — only meaningful for file-based upload with 2+ subjects */}
            {!(mode === 'omr' && omrInputType === 'paste') && subjects.length > 1 && (
              <div>
                <p className="jbr-label text-xs mb-2" style={{ color: 'var(--text-muted)' }}>PAPER STRUCTURE</p>
                <SegmentedToggle
                  ariaLabel="Paper structure"
                  value={paperMode}
                  onChange={setPaperMode}
                  options={[
                    { key: 'separate', label: 'Separate Files', icon: Rows3 },
                    { key: 'combined', label: 'One Combined File', icon: Layers },
                  ]}
                />
                <p className="text-xs mt-2" style={{ color: 'var(--text-muted)' }}>
                  {paperMode === 'combined'
                    ? "Upload one file with all subjects together — we'll split it by question number."
                    : 'Upload a separate file for each subject below.'}
                </p>
              </div>
            )}

            {/* File pickers — file-based modes only */}
            {!(mode === 'omr' && omrInputType === 'paste') && (
              <div>
                <p className="jbr-label text-xs mb-2" style={{ color: 'var(--text-muted)' }}>
                  {mode === 'omr' ? 'OMR SHEETS' : 'TEST PAPERS'}
                </p>

                {subjects.length === 0 ? (
                  <div className="jbr-panel p-5 text-center">
                    <p className="text-xs" style={{ color: 'var(--text-muted)' }}>Select a subject above to attach a file.</p>
                  </div>
                ) : paperMode === 'combined' && subjects.length > 1 ? (
                  <div className="space-y-3">
                    <FileDropzone
                      label={`Combined ${mode === 'omr' ? 'OMR Sheet' : 'Paper'} (${SUBJECTS.filter(s => subjects.includes(s.key)).map(s => s.label).join(' + ')})`}
                      color="var(--gold)"
                      icon={Layers}
                      accept={accept}
                      multiple={allowMultipleFiles}
                      files={combinedFile}
                      onAddFiles={addCombinedFiles}
                      onRemoveFile={removeCombinedFile}
                    />
                    <div>
                      <label htmlFor="total-q" className="jbr-label text-xs block mb-2" style={{ color: 'var(--text-muted)' }}>
                        TOTAL QUESTIONS
                      </label>
                      <input
                        id="total-q"
                        type="number"
                        min={1}
                        className="jbr-input"
                        style={{ maxWidth: 120 }}
                        value={totalQuestions}
                        onChange={(e) => setTotalQuestions(Math.max(0, parseInt(e.target.value || '0', 10)))}
                      />
                    </div>
                    <QuestionSplitInputs subjects={subjects} totalQuestions={totalQuestions} split={split} onChange={updateSplit} />
                  </div>
                ) : (
                  <div className="space-y-3">
                    {SUBJECTS.filter((s) => subjects.includes(s.key)).map((s) => (
                      <FileDropzone
                        key={s.key}
                        label={s.label}
                        color={s.color}
                        icon={s.icon}
                        accept={accept}
                        multiple={allowMultipleFiles}
                        files={files[s.key]}
                        onAddFiles={(fs) => addSubjectFiles(s.key, fs)}
                        onRemoveFile={(idx) => removeSubjectFile(s.key, idx)}
                      />
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* Error state */}
            {status === 'error' && (
              <div className="jbr-panel p-4 flex items-center gap-3" style={{ borderColor: 'var(--danger)' }}>
                <AlertTriangle size={18} color="var(--danger)" className="shrink-0" />
                <p className="text-xs flex-1" style={{ color: 'var(--text-main)' }}>{error}</p>
                <button onClick={handleSubmit} className="jbr-label text-xs flex items-center gap-1" style={{ color: 'var(--gold-bright)' }}>
                  <RefreshCw size={12} /> RETRY
                </button>
              </div>
            )}

            {/* Parsing progress — shown while Gemini reads the paper */}
            {status === 'parsing' && (
              <div className="jbr-panel p-4 space-y-2">
                <div className="flex items-center justify-between">
                  <p className="jbr-label text-xs" style={{ color: 'var(--gold-bright)' }}>
                    {progress.message || 'Processing with AI…'}
                  </p>
                  <span className="jbr-label text-xs" style={{ color: 'var(--text-muted)' }}>
                    {progress.percent}%
                  </span>
                </div>
                <div className="jbr-xp-track h-2">
                  <div className="jbr-xp-fill" style={{ width: `${progress.percent}%`, transition: 'width .4s ease' }} />
                </div>
                <p className="text-[11px]" style={{ color: 'var(--text-muted)' }}>
                  Gemini is reading your test paper — this takes ~15 seconds.
                </p>
              </div>
            )}

            {/* Submit */}
            <button
              onClick={handleSubmit}
              disabled={status === 'uploading' || status === 'parsing'}
              className="jbr-btn-primary jbr-label text-sm w-full flex items-center justify-center gap-2"
            >
              {status === 'uploading' ? (
                <><Loader2 size={16} className="jbr-spin" /> UPLOADING…</>
              ) : status === 'parsing' ? (
                <><Loader2 size={16} className="jbr-spin" /> AI PARSING…</>
              ) : (
                'UPLOAD TEST'
              )}
            </button>
          </>
        )}
      </div>
    </div>
  );
}
