import React, { useState, useEffect } from 'react';
import Dashboard from './Dashboard';
import UploadScreen from './UploadScreen';
import QuestionPapersPreview from './QuestionPapersPreview';
import OverallAnalytics from './OverallAnalytics';
import TestsTab from './TestsTab';
import Achievements from './Achievements';
import { authenticateUser, FIREBASE_CONFIGURED } from './firebase';

/* ============================================================
   APP SHELL
   Two concerns live here:

   1. Auth — authenticateUser() runs once on mount. If Firebase is
      configured it signs in anonymously (<300ms typical); if not
      (no .env) the app proceeds immediately in demo/mock mode.
      A minimal splash covers the auth gap so components never
      render with a null uid, but the splash is never shown when
      Firebase isn't configured (no flicker for dev builds).

   2. Navigation — simple state-based router with cross-screen
      state. paperToOpen lets TestsTab deep-link into a specific
      paper in QuestionPapersPreview without either screen knowing
      about the other's internals.
   ============================================================ */

export default function App() {
  const [screen,      setScreen]      = useState('dashboard');
  const [paperToOpen, setPaperToOpen] = useState(null);

  // Start as "ready" when Firebase isn't configured — no splash shown
  // in dev mode without a .env, no delay.
  const [authReady, setAuthReady] = useState(!FIREBASE_CONFIGURED);

  useEffect(() => {
    if (!FIREBASE_CONFIGURED) return; // already set to true above
    authenticateUser().finally(() => setAuthReady(true));
  }, []);

  // Minimal splash while anonymous auth resolves. Styled inline so it
  // works before any CSS is loaded and never flashes the full dark UI.
  if (!authReady) {
    return (
      <div style={{
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        minHeight: '100vh', background: '#0a0710', flexDirection: 'column', gap: 16,
      }}>
        <div style={{
          width: 40, height: 40, borderRadius: 10,
          background: 'linear-gradient(135deg, #7a0d3a, #3a0620)',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          fontSize: 22, color: '#ffe1ec',
        }}>⚡</div>
        <p style={{
          color: '#ffcf3d', fontFamily: 'Orbitron, sans-serif',
          fontSize: 12, letterSpacing: 3, opacity: 0.8,
        }}>INITIALIZING…</p>
      </div>
    );
  }

  // Navigate to a new screen. Clears paperToOpen unless the caller
  // sets it first (see handleViewPaper below).
  const navigate = (screenKey) => {
    if (screenKey !== 'papers') setPaperToOpen(null);
    setScreen(screenKey || 'dashboard');
  };

  // Called from TestsTab's "View Question Paper" button.
  // Sends the user to the papers screen with that paper pre-opened.
  const handleViewPaper = (paperId) => {
    setPaperToOpen(paperId);
    setScreen('papers');
  };

  if (screen === 'dashboard') {
    return <Dashboard onNavigate={navigate} />;
  }

  const screens = {
    upload:       () => <UploadScreen    onBack={() => navigate('dashboard')} />,
    papers:       () => <QuestionPapersPreview onBack={() => navigate('dashboard')} initialPaperId={paperToOpen} />,
    analytics:    () => <OverallAnalytics onBack={() => navigate('dashboard')} />,
    tests:        () => <TestsTab         onBack={() => navigate('dashboard')} onViewPaper={handleViewPaper} />,
    achievements: () => <Achievements     onBack={() => navigate('dashboard')} />,
  };

  const render = screens[screen];
  return render ? render() : <Dashboard onNavigate={navigate} />;
}
