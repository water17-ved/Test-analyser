import React, { useState, useMemo } from 'react';
import { Trophy, Lock, Check, AlertTriangle, RefreshCw, ChevronLeft } from 'lucide-react';
import { THEME, TIER, EXAM_COLOR } from './theme';
import { useAchievements, CATEGORY_META, EXAM_META } from './achievements';

/* ---- Loading skeleton, matches real layout so there's no jump ---- */
function AchievementsSkeleton() {
  return (
    <div className="space-y-8" aria-busy="true" aria-label="Loading achievements">
      <div className="jbr-skeleton h-24 rounded-2xl" />
      <div className="jbr-skeleton h-9 rounded-full w-full max-w-xs" />
      <div className="jbr-skeleton h-10 rounded-full w-full max-w-md" />
      <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
        {Array.from({ length: 9 }).map((_, i) => (
          <div key={i} className="jbr-skeleton h-32 rounded-2xl" />
        ))}
      </div>
    </div>
  );
}

/* ---- Error state with retry ---- */
function AchievementsError({ onRetry }) {
  return (
    <div className="jbr-card p-8 flex flex-col items-center text-center gap-3">
      <AlertTriangle size={28} color="var(--danger)" />
      <p className="jbr-label text-sm" style={{ color: 'var(--text-main)' }}>Couldn't load your achievements.</p>
      <p className="text-xs" style={{ color: 'var(--text-muted)' }}>Check your connection and try again.</p>
      <button
        onClick={onRetry}
        className="jbr-label mt-2 px-4 py-2 rounded-lg flex items-center gap-2 text-sm"
        style={{ background: 'var(--gold)', color: '#160a00' }}
      >
        <RefreshCw size={14} /> RETRY
      </button>
    </div>
  );
}

/* ---- Empty state: filtered view has nothing to show ---- */
function EmptyAchievements() {
  return (
    <div className="jbr-card p-6 flex items-center gap-4">
      <Trophy size={20} color="var(--text-muted)" />
      <p className="text-sm" style={{ color: 'var(--text-muted)' }}>No achievements match this filter yet.</p>
    </div>
  );
}

/* ---- Summary header: unlocked count + overall progress ---- */
function AchievementsSummary({ achievements }) {
  const unlockedCount = achievements.filter((a) => a.unlocked).length;
  const total = achievements.length;
  const pct = total > 0 ? Math.round((unlockedCount / total) * 100) : 0;

  return (
    <div className="jbr-card p-6 flex flex-col md:flex-row md:items-center justify-between gap-6">
      <div className="flex items-center gap-4">
        <div
          className="w-14 h-14 rounded-2xl flex items-center justify-center"
          style={{ background: 'linear-gradient(135deg, var(--gold), var(--xp))' }}
        >
          <Trophy size={24} color="#160a00" />
        </div>
        <div>
          <p className="jbr-label text-xs" style={{ color: 'var(--text-muted)' }}>ACHIEVEMENTS UNLOCKED</p>
          <h2 className="jbr-display text-xl font-bold" style={{ color: 'var(--text-main)' }}>
            {unlockedCount} <span style={{ color: 'var(--text-muted)' }}>/ {total}</span>
          </h2>
        </div>
      </div>
      <div className="flex-1 md:max-w-xs">
        <div className="flex justify-between mb-1">
          <span className="jbr-label text-xs" style={{ color: 'var(--text-muted)' }}>PROGRESS</span>
          <span className="jbr-label text-xs" style={{ color: 'var(--gold-bright)' }}>{pct}%</span>
        </div>
        <div className="jbr-xp-track h-3" role="progressbar" aria-valuenow={pct} aria-valuemin={0} aria-valuemax={100}>
          <div className="jbr-xp-fill" style={{ width: `${pct}%` }} />
        </div>
      </div>
    </div>
  );
}

/* ---- Generic pill-tab row, reused for both the exam filter and the
   category filter so the two rows stay visually and behaviorally
   consistent instead of two one-off implementations. ---- */
function FilterTabs({ options, selected, onSelect, ariaLabel }) {
  return (
    <div className="flex gap-2 overflow-x-auto pb-1" role="tablist" aria-label={ariaLabel}>
      {options.map(({ key, label, icon: Icon, activeColor }) => {
        const isActive = selected === key;
        return (
          <button
            key={key}
            role="tab"
            aria-selected={isActive}
            onClick={() => onSelect(key)}
            className="jbr-label text-xs px-3 py-2 rounded-full flex items-center gap-1.5 whitespace-nowrap flex-shrink-0 transition-colors"
            style={{
              background: isActive ? (activeColor || 'var(--gold)') : 'var(--panel-bg)',
              color: isActive ? '#0a0710' : 'var(--text-muted)',
              border: `1px solid ${isActive ? (activeColor || 'var(--gold)') : 'var(--border)'}`,
            }}
          >
            {Icon && <Icon size={13} />}
            {label}
          </button>
        );
      })}
    </div>
  );
}

/* ---- Single achievement card ---- */
function AchievementCard({ achievement, index }) {
  const { title, description, icon: Icon, tier, exam, unlocked, current, target, progressPct, comparator } = achievement;
  const tierStyle = TIER[tier];
  const examStyle = exam ? { label: EXAM_META[exam].label, color: EXAM_COLOR[exam] } : null;

  const progressLabel =
    comparator === 'lte'
      ? unlocked
        ? `AIR #${current.toLocaleString()}`
        : `Currently AIR #${current.toLocaleString()} · need Top ${target.toLocaleString()}`
      : `${current} / ${target}`;

  return (
    <div
      className={`jbr-card jbr-tile jbr-card-in p-4 flex flex-col gap-3 relative ${unlocked ? 'jbr-achieve-unlocked' : ''}`}
      style={{
        animationDelay: `${Math.min(index, 20) * 40}ms`,
        '--tier-color': tierStyle.color,
        '--tier-glow': tierStyle.glow,
        opacity: unlocked ? 1 : 0.55,
      }}
    >
      <div className="flex items-start justify-between gap-2">
        <div
          className={`w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0 ${unlocked ? 'jbr-unlock-icon' : ''}`}
          style={{
            background: 'var(--panel-bg)',
            border: `1px solid ${unlocked ? tierStyle.color : 'var(--border)'}`,
          }}
        >
          {unlocked ? <Icon size={18} color={tierStyle.color} /> : <Lock size={16} color="var(--text-muted)" />}
        </div>
        <div className="flex flex-col items-end gap-1">
          <span
            className="jbr-label text-[9px] px-2 py-0.5 rounded-full flex items-center gap-1"
            style={{ background: 'var(--panel-bg)', border: `1px solid ${tierStyle.color}`, color: tierStyle.color }}
          >
            {unlocked && <Check size={9} />}
            {tierStyle.label.toUpperCase()}
          </span>
          {examStyle && (
            <span
              className="jbr-label text-[9px] px-2 py-0.5 rounded-full"
              style={{ background: 'var(--panel-bg)', border: `1px solid ${examStyle.color}`, color: examStyle.color }}
            >
              {examStyle.label}
            </span>
          )}
        </div>
      </div>

      <div>
        <p className="jbr-label text-sm font-semibold" style={{ color: 'var(--text-main)' }}>{title}</p>
        <p className="text-xs mt-0.5" style={{ color: 'var(--text-muted)' }}>{description}</p>
      </div>

      <div>
        <div className="jbr-xp-track h-1.5" role="progressbar" aria-valuenow={progressPct} aria-valuemin={0} aria-valuemax={100}>
          <div
            className="jbr-xp-fill"
            style={{ width: `${progressPct}%`, background: unlocked ? tierStyle.color : 'var(--xp)' }}
          />
        </div>
        <p className="jbr-label text-[10px] mt-1" style={{ color: 'var(--text-muted)' }}>{progressLabel}</p>
      </div>
    </div>
  );
}

/* ============================================================
   MAIN ACHIEVEMENTS SCREEN
   ============================================================ */
export default function Achievements({ onBack }) {
  const { data, isLoading, error, retry } = useAchievements();
  const [selectedExam, setSelectedExam] = useState('all');
  const [selectedCategory, setSelectedCategory] = useState('all');

  const examOptions = useMemo(
    () => [
      { key: 'all', label: 'All Exams' },
      { key: 'neet', label: EXAM_META.neet.label, activeColor: 'var(--chem)' },
      { key: 'jee', label: EXAM_META.jee.label, activeColor: 'var(--phys)' },
    ],
    []
  );

  const categoryOptions = useMemo(
    () => [
      { key: 'all', label: 'All' },
      ...Object.entries(CATEGORY_META).map(([key, meta]) => ({ key, label: meta.label, icon: meta.icon })),
    ],
    []
  );

  const filtered = useMemo(() => {
    if (!data) return [];
    return data.filter((a) => {
      const examMatch = selectedExam === 'all' || a.exam === selectedExam || a.exam === null;
      const categoryMatch = selectedCategory === 'all' || a.category === selectedCategory;
      return examMatch && categoryMatch;
    });
  }, [data, selectedExam, selectedCategory]);

  return (
    <div className="jbr-root jbr-glow-bg">
      <style>{THEME}</style>

      <div className="max-w-5xl mx-auto px-5 py-8 space-y-6">
        <header className="flex items-center gap-3">
          {onBack && (
            <button onClick={onBack} aria-label="Back to Dashboard" className="jbr-panel p-2 rounded-lg shrink-0">
              <ChevronLeft size={18} color="var(--text-muted)" />
            </button>
          )}
          <div>
            <h1 className="jbr-display text-xl font-bold jbr-gradient-text">ACHIEVEMENTS</h1>
            <p className="jbr-label text-xs" style={{ color: 'var(--text-muted)' }}>YOUR TROPHY CASE — NEET &amp; JEE</p>
          </div>
        </header>

        {error ? (
          <AchievementsError onRetry={retry} />
        ) : isLoading ? (
          <AchievementsSkeleton />
        ) : (
          <>
            <AchievementsSummary achievements={data} />
            <FilterTabs options={examOptions} selected={selectedExam} onSelect={setSelectedExam} ariaLabel="Filter achievements by exam" />
            <FilterTabs options={categoryOptions} selected={selectedCategory} onSelect={setSelectedCategory} ariaLabel="Filter achievements by category" />
            {filtered.length === 0 ? (
              <EmptyAchievements />
            ) : (
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                {filtered.map((achievement, i) => (
                  <AchievementCard key={achievement.id} achievement={achievement} index={i} />
                ))}
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}
