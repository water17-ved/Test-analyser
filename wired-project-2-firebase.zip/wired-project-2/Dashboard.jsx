import React, { useState, useEffect, useCallback } from 'react';
import { Sword, Crown, Trophy, Target, UploadCloud, FileStack, BarChart3, Flame, Zap, AlertTriangle, RefreshCw } from 'lucide-react';
import { THEME } from './theme';
import { getPlayerStats, XP_PER_LEVEL } from './playerStats';

/* ============================================================
   DATA LAYER
   Stand-in for the real Firestore call (Dev 3: getStudentAttempts).
   Swapping this for a real fetch is a one-line change — every
   component below only depends on the { data, isLoading, error }
   shape, not on how it was fetched.
   ============================================================ */
function usePlayerData() {
  const [state, setState] = useState({ data: null, isLoading: true, error: null });

  const fetchData = useCallback(() => {
    setState({ data: null, isLoading: true, error: null });
    const timer = setTimeout(() => {
      // Reads from localStorage via playerStats.js.
      // Swap for a Firestore read once Dev 3's backend is live.
      const saved = getPlayerStats();
      const xpInLevel = saved.xp % XP_PER_LEVEL;
      setState({
        data: {
          name:         saved.name,
          rank:         saved.rank,   // null until leaderboard/Firestore sets it
          level:        saved.level,
          xp:           xpInLevel,
          xpToNext:     XP_PER_LEVEL,
          streak:       saved.streak,
          attemptsCount: saved.attemptsCount,
          nextTarget:   saved.attemptsCount > 0
            ? `${saved.attemptsCount} test${saved.attemptsCount !== 1 ? 's' : ''} logged — keep the streak alive.`
            : null,
          aim: saved.aim,             // null until AI rank prediction is live
        },
        isLoading: false,
        error: null,
      });
    }, 200);
    return () => clearTimeout(timer);
  }, []);

  useEffect(() => fetchData(), [fetchData]);

  return { ...state, retry: fetchData };
}

const QUOTES = [
  "Every topic you skip is a boss you'll face later.",
  "Rank up. Rivals are grinding right now.",
  "Consistency is your strongest weapon.",
  "The dungeon doesn't care about your excuses.",
  "Small XP daily beats one big grind weekly.",
];

/* ============================================================
   REUSABLE COMPONENTS
   Kept presentational (props in, JSX out) so Upload/Analysis
   screens can import the same building blocks.
   ============================================================ */

function QuoteBanner() {
  const [idx, setIdx] = useState(0);
  const [visible, setVisible] = useState(true);

  useEffect(() => {
    const interval = setInterval(() => {
      setVisible(false);
      setTimeout(() => {
        setIdx((i) => (i + 1) % QUOTES.length);
        setVisible(true);
      }, 300);
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="jbr-card px-6 py-4 text-center">
      <p
        className="jbr-label text-sm md:text-base transition-opacity duration-300"
        style={{ color: 'var(--text-main)', opacity: visible ? 1 : 0 }}
        aria-live="polite"
      >
        "{QUOTES[idx]}"
      </p>
    </div>
  );
}

function XPBar({ xp, xpToNext }) {
  const pct = xpToNext > 0 ? Math.min(100, Math.round((xp / xpToNext) * 100)) : 0;
  return (
    <div className="flex-1 md:max-w-xs">
      <div className="flex justify-between mb-1">
        <span className="jbr-label text-xs" style={{ color: 'var(--text-muted)' }}>XP</span>
        <span className="jbr-label text-xs" style={{ color: 'var(--gold-bright)' }}>{xp} / {xpToNext}</span>
      </div>
      <div className="jbr-xp-track h-3" role="progressbar" aria-valuenow={pct} aria-valuemin={0} aria-valuemax={100}>
        <div className="jbr-xp-fill" style={{ width: `${pct}%` }} />
      </div>
    </div>
  );
}

/* Derives a percentile label from { position, totalPlayers } — the same
   shape the Leaderboard screen will consume, so Dashboard and Leaderboard
   always agree on where the student stands rather than tracking two
   separate sources of truth (like the old static tier label did). */
function getPercentile(rank) {
  if (!rank || !rank.totalPlayers) return null;
  const pct = Math.max(1, Math.round((rank.position / rank.totalPlayers) * 100));
  return pct;
}

function RankBadge({ rank }) {
  if (!rank) return null;
  const pct = getPercentile(rank);
  return (
    <div className="flex items-center gap-2">
      <span className="jbr-label text-xs" style={{ color: 'var(--text-muted)' }}>
        RANK <span className="jbr-display" style={{ color: 'var(--gold-bright)' }}>#{rank.position.toLocaleString()}</span> OF {rank.totalPlayers.toLocaleString()}
      </span>
      {pct !== null && (
        <span
          className="jbr-label text-[10px] px-2 py-0.5 rounded-full"
          style={{ background: 'var(--panel-bg)', border: '1px solid var(--gold)', color: 'var(--gold-bright)' }}
        >
          TOP {pct}%
        </span>
      )}
    </div>
  );
}

function AimCard({ aim }) {
  if (!aim) return null;
  return (
    <div className="flex items-center gap-2 px-4 py-3 rounded-xl" style={{ background: 'var(--panel-bg)', border: '1px solid var(--border)' }}>
      <Target size={18} color="var(--phys)" />
      <div>
        <p className="jbr-label text-[10px]" style={{ color: 'var(--text-muted)' }}>{aim.label.toUpperCase()}</p>
        <p className="jbr-display text-sm font-bold" style={{ color: 'var(--phys)' }}>{aim.value}</p>
      </div>
    </div>
  );
}

function NavTile({ tile, onClick }) {
  const Icon = tile.icon;
  const disabled = !tile.screen;
  return (
    <button
      className={`jbr-card jbr-tile p-5 flex flex-col items-start gap-3 text-left w-full relative ${disabled ? 'disabled' : ''}`}
      aria-label={disabled ? `${tile.label} (coming soon)` : tile.label}
      aria-disabled={disabled}
      onClick={disabled ? undefined : onClick}
    >
      {disabled && (
        <span
          className="jbr-label text-[9px] absolute top-3 right-3 px-2 py-0.5 rounded-full"
          style={{ background: 'var(--panel-bg)', border: '1px solid var(--border)', color: 'var(--text-muted)' }}
        >
          SOON
        </span>
      )}
      <div
        className="w-10 h-10 rounded-lg flex items-center justify-center"
        style={{ background: 'var(--panel-bg)', border: `1px solid ${tile.color}` }}
      >
        <Icon size={18} color={tile.color} />
      </div>
      <span className="jbr-label text-sm font-semibold">{tile.label}</span>
    </button>
  );
}

const NAV_TILES = [
  { key: 'tests', label: 'Tests', icon: Sword, color: 'var(--gold)', screen: 'tests' },
  { key: 'papers', label: 'Question Papers', icon: FileStack, color: 'var(--phys)', screen: 'papers' },
  { key: 'leaderboard', label: 'Leaderboard', icon: Crown, color: '#ffd93d', screen: null },
  { key: 'achievements', label: 'Achievements', icon: Trophy, color: 'var(--gold-bright)', screen: 'achievements' },
  { key: 'analytics', label: 'Overall Analytics', icon: BarChart3, color: 'var(--maths)', screen: 'analytics' },
  { key: 'uploads', label: 'Uploads', icon: UploadCloud, color: 'var(--chem)', screen: 'upload' },
];

/* ---- Loading skeleton, matches real layout so there's no jump ---- */
function DashboardSkeleton() {
  return (
    <div className="space-y-8" aria-busy="true" aria-label="Loading dashboard">
      <div className="jbr-skeleton h-14 rounded-2xl" />
      <div className="jbr-skeleton h-44 rounded-2xl" />
      <div className="grid grid-cols-3 gap-4">
        {[0, 1, 2].map((i) => <div key={i} className="jbr-skeleton h-24 rounded-2xl" />)}
      </div>
      <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
        {[0, 1, 2, 3, 4].map((i) => <div key={i} className="jbr-skeleton h-24 rounded-2xl" />)}
      </div>
    </div>
  );
}

/* ---- Error state with retry ---- */
function DashboardError({ onRetry }) {
  return (
    <div className="jbr-card p-8 flex flex-col items-center text-center gap-3">
      <AlertTriangle size={28} color="var(--danger)" />
      <p className="jbr-label text-sm" style={{ color: 'var(--text-main)' }}>Couldn't load your stats.</p>
      <p className="text-xs" style={{ color: 'var(--text-muted)' }}>Check your connection and try again.</p>
      <button
        onClick={onRetry}
        className="jbr-label mt-2 px-4 py-2 rounded-lg flex items-center gap-2 text-sm"
        style={{ background: 'var(--gold)', color: '#160a00' }}
      >
        <RefreshCw size={14} /> RETRY
      </button>
    </div>
  );
}

/* ---- Empty state: no attempts yet ---- */
function EmptyProgress() {
  return (
    <div className="jbr-card p-6 flex items-center gap-4">
      <div className="w-12 h-12 rounded-xl flex items-center justify-center jbr-pulse" style={{ background: 'var(--panel-bg)', border: '1px solid var(--border)' }}>
        <Sword size={20} color="var(--gold)" />
      </div>
      <div>
        <p className="jbr-label text-sm" style={{ color: 'var(--text-main)' }}>No battles fought yet.</p>
        <p className="text-xs" style={{ color: 'var(--text-muted)' }}>Take your first test to start earning XP and unlock stats.</p>
      </div>
    </div>
  );
}

/* ============================================================
   MAIN DASHBOARD
   ============================================================ */
export default function Dashboard({ onNavigate }) {
  const { data, isLoading, error, retry } = usePlayerData();
  const hasAttempts = data && data.attemptsCount > 0;

  return (
    <div className="jbr-root jbr-glow-bg">
      <style>{THEME}</style>

      <div className="max-w-5xl mx-auto px-5 py-8 space-y-8">
        <header className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-xl flex items-center justify-center" style={{ background: 'linear-gradient(135deg, #7a0d3a, #3a0620)' }}>
              <Zap size={22} color="#ffe1ec" strokeWidth={2.5} />
            </div>
            <div>
              <h1 className="jbr-display text-xl font-bold jbr-gradient-text">JEE BATTLE ROYALE</h1>
              <p className="jbr-label text-xs" style={{ color: 'var(--text-muted)' }}>SURVIVE TO LEVEL 50</p>
            </div>
          </div>
          {!isLoading && !error && data && (
            <div className="flex items-center gap-2 px-3 py-1.5 rounded-full jbr-card">
              <Flame size={16} color="var(--gold)" />
              <span className="jbr-label text-sm" style={{ color: 'var(--gold-bright)' }}>{data.streak} day streak</span>
            </div>
          )}
        </header>

        {error ? (
          <DashboardError onRetry={retry} />
        ) : isLoading ? (
          <DashboardSkeleton />
        ) : (
          <>
            <QuoteBanner />

            <div className="jbr-card p-6">
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
                <div className="flex items-center gap-4">
                  <div className="w-16 h-16 rounded-2xl flex items-center justify-center jbr-pulse" style={{ background: 'linear-gradient(135deg, var(--gold), var(--xp))' }}>
                    <span className="jbr-display text-xl font-black text-white">{data.level}</span>
                  </div>
                  <div>
                    <RankBadge rank={data.rank} />
                    <h2 className="jbr-display text-lg font-bold mt-0.5">{data.name}</h2>
                  </div>
                </div>
                <XPBar xp={data.xp} xpToNext={data.xpToNext} />
                <AimCard aim={hasAttempts ? data.aim : null} />
              </div>

              <div className="jbr-divider my-4" />

              {hasAttempts ? (
                <div className="flex items-center gap-2">
                  <Trophy size={16} color="var(--gold-bright)" />
                  <p className="text-sm" style={{ color: 'var(--text-main)' }}>
                    <span className="jbr-label" style={{ color: 'var(--gold-bright)' }}>NEXT TARGET —</span> {data.nextTarget}
                  </p>
                </div>
              ) : (
                <p className="text-xs" style={{ color: 'var(--text-muted)' }}>Your next target will appear after your first test.</p>
              )}
            </div>

            {!hasAttempts && <EmptyProgress />}

            <div>
              <p className="jbr-label text-xs mb-3" style={{ color: 'var(--text-muted)' }}>DUNGEON MAP</p>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
                {NAV_TILES.map((tile) => (
                  <NavTile key={tile.key} tile={tile} onClick={() => onNavigate?.(tile.screen)} />
                ))}
              </div>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
