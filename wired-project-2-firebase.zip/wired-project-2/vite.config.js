import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// If deploying to GitHub Pages at https://<user>.github.io/<repo>/,
// set base to '/<repo>/'. If deploying to Vercel (or a custom domain,
// or a *.github.io user/org root site), leave it as '/'.
export default defineConfig({
  plugins: [react()],
  base: '/test-analyse-/',
});
