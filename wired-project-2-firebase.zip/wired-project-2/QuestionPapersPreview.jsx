import React, { useState, useEffect, useCallback, useMemo, memo } from 'react';
import {
  FileStack, ChevronRight, ChevronLeft, ChevronDown, CheckCircle2,
  Search, Calendar, ListChecks, AlertTriangle, RefreshCw, Bookmark, BookmarkCheck, Layers,
} from 'lucide-react';
import { THEME, SUBJECT_META } from './theme';
import { getUploadedPapers } from './uploadedPapers';

/* ============================================================
   DATA LAYER — same shape/content as questionPapersData.js.
   ============================================================ */
/* All papers come from uploadedPapers.js (localStorage).
   Seed data removed — the list starts empty for a new user
   and populates as they upload via UploadScreen. */
const QUESTION_PAPERS = [];

function usePapersData() {
  const [state, setState] = useState({ data: null, isLoading: true, error: null });
  const fetchData = useCallback(() => {
    setState({ data: null, isLoading: true, error: null });
    const timer = setTimeout(() => {
      const merged = [...getUploadedPapers(), ...QUESTION_PAPERS]; // real uploads first, seed data after
      setState({ data: merged, isLoading: false, error: null });
    }, 500);
    return () => clearTimeout(timer);
  }, []);
  useEffect(() => fetchData(), [fetchData]);
  return { ...state, retry: fetchData };
}

function usePaperById(paperId) {
  const [state, setState] = useState({ data: null, isLoading: true, error: null });
  const fetchData = useCallback(() => {
    if (!paperId) { setState({ data: null, isLoading: false, error: null }); return undefined; }
    setState({ data: null, isLoading: true, error: null });
    const timer = setTimeout(() => {
      const found = [...getUploadedPapers(), ...QUESTION_PAPERS].find((p) => p.id === paperId) || null;
      setState({ data: found, isLoading: false, error: found ? null : 'Paper not found.' });
    }, 350);
    return () => clearTimeout(timer);
  }, [paperId]);
  useEffect(() => fetchData(), [fetchData]);
  return { ...state, retry: fetchData };
}

/* ============================================================
   BOOKMARKS
   Key shape: "paperId::subjectKey::questionNumber" — matches how
   a Firestore doc id under /users/{uid}/bookmarks/{bookmarkId}
   would be built once Dev 3 wires this to real auth. Persisted to
   localStorage for now so it survives refreshes without a backend.
   ============================================================ */
const BOOKMARKS_STORAGE_KEY = 'jbr_bookmarks_v1';

function makeBookmarkKey(paperId, subjectKey, number) {
  return `${paperId}::${subjectKey}::${number}`;
}

function parseBookmarkKey(key) {
  const [paperId, subjectKey, numberStr] = key.split('::');
  return { paperId, subjectKey, number: Number(numberStr) };
}

function readStoredBookmarks() {
  try {
    const raw = localStorage.getItem(BOOKMARKS_STORAGE_KEY);
    const parsed = raw ? JSON.parse(raw) : [];
    return new Set(Array.isArray(parsed) ? parsed : []);
  } catch {
    return new Set();
  }
}

function useBookmarks() {
  const [bookmarkedKeys, setBookmarkedKeys] = useState(() => readStoredBookmarks());

  const persist = useCallback((nextSet) => {
    try {
      localStorage.setItem(BOOKMARKS_STORAGE_KEY, JSON.stringify(Array.from(nextSet)));
    } catch {
      // Storage unavailable (private mode/quota) — bookmarks stay in memory for this session.
    }
  }, []);

  const toggleBookmark = useCallback((key) => {
    setBookmarkedKeys((prev) => {
      const next = new Set(prev);
      if (next.has(key)) next.delete(key); else next.add(key);
      persist(next);
      return next;
    });
  }, [persist]);

  const removeBookmark = useCallback((key) => {
    setBookmarkedKeys((prev) => {
      if (!prev.has(key)) return prev;
      const next = new Set(prev);
      next.delete(key);
      persist(next);
      return next;
    });
  }, [persist]);

  return { bookmarkedKeys, toggleBookmark, removeBookmark, count: bookmarkedKeys.size };
}

/* ============================================================
   SHARED PIECES
   ============================================================ */
const SubjectChip = memo(function SubjectChip({ subjectKey, count, active, onClick }) {
  const meta = SUBJECT_META[subjectKey];
  const Icon = meta.icon;
  return (
    <button
      className="jbr-chip"
      aria-pressed={active}
      onClick={onClick}
      style={active ? { borderColor: meta.color, boxShadow: `0 0 16px -6px ${meta.color}` } : {}}
    >
      <Icon size={14} color={active ? meta.color : 'var(--text-muted)'} />
      <span className="jbr-label text-xs" style={{ color: active ? 'var(--text-main)' : 'var(--text-muted)' }}>
        {meta.label} · {count}
      </span>
    </button>
  );
});

const PaperCard = memo(function PaperCard({ paper, onSelect }) {
  const subjectKeys = Object.keys(paper.subjects);
  return (
    <button
      className="jbr-card jbr-tile p-5 flex flex-col gap-3 text-left w-full"
      onClick={() => onSelect(paper.id)}
      aria-label={`Open ${paper.title}`}
    >
      <div className="flex items-start justify-between gap-3">
        <div className="flex items-center gap-3 min-w-0">
          <div className="w-10 h-10 rounded-lg flex items-center justify-center shrink-0" style={{ background: 'var(--panel-bg)', border: '1px solid var(--gold)' }}>
            <FileStack size={18} color="var(--gold-bright)" />
          </div>
          <div className="min-w-0">
            <p className="jbr-label text-sm font-semibold truncate">{paper.title}</p>
            <p className="text-xs flex items-center gap-1 mt-0.5 flex-wrap" style={{ color: 'var(--text-muted)' }}>
              <Calendar size={11} /> {paper.uploadedOn} <span className="mx-1">·</span> <ListChecks size={11} /> {paper.questionCount} questions
              {paper.status === 'processing' && (
                <span className="jbr-label text-[9px] ml-1 px-2 py-0.5 rounded-full" style={{ background: 'var(--panel-bg)', border: '1px solid var(--gold)', color: 'var(--gold-bright)' }}>
                  PROCESSING
                </span>
              )}
            </p>
          </div>
        </div>
        <ChevronRight size={18} color="var(--text-muted)" className="shrink-0" />
      </div>
      <div className="flex gap-2 flex-wrap">
        {subjectKeys.map((key) => {
          const meta = SUBJECT_META[key];
          const Icon = meta.icon;
          return (
            <span key={key} className="jbr-label text-[10px] px-2 py-1 rounded-full flex items-center gap-1" style={{ background: 'var(--panel-bg)', border: `1px solid ${meta.color}`, color: meta.color }}>
              <Icon size={11} /> {paper.subjects[key].length}
            </span>
          );
        })}
      </div>
    </button>
  );
});

const BookmarkButton = memo(function BookmarkButton({ active, onToggle, questionNumber }) {
  return (
    <button
      className={`jbr-icon-btn shrink-0 ${active ? 'active' : ''}`}
      style={{ width: 32, height: 32 }}
      onClick={onToggle}
      aria-pressed={active}
      aria-label={active ? `Remove bookmark for question ${questionNumber}` : `Bookmark question ${questionNumber}`}
    >
      {active
        ? <BookmarkCheck size={15} color="var(--gold-bright)" />
        : <Bookmark size={15} color="var(--text-muted)" />}
    </button>
  );
});

const QuestionCard = memo(function QuestionCard({ question, isBookmarked, onToggleBookmark, paperBadge }) {
  return (
    <div className="jbr-panel p-4">
      <div className="flex items-start justify-between gap-3 mb-3">
        <p className="text-sm" style={{ color: 'var(--text-main)' }}>
          <span className="jbr-label" style={{ color: 'var(--gold-bright)' }}>Q{question.number}.</span> {question.text}
          {paperBadge && (
            <button
              className="jbr-label text-[10px] ml-2 align-middle px-2 py-0.5 rounded-full"
              style={{ background: 'var(--panel-bg)', border: '1px solid var(--border)', color: 'var(--text-muted)' }}
              onClick={paperBadge.onClick}
              aria-label={`Open ${paperBadge.label}`}
            >
              {paperBadge.label}
            </button>
          )}
        </p>
        {onToggleBookmark && (
          <BookmarkButton active={isBookmarked} onToggle={onToggleBookmark} questionNumber={question.number} />
        )}
      </div>
      <div className="grid sm:grid-cols-2 gap-2">
        {question.options.map((opt, idx) => {
          const isCorrect = idx === question.correctIndex;
          return (
            <div key={idx} className={`jbr-option ${isCorrect ? 'correct' : ''}`}>
              {isCorrect
                ? <CheckCircle2 size={14} color="var(--chem)" className="shrink-0" />
                : <span className="jbr-label text-xs shrink-0" style={{ color: 'var(--text-muted)' }}>{String.fromCharCode(97 + idx)})</span>}
              <span className="text-xs" style={{ color: isCorrect ? 'var(--chem)' : 'var(--text-muted)' }}>{opt}</span>
            </div>
          );
        })}
      </div>
    </div>
  );
});

/* ============================================================
   PAGE 1 — LIST
   ============================================================ */
function QuestionPapersList({ onSelectPaper, onOpenBookmarks, bookmarkCount, onBack }) {
  const { data: papers, isLoading, error, retry } = usePapersData();
  const [search, setSearch] = useState('');

  const filteredPapers = useMemo(() => {
    if (!papers) return [];
    if (!search.trim()) return papers;
    const q = search.trim().toLowerCase();
    return papers.filter((p) => p.title.toLowerCase().includes(q));
  }, [papers, search]);

  return (
    <div className="max-w-3xl mx-auto px-5 py-8 space-y-6">
      <header className="flex items-start justify-between gap-3">
        <div className="flex items-start gap-3">
          {onBack && (
            <button onClick={onBack} aria-label="Back to Dashboard" className="jbr-panel p-2 rounded-lg shrink-0 mt-0.5">
              <ChevronLeft size={18} color="var(--text-muted)" />
            </button>
          )}
          <div>
            <h1 className="jbr-display text-xl font-bold jbr-gradient-text">QUESTION PAPERS</h1>
            <p className="jbr-label text-xs mt-1" style={{ color: 'var(--text-muted)' }}>BROWSE AND PREVIEW YOUR ARCHIVE</p>
          </div>
        </div>
        <button
          className="jbr-icon-btn relative shrink-0"
          style={{ width: 40, height: 40 }}
          onClick={onOpenBookmarks}
          aria-label={`View bookmarked questions${bookmarkCount ? ` (${bookmarkCount})` : ''}`}
        >
          <Bookmark size={17} color="var(--gold-bright)" />
          {bookmarkCount > 0 && (
            <span
              className="jbr-label absolute -top-1.5 -right-1.5 text-[9px] min-w-[16px] h-4 px-1 rounded-full flex items-center justify-center"
              style={{ background: 'var(--xp)', color: '#fff' }}
            >
              {bookmarkCount}
            </span>
          )}
        </button>
      </header>

      <div className="relative">
        <Search size={15} color="var(--text-muted)" className="absolute left-3 top-1/2 -translate-y-1/2" />
        <input
          className="jbr-input pl-9"
          placeholder="Search papers by name…"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          aria-label="Search papers by name"
        />
      </div>

      {error ? (
        <div className="jbr-card p-8 flex flex-col items-center text-center gap-3">
          <AlertTriangle size={28} color="var(--danger)" />
          <p className="jbr-label text-sm" style={{ color: 'var(--text-main)' }}>Couldn't load question papers.</p>
          <button onClick={retry} className="jbr-label mt-2 px-4 py-2 rounded-lg flex items-center gap-2 text-sm" style={{ background: 'var(--gold)', color: '#160a00' }}>
            <RefreshCw size={14} /> RETRY
          </button>
        </div>
      ) : isLoading ? (
        <div className="space-y-4" aria-busy="true" aria-label="Loading question papers">
          {[0, 1, 2].map((i) => <div key={i} className="jbr-skeleton h-28 rounded-2xl" />)}
        </div>
      ) : filteredPapers.length === 0 ? (
        <div className="jbr-card p-8 flex flex-col items-center text-center gap-3">
          <FileStack size={28} color="var(--gold)" />
          <p className="jbr-label text-sm" style={{ color: 'var(--text-main)' }}>
            {search.trim() ? 'No papers match your search.' : 'No question papers yet.'}
          </p>
        </div>
      ) : (
        <div className="space-y-4">
          {filteredPapers.map((paper) => <PaperCard key={paper.id} paper={paper} onSelect={onSelectPaper} />)}
        </div>
      )}
    </div>
  );
}

/* ============================================================
   PAGE 2 — DETAIL
   ============================================================ */
function QuestionPaperDetail({ paperId, onBack, bookmarkedKeys, onToggleBookmark }) {
  const { data: paper, isLoading, error, retry } = usePaperById(paperId);
  const [activeSubject, setActiveSubject] = useState(null);
  const [query, setQuery] = useState('');

  const subjectKeys = paper ? Object.keys(paper.subjects) : [];
  const currentSubject = activeSubject && subjectKeys.includes(activeSubject) ? activeSubject : subjectKeys[0];

  const questions = useMemo(() => {
    if (!paper || !currentSubject) return [];
    const list = paper.subjects[currentSubject] || [];
    if (!query.trim()) return list;
    const q = query.trim().toLowerCase();
    return list.filter((item) => item.text.toLowerCase().includes(q) || String(item.number).includes(q));
  }, [paper, currentSubject, query]);

  return (
    <div className="max-w-3xl mx-auto px-5 py-8 space-y-6">
      <header className="flex items-center gap-3">
        <button onClick={onBack} aria-label="Back to Question Papers" className="jbr-panel p-2 rounded-lg shrink-0">
          <ChevronLeft size={18} color="var(--text-muted)" />
        </button>
        <div className="min-w-0">
          <h1 className="jbr-display text-lg font-bold truncate">{paper ? paper.title : 'Loading…'}</h1>
          {paper && <p className="jbr-label text-xs" style={{ color: 'var(--text-muted)' }}>PREVIEW · {paper.questionCount} QUESTIONS TOTAL</p>}
        </div>
      </header>

      {error ? (
        <div className="jbr-card p-8 flex flex-col items-center text-center gap-3">
          <AlertTriangle size={28} color="var(--danger)" />
          <p className="jbr-label text-sm" style={{ color: 'var(--text-main)' }}>{error}</p>
          <div className="flex gap-2 mt-2">
            <button onClick={onBack} className="jbr-label px-4 py-2 rounded-lg text-sm jbr-panel">BACK TO LIST</button>
            <button onClick={retry} className="jbr-label px-4 py-2 rounded-lg flex items-center gap-2 text-sm" style={{ background: 'var(--gold)', color: '#160a00' }}>
              <RefreshCw size={14} /> RETRY
            </button>
          </div>
        </div>
      ) : isLoading || !paper ? (
        <div className="space-y-4" aria-busy="true" aria-label="Loading paper">
          <div className="jbr-skeleton h-9 w-2/3 rounded-lg" />
          <div className="flex gap-2">{[0, 1, 2].map((i) => <div key={i} className="jbr-skeleton h-8 w-24 rounded-full" />)}</div>
          {[0, 1, 2].map((i) => <div key={i} className="jbr-skeleton h-24 rounded-2xl" />)}
        </div>
      ) : (
        <>
          <div className="flex gap-2 flex-wrap">
            {subjectKeys.map((key) => (
              <SubjectChip key={key} subjectKey={key} count={paper.subjects[key].length} active={currentSubject === key} onClick={() => setActiveSubject(key)} />
            ))}
          </div>

          <div className="relative">
            <Search size={15} color="var(--text-muted)" className="absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              className="jbr-input pl-9"
              placeholder="Search by question number or text…"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              aria-label="Search questions in this subject"
            />
          </div>

          <div className="jbr-divider" />

          {questions.length === 0 ? (
            <div className="jbr-card p-6 flex items-center gap-3">
              <AlertTriangle size={18} color="var(--danger)" />
              <p className="text-xs" style={{ color: 'var(--text-muted)' }}>
                {paper.status === 'processing' && !(paper.subjects[currentSubject] || []).length
                  ? "Still processing — questions will appear here once analysis finishes."
                  : `No questions match "${query}" in this subject.`}
              </p>
            </div>
          ) : (
            <div className="space-y-3">
              {questions.map((q) => {
                const key = makeBookmarkKey(paper.id, currentSubject, q.number);
                return (
                  <QuestionCard
                    key={q.number}
                    question={q}
                    isBookmarked={bookmarkedKeys.has(key)}
                    onToggleBookmark={() => onToggleBookmark(key)}
                  />
                );
              })}
            </div>
          )}
        </>
      )}
    </div>
  );
}

/* ============================================================
   PAGE 3 — BOOKMARKS
   Groups saved questions Subject → Chapter, merged across every
   uploaded paper — a chapter that shows up in two different papers
   collapses into one section instead of repeating. Each question
   carries a small badge naming its source paper so you can still
   tell them apart (and jump straight to that paper). Chapters are
   built purely from whatever `chapter` values exist on bookmarked
   questions, so new chapters just appear as new papers are
   uploaded — nothing here is a fixed/static list.
   ============================================================ */
const SUBJECT_ORDER = Object.keys(SUBJECT_META);

function BookmarksView({ onBack, onSelectPaper, bookmarkedKeys, onRemoveBookmark }) {
  const { data: papers, isLoading, error, retry } = usePapersData();
  const [expanded, setExpanded] = useState(() => new Set());

  const toggleCollapsed = useCallback((id) => {
    setExpanded((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id); else next.add(id);
      return next;
    });
  }, []);

  const groups = useMemo(() => {
    if (!papers) return [];
    const paperMap = new Map(papers.map((p) => [p.id, p]));
    const bySubject = new Map();

    bookmarkedKeys.forEach((key) => {
      const { paperId, subjectKey, number } = parseBookmarkKey(key);
      const paper = paperMap.get(paperId);
      const question = paper?.subjects[subjectKey]?.find((q) => q.number === number);
      if (!paper || !question) return; // stale bookmark — source question no longer exists

      if (!bySubject.has(subjectKey)) bySubject.set(subjectKey, new Map());
      const chapterMap = bySubject.get(subjectKey);
      const chapter = question.chapter || 'Uncategorized';
      if (!chapterMap.has(chapter)) chapterMap.set(chapter, []);
      chapterMap.get(chapter).push({ question, key, paper });
    });

    const orderedSubjectKeys = [
      ...SUBJECT_ORDER.filter((k) => bySubject.has(k)),
      ...Array.from(bySubject.keys()).filter((k) => !SUBJECT_ORDER.includes(k)),
    ];

    return orderedSubjectKeys.map((subjectKey) => {
      const byChapter = bySubject.get(subjectKey);
      const chapters = Array.from(byChapter.entries())
        .sort(([a], [b]) => a.localeCompare(b)) // chapters auto-ordered alphabetically
        .map(([chapter, items]) => ({
          chapter,
          items: items.slice().sort((a, b) => a.paper.title.localeCompare(b.paper.title) || a.question.number - b.question.number),
        }));
      return { subjectKey, chapters, count: chapters.reduce((sum, c) => sum + c.items.length, 0) };
    });
  }, [papers, bookmarkedKeys]);

  const totalCount = bookmarkedKeys.size;

  return (
    <div className="max-w-3xl mx-auto px-5 py-8 space-y-6">
      <header className="flex items-center gap-3">
        <button onClick={onBack} aria-label="Back to Question Papers" className="jbr-panel p-2 rounded-lg shrink-0">
          <ChevronLeft size={18} color="var(--text-muted)" />
        </button>
        <div className="min-w-0">
          <h1 className="jbr-display text-lg font-bold">BOOKMARKS</h1>
          <p className="jbr-label text-xs" style={{ color: 'var(--text-muted)' }}>{totalCount} QUESTION{totalCount === 1 ? '' : 'S'} SAVED</p>
        </div>
      </header>

      {error ? (
        <div className="jbr-card p-8 flex flex-col items-center text-center gap-3">
          <AlertTriangle size={28} color="var(--danger)" />
          <p className="jbr-label text-sm" style={{ color: 'var(--text-main)' }}>Couldn't load your papers.</p>
          <button onClick={retry} className="jbr-label mt-2 px-4 py-2 rounded-lg flex items-center gap-2 text-sm" style={{ background: 'var(--gold)', color: '#160a00' }}>
            <RefreshCw size={14} /> RETRY
          </button>
        </div>
      ) : isLoading ? (
        <div className="space-y-4" aria-busy="true" aria-label="Loading bookmarks">
          {[0, 1].map((i) => <div key={i} className="jbr-skeleton h-24 rounded-2xl" />)}
        </div>
      ) : totalCount === 0 ? (
        <div className="jbr-card p-8 flex flex-col items-center text-center gap-3">
          <Bookmark size={28} color="var(--gold)" />
          <p className="jbr-label text-sm" style={{ color: 'var(--text-main)' }}>No bookmarks yet.</p>
          <p className="text-xs" style={{ color: 'var(--text-muted)' }}>Tap the bookmark icon on any question to save it here.</p>
        </div>
      ) : (
        <div className="space-y-4">
          {groups.map(({ subjectKey, chapters, count }) => {
            const subjectCollapsed = !expanded.has(subjectKey);
            const meta = SUBJECT_META[subjectKey] || { label: subjectKey, color: 'var(--text-muted)', icon: FileStack };
            const Icon = meta.icon;
            return (
              <div key={subjectKey} className="jbr-card p-4">
                <button className="jbr-group-header" onClick={() => toggleCollapsed(subjectKey)} aria-expanded={!subjectCollapsed}>
                  <span className="flex items-center gap-2 min-w-0">
                    <Icon size={16} color={meta.color} className="shrink-0" />
                    <span className="jbr-label text-sm font-semibold" style={{ color: meta.color }}>{meta.label}</span>
                    <span className="jbr-label text-[10px] px-2 py-0.5 rounded-full shrink-0" style={{ background: 'var(--panel-bg)', border: '1px solid var(--border)', color: 'var(--text-muted)' }}>
                      {count}
                    </span>
                  </span>
                  <ChevronDown size={16} color="var(--text-muted)" style={{ transform: subjectCollapsed ? 'rotate(-90deg)' : 'none', transition: 'transform .2s ease' }} />
                </button>

                {!subjectCollapsed && (
                  <div className="mt-2 space-y-3">
                    {chapters.map(({ chapter, items }) => {
                      const chapterGroupId = `${subjectKey}::${chapter}`;
                      const chapterCollapsed = !expanded.has(chapterGroupId);
                      return (
                        <div key={chapter} className="jbr-panel p-3">
                          <button className="jbr-group-header p-0" onClick={() => toggleCollapsed(chapterGroupId)} aria-expanded={!chapterCollapsed}>
                            <span className="flex items-center gap-2 min-w-0">
                              <Layers size={13} color="var(--text-muted)" className="shrink-0" />
                              <span className="jbr-label text-xs font-semibold truncate">{chapter}</span>
                              <span className="jbr-label text-[10px]" style={{ color: 'var(--text-muted)' }}>· {items.length}</span>
                            </span>
                            <ChevronDown size={14} color="var(--text-muted)" style={{ transform: chapterCollapsed ? 'rotate(-90deg)' : 'none', transition: 'transform .2s ease' }} />
                          </button>

                          {!chapterCollapsed && (
                            <div className="mt-3 space-y-2">
                              {items.map(({ question, key, paper }) => (
                                <QuestionCard
                                  key={key}
                                  question={question}
                                  isBookmarked
                                  onToggleBookmark={() => onRemoveBookmark(key)}
                                  paperBadge={{ label: paper.title, onClick: () => onSelectPaper(paper.id) }}
                                />
                              ))}
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

/* ============================================================
   TAB CONTAINER
   ============================================================ */
export default function QuestionPapersPreview({ onBack, initialPaperId }) {
  // initialPaperId is set when the user arrives via TestsTab's "View Question Paper"
  // button. If provided, skip the list and go straight to the detail view.
  const [view, setView] = useState(initialPaperId ? 'detail' : 'list');
  const [selectedPaperId, setSelectedPaperId] = useState(initialPaperId || null);
  const { bookmarkedKeys, toggleBookmark, removeBookmark, count: bookmarkCount } = useBookmarks();

  const openPaper = (paperId) => { setSelectedPaperId(paperId); setView('detail'); };

  return (
    <div className="jbr-root jbr-glow-bg">
      <style>{THEME}</style>
      {view === 'detail' ? (
        <QuestionPaperDetail
          paperId={selectedPaperId}
          onBack={() => setView('list')}
          bookmarkedKeys={bookmarkedKeys}
          onToggleBookmark={toggleBookmark}
        />
      ) : view === 'bookmarks' ? (
        <BookmarksView
          onBack={() => setView('list')}
          onSelectPaper={openPaper}
          bookmarkedKeys={bookmarkedKeys}
          onRemoveBookmark={removeBookmark}
        />
      ) : (
        <QuestionPapersList
          onSelectPaper={openPaper}
          onOpenBookmarks={() => setView('bookmarks')}
          bookmarkCount={bookmarkCount}
          onBack={onBack}
        />
      )}
    </div>
  );
}
