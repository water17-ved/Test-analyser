import { useState, useEffect, useCallback } from 'react';
import { Flame, Sword, Target, Crown, BarChart3, Atom, FlaskConical, Sigma, Dna } from 'lucide-react';
import { TIER_ORDER } from './theme';
import { getPlayerStats } from './playerStats';
import { getTests } from './testsStorage';

/* ============================================================
   CATALOG
   Built around how NEET and JEE actually work, not a generic
   %-based ladder:
   - NEET is scored out of 720 marks -> score tiers use real marks bands.
   - JEE Main is scored by percentile -> score tiers use percentile bands.
   - Subjects differ: NEET has Biology, JEE has Maths; Physics and
     Chemistry are common to both.
   - Rank pools are separate (NEET AIR vs JEE AIR), so volume and rank
     tracks are split per exam. `exam: null` means the achievement is
     shared (streaks, Physics/Chemistry mastery, first mock overall).
   `comparator` defaults to "gte"; rank uses "lte" (lower AIR is better).
   ============================================================ */
export const ACHIEVEMENT_CATALOG = [
  // --- Streak (exam-agnostic study habit) ---
  { id: 'streak-3', category: 'streak', tier: 'bronze', exam: null, title: 'Warming Up', description: 'Reach a 3-day streak.', icon: Flame, metric: 'streak', target: 3 },
  { id: 'streak-7', category: 'streak', tier: 'silver', exam: null, title: 'On Fire', description: 'Reach a 7-day streak.', icon: Flame, metric: 'streak', target: 7 },
  { id: 'streak-30', category: 'streak', tier: 'gold', exam: null, title: 'Unstoppable', description: 'Reach a 30-day streak.', icon: Flame, metric: 'streak', target: 30 },
  { id: 'streak-100', category: 'streak', tier: 'diamond', exam: null, title: 'Immortal', description: 'Reach a 100-day streak.', icon: Flame, metric: 'streak', target: 100 },

  // --- Volume: one shared icebreaker, then per-exam tracks ---
  { id: 'vol-first', category: 'volume', tier: 'bronze', exam: null, title: 'First Blood', description: 'Complete your first mock test — NEET or JEE.', icon: Sword, metric: 'attemptsCount', target: 1 },

  { id: 'neet-vol-1', category: 'volume', tier: 'bronze', exam: 'neet', title: 'NEET Debut', description: 'Complete your first NEET mock.', icon: Sword, metric: 'neetAttemptsCount', target: 1 },
  { id: 'neet-vol-10', category: 'volume', tier: 'silver', exam: 'neet', title: 'NEET Regular', description: 'Complete 10 NEET mocks.', icon: Sword, metric: 'neetAttemptsCount', target: 10 },
  { id: 'neet-vol-50', category: 'volume', tier: 'gold', exam: 'neet', title: 'NEET Veteran', description: 'Complete 50 NEET mocks.', icon: Sword, metric: 'neetAttemptsCount', target: 50 },

  { id: 'jee-vol-1', category: 'volume', tier: 'bronze', exam: 'jee', title: 'JEE Debut', description: 'Complete your first JEE mock.', icon: Sword, metric: 'jeeAttemptsCount', target: 1 },
  { id: 'jee-vol-10', category: 'volume', tier: 'silver', exam: 'jee', title: 'JEE Regular', description: 'Complete 10 JEE mocks.', icon: Sword, metric: 'jeeAttemptsCount', target: 10 },
  { id: 'jee-vol-50', category: 'volume', tier: 'gold', exam: 'jee', title: 'JEE Veteran', description: 'Complete 50 JEE mocks.', icon: Sword, metric: 'jeeAttemptsCount', target: 50 },

  // --- Score: NEET uses /720 marks bands, JEE uses percentile bands ---
  { id: 'neet-score-450', category: 'score', tier: 'bronze', exam: 'neet', title: 'Qualifying Zone', description: 'Score 450+ in a NEET mock (general-category qualifying range).', icon: Target, metric: 'neetBestScore', target: 450 },
  { id: 'neet-score-550', category: 'score', tier: 'silver', exam: 'neet', title: 'State Quota Contender', description: 'Score 550+ in a NEET mock.', icon: Target, metric: 'neetBestScore', target: 550 },
  { id: 'neet-score-620', category: 'score', tier: 'gold', exam: 'neet', title: 'Govt MBBS Range', description: 'Score 620+ in a NEET mock.', icon: Target, metric: 'neetBestScore', target: 620 },
  { id: 'neet-score-680', category: 'score', tier: 'diamond', exam: 'neet', title: 'AIIMS Delhi Range', description: 'Score 680+ in a NEET mock.', icon: Target, metric: 'neetBestScore', target: 680 },

  { id: 'jee-score-90', category: 'score', tier: 'bronze', exam: 'jee', title: 'Mains Qualified', description: 'Hit the 90th percentile in a JEE Main mock.', icon: Target, metric: 'jeeBestPercentile', target: 90 },
  { id: 'jee-score-95', category: 'score', tier: 'silver', exam: 'jee', title: 'Strong Contender', description: 'Hit the 95th percentile in a JEE Main mock.', icon: Target, metric: 'jeeBestPercentile', target: 95 },
  { id: 'jee-score-99', category: 'score', tier: 'gold', exam: 'jee', title: 'NIT Range', description: 'Hit the 99th percentile in a JEE Main mock.', icon: Target, metric: 'jeeBestPercentile', target: 99 },
  { id: 'jee-score-999', category: 'score', tier: 'diamond', exam: 'jee', title: 'Advanced Qualifier', description: 'Cross 99.9 percentile — JEE Advanced qualifying range.', icon: Target, metric: 'jeeBestPercentile', target: 99.9 },

  // --- Subject mastery: Physics & Chemistry shared, Maths (JEE) / Biology (NEET) split ---
  { id: 'subj-phys-70', category: 'subject', tier: 'bronze', exam: null, title: 'Physics Learner', description: '70%+ average in Physics.', icon: Atom, metric: 'physicsAvgPct', target: 70 },
  { id: 'subj-phys-90', category: 'subject', tier: 'gold', exam: null, title: 'Physics Prodigy', description: '90%+ average in Physics.', icon: Atom, metric: 'physicsAvgPct', target: 90 },

  { id: 'subj-chem-70', category: 'subject', tier: 'bronze', exam: null, title: 'Chemistry Learner', description: '70%+ average in Chemistry.', icon: FlaskConical, metric: 'chemistryAvgPct', target: 70 },
  { id: 'subj-chem-90', category: 'subject', tier: 'gold', exam: null, title: 'Chem Whiz', description: '90%+ average in Chemistry.', icon: FlaskConical, metric: 'chemistryAvgPct', target: 90 },

  { id: 'subj-maths-70', category: 'subject', tier: 'bronze', exam: 'jee', title: 'Maths Learner', description: '70%+ average in Maths.', icon: Sigma, metric: 'mathsAvgPct', target: 70 },
  { id: 'subj-maths-90', category: 'subject', tier: 'gold', exam: 'jee', title: 'Maths Maverick', description: '90%+ average in Maths.', icon: Sigma, metric: 'mathsAvgPct', target: 90 },

  { id: 'subj-bio-70', category: 'subject', tier: 'bronze', exam: 'neet', title: 'Biology Learner', description: '70%+ average in Biology.', icon: Dna, metric: 'biologyAvgPct', target: 70 },
  { id: 'subj-bio-90', category: 'subject', tier: 'gold', exam: 'neet', title: 'Bio Ace', description: '90%+ average in Biology.', icon: Dna, metric: 'biologyAvgPct', target: 90 },

  // --- Rank: separate AIR pools per exam ---
  { id: 'neet-rank-50000', category: 'rank', tier: 'bronze', exam: 'neet', title: 'NEET Rising Star', description: 'Break into NEET AIR Top 50,000.', icon: Crown, metric: 'neetRank', target: 50000, comparator: 'lte' },
  { id: 'neet-rank-10000', category: 'rank', tier: 'silver', exam: 'neet', title: 'NEET Contender', description: 'Break into NEET AIR Top 10,000.', icon: Crown, metric: 'neetRank', target: 10000, comparator: 'lte' },
  { id: 'neet-rank-1000', category: 'rank', tier: 'gold', exam: 'neet', title: 'NEET Elite', description: 'Break into NEET AIR Top 1,000.', icon: Crown, metric: 'neetRank', target: 1000, comparator: 'lte' },
  { id: 'neet-rank-100', category: 'rank', tier: 'diamond', exam: 'neet', title: 'NEET Topper', description: 'Break into NEET AIR Top 100.', icon: Crown, metric: 'neetRank', target: 100, comparator: 'lte' },

  { id: 'jee-rank-50000', category: 'rank', tier: 'bronze', exam: 'jee', title: 'JEE Rising Star', description: 'Break into JEE AIR Top 50,000.', icon: Crown, metric: 'jeeRank', target: 50000, comparator: 'lte' },
  { id: 'jee-rank-10000', category: 'rank', tier: 'silver', exam: 'jee', title: 'JEE Contender', description: 'Break into JEE AIR Top 10,000.', icon: Crown, metric: 'jeeRank', target: 10000, comparator: 'lte' },
  { id: 'jee-rank-1000', category: 'rank', tier: 'gold', exam: 'jee', title: 'JEE Elite', description: 'Break into JEE AIR Top 1,000.', icon: Crown, metric: 'jeeRank', target: 1000, comparator: 'lte' },
  { id: 'jee-rank-100', category: 'rank', tier: 'diamond', exam: 'jee', title: 'JEE Topper', description: 'Break into JEE AIR Top 100.', icon: Crown, metric: 'jeeRank', target: 100, comparator: 'lte' },
];

export const CATEGORY_META = {
  streak: { label: 'Streak', icon: Flame },
  volume: { label: 'Volume', icon: Sword },
  score: { label: 'Score', icon: Target },
  subject: { label: 'Subject Mastery', icon: BarChart3 },
  rank: { label: 'Rank', icon: Crown },
};

export const EXAM_META = {
  neet: { label: 'NEET' },
  jee: { label: 'JEE' },
};

/* ============================================================
   EVALUATION
   Pure function: (catalog def + live stats) -> achievement state.
   Same function can run client-side for optimistic UI or in a
   Cloud Function as the source of truth — no duplicated logic.
   ============================================================ */
export function evaluateAchievements(stats) {
  return ACHIEVEMENT_CATALOG
    .map((def) => {
      const current = stats?.[def.metric] ?? 0;
      const isLte = def.comparator === 'lte';
      const unlocked = isLte ? current > 0 && current <= def.target : current >= def.target;

      let progressPct;
      if (unlocked) {
        progressPct = 100;
      } else if (isLte) {
        progressPct = current > 0 ? Math.min(100, Math.round((def.target / current) * 100)) : 0;
      } else {
        progressPct = Math.min(100, Math.round((current / def.target) * 100));
      }

      return { ...def, current, unlocked, progressPct };
    })
    .sort((a, b) => TIER_ORDER.indexOf(a.tier) - TIER_ORDER.indexOf(b.tier));
}

/* ============================================================
   DATA LAYER
   Stand-in for the real Firestore aggregation (Dev 3). Real version:
   read /attempts where studentId == uid, split by attempt.examType
   ('neet' | 'jee'), and reduce to this same `stats` shape — per-exam
   attempt counts, best NEET marks (/720), best JEE percentile,
   per-subject averages, and each exam's predicted AIR. Swapping this
   fetch for the real read is a one-line change; evaluateAchievements
   and the UI don't need to know the difference.
   ============================================================ */
export function useAchievements() {
  const [state, setState] = useState({ data: null, isLoading: true, error: null });

  const fetchData = useCallback(() => {
    setState({ data: null, isLoading: true, error: null });
    const timer = setTimeout(() => {
      // Derive stats from real localStorage data.
      // Per-exam score metrics (neetBestScore, jeeBestPercentile, subject averages,
      // and rank) stay at 0 until Firestore + OMR evaluation pipeline are live —
      // the achievements for those metrics will unlock naturally once real data flows in.
      const player = getPlayerStats();
      const tests  = getTests();

      const neetTests = tests.filter((t) => t.examType === 'neet');
      const jeeTests  = tests.filter((t) => t.examType === 'jee');

      // Subject accuracy averages (across all tests that have topicBreakdown)
      function subjectAvgPct(subjectKey) {
        const rows = tests.flatMap((t) => (t.topicBreakdown || []).filter((r) => r.subject === subjectKey));
        const total = rows.reduce((acc, r) => acc + r.correct + r.incorrect, 0);
        const correct = rows.reduce((acc, r) => acc + r.correct, 0);
        return total > 0 ? Math.round((correct / total) * 100) : 0;
      }

      const stats = {
        streak:             player.streak,
        attemptsCount:      player.attemptsCount,
        neetAttemptsCount:  neetTests.length,
        jeeAttemptsCount:   jeeTests.length,
        // Score metrics — populated once OMR evaluation returns real marks/percentile
        neetBestScore:      Math.max(0, ...neetTests.map((t) => t.totalScore ?? 0)),
        jeeBestPercentile:  Math.max(0, ...jeeTests.map((t) => t.percentile ?? 0)),
        physicsAvgPct:      subjectAvgPct('physics'),
        chemistryAvgPct:    subjectAvgPct('chemistry'),
        mathsAvgPct:        subjectAvgPct('maths'),
        biologyAvgPct:      subjectAvgPct('biology'),
        // Rank — set by Firestore/leaderboard once live
        neetRank:           player.rank?.neet ?? 0,
        jeeRank:            player.rank?.jee  ?? 0,
      };
      setState({ data: evaluateAchievements(stats), isLoading: false, error: null });
    }, 400);
    return () => clearTimeout(timer);
  }, []);

  useEffect(() => fetchData(), [fetchData]);

  return { ...state, retry: fetchData };
}
